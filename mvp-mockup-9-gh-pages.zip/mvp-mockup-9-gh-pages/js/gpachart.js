

var ICEsampleData=[
  {
    value: 22,
    color: "#1b5e20",
    highlight: "#2e7d32",
    label: "Innovation"
  },
  {
    value: 23,
    color: "#8bc34a",
    highlight: "#9ccc65",
    label: "Competency"
  },
  {
    value: 23,
    color: "#26a69a",
    highlight: "#4db6ac",
    label: "Experience"
  }
];



window.onload = function() {
  var graph1 = document.getElementById("ICEchart").getContext("2d");
  var iceGraph = new Chart(graph1).PolarArea(ICEsampleData,{responsive: true});
};
