# About [RadGrad MVP-9](http://radgrad-mvp-9.meteorapp.com/)
RadGrad is a degree planning website, which provides a semester-by-semester representation of the student's curricular and extracurricular endeavors and outside work.  RadGrad will help students allocate their time properly to achieve their academic and career goals.  RadGrad can also provide feedback based on the students academic and career goals and prior graduate experiences to create a plan that is feasible for the student.

##Progress
View our [Huboard](https://huboard.com/radgrad/mvp-9/).

### Current Status
These pages are still in their early stages of development.  The pages are mostly non-static and update from the sample data model, some functions of each page are working.  Databases are set up, and are incorporated into some of the widgets on each of the pages.  The orginal Materialized CSS mockup can be found [here](http://radgrad.org/mvp-mockup-9/).

### Current Deployed Website
The current deployed website can be found [here](http://radgrad-mvp-9.meteorapp.com/).

### Testing the application
Currently to use the website one must log in as a test user. Here are some username and password combinations that will work:
```
[username]        [password]
flanagandanell    foo
markyukimura      foo
normantaylor      foo
```

### Milestone 1 Update Log (April 14, 2016)
- Incorporate ics-data-model and radgrad packages.
- Using Semantic UI, implement skeleton pages for:
  - **Landing Page:**
    - Changed overall theme from Material Design to Semantic UI.
  - **Home Page:**
    - Changed overall theme from Material Design to Semantic UI.
  - **Degree Planner Page:**
    - Changed overall theme from Material Design to Semantic UI.

### Tasks Assignment Milestone 1
#### RoryAndrews
- Set up the meteor project and add the needed packages
- Incorporate ICS-data-model and radgrad package(s)
- Worked on understanding the back end of the project so that file structure and package imports can be set up appropriately for Milestone 2.

#### symorikawa
- Created Degree Planner page skeleton
- Update degree planner side-bar with Semantic UI
- Update degree planner schedule with Semantic UI
- Upgrade degree planner with planned changes from usability test

#### micahtas
- Created home page skeleton
- Implement skeleton of notifications widget with Semantic UI
- Implement skeleton of interests and degree goal widget with Semantic UI

#### justgilyim
- Created Landing page skeleton
- Implement skeleton of academic status widget with Semantic UI
- Created GitHub page

### Milestone 2 Update Log (April 21, 2016)
- Start to figure out how to interact with sample-database.
- Using Semantic UI, implement incorporate improvements from usability test for:
  - **Landing Page:**
    - Make less wordy, more straight to the point.
  - **Home Page:**
    - Improve overall layout
  - **Degree Planner Page:**
    - Improve overall layout

### Tasks Assignment Milestone 2
#### RoryAndrews
- Worked on adding logging in as users and routing appropriately
- Converted navbar to its own template and incorporate it into a main layout template.

#### symorikawa
- Incorporate data model with degree planner

#### micahtas
- Incorporate owl carousel to project
- Convert schedule summary widget from Materialized CSS to Semantic UI
- Implement static upcoming opportunities carousel on landing page

#### justgilyim
- Updated landing pages with improvements found from usability test
- Updated homepage with improvements and suggestions found from usability test.
- Updated GitHub page

### Milestone 3 Update Log (April 28, 2016)
- Start incorporating sample-data-model data into widgets and pages
- Start adding functionality to widgets and pages

### Tasks Assignment Milestone 3
#### RoryAndrews
- Fixed plugins not loading correctly and now login button allows any user to log in
- Added routing for invalid pages and loading
- Started work on getting the Schedule Summary functional.

#### symorikawa
- Implemented feature to sort classes and opportunities by rating or alphabetical order in degree planner page
- Implemented search function for classes and opportunities in degree planner page
- Implemented add new year and semester for degree planner page

#### micahtas
- Implemented search feature for interests tags widget
- Implemented search feature for degree goals widget
- Implemented profile widget and incorporated user data from sample-data-model

#### justgilyim
- Implemented an users page, incorporating data from sample-data-model
- Implemented an opportunities page, incorporating data from sample-data-model
- Updated students and opportunities database
- Updated GitHub page for Milestone 3

### Milestone 4 Update Log (May 5, 2016)
- Continue incorporating sample-data-model data into widgets and pages
- Continue adding functionality to widgets and pages

### Tasks Assignment Milestone 4
#### RoryAndrews
- Reorganized Schedule summary on the homepage to take advantage of semantic-ui and templates.
- Added functionality to schedule summary so that it now uses actual data from the logged in user.

#### symorikawa
- Implemented add and delete function for courses and opportunities in degree planner page

#### micahtas
- Started implementation of add and delete for interest tags, encountered "access denied" error.

#### justgilyim
- Implemented function to calculate and display competency score
- Implement function to calculate and display current amount of credits completed
- Update GitHub page for Milestone 4

### Final Milestone Update Log (May 10, 2016)
- Continue incorporating sample-data-model data into widgets and pages
- Continue adding functionality to widgets and pages

### Tasks Assignment Final Milestone
#### RoryAndrews
- Fixed schedule summary widget from breaking due to initialization before all DOM elements are loaded
- Added expansion of information when class or opportunity is clicked on

#### symorikawa
- Implemented uploading of data on save

#### micahtas
- Started implementation of adding and deleting degree goals, but encountered an error that was not able to be solved
 in time (same error as adding/deleting interest tags, "update failed: access denied").

#### justgilyim
- Implement function to calculate and display GPA
- Implement function to calculate and display Innovation score
- Implement function to calculate and display Experience score
- Implement function to calculate and display current ICE score
