Template.oppPage.helpers({
    opportunityList: function () {
        return _.map(RadGrad.opportunity.find({}, {sort: {name: 1}}).fetch(), function(opportunity) {
            // Required fields
            let name = `*Name:* ${opportunity.name}, `;
            let slug = `*Slug:* ${RadGrad.slug.findBySlug(opportunity.slugID).name}, `;
            let opportunityType = `*Type:* ${RadGrad.opportunitytype.findOne(opportunity.opportunityTypeID).name}, `;
            let sponsor = `*Sponsor:* ${RadGrad.user.findOne(opportunity.sponsorID).lastName}`;
            let tags = `<br>*Tags:* ${RadGrad.tag.getTagNames(opportunity.tagIDs)} `;
            let description = `<br>*Description:* ${opportunity.description}`;
            let start = moment(opportunity.startActive).format('MM/DD/YYYY');
            let end = moment(opportunity.endActive).format('MM/DD/YYYY');
            let activeInterval = `<br>*Active Interval:* ${start} - ${end}`;

            return { iconURL: opportunity.iconURL,
                description: name + slug + opportunityType + sponsor + tags + description + activeInterval};
        })
    }
});
