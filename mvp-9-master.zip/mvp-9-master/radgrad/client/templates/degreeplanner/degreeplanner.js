import {Meteor} from 'meteor/meteor';
import {Template} from 'meteor/templating';
import { Session } from 'meteor/session';
import './degreeplanner.html';
import dragula from 'dragula';


Template.Degreeplanner.onCreated(function bodyOnCreated() {
  Session.set('searchFilter', "");
  Session.set('ratingOrder', false);
  Session.set('changeLog', []);
});

Template.Degreeplanner.helpers({
  /*
   checks the state of the search field and sort toggle then returns appropriate cursor
   */
  courseList: function () {
    if (Session.get('ratingOrder')) {
      return RadGrad.course.find(
        //creates regular expressions to filter the returned results
        {
          $or: [
            {number: {$regex: Session.get('searchFilter').toString(), $options: 'i'}},
            {name: {$regex: Session.get('searchFilter').toString(), $options: 'i'}},
            {description: {$regex: Session.get('searchFilter').toString(), $options: 'i'}},
            {tags: {$regex: Session.get('searchFilter').toString(), $options: 'i'}}
          ]
        },
        //sort by credit hours (for now)
        {sort: {credithrs: -1}});
    } else {
      return RadGrad.course.find(
        //creates regular expressions to filter the returned results
        {
          $or: [
            {number: {$regex: Session.get('searchFilter').toString(), $options: 'i'}},
            {name: {$regex: Session.get('searchFilter').toString(), $options: 'i'}},
            {description: {$regex: Session.get('searchFilter').toString(), $options: 'i'}},
            {tags: {$regex: Session.get('searchFilter').toString(), $options: 'i'}}
          ]
        },
        //sort by course number
        {sort: {number: 1}});
    }
  },
  /*
   builds an array of objects representing the user's degreeplan and returns it
   */
  yearList: function () {
    //get course instance list
    let cil = RadGrad.courseinstance.find();
    //get opportunity instance list
    let oppil = RadGrad.opportunityinstance.find();
    //initvars
    let rArray = [];
    let sArray = [];
    let yearObj = {year: "", semesters: []};
    let semesterObj = {containerID: "", term: "", classes: []};
    let classObj = {description: "", name: "", number: "", credithrs: 0};
    let pastSem = 0, thisSem = 0;

    //add classes to array to sort by semester and year
    cil.forEach(function (item) {
      sArray.push(item);
    });
    sArray = _.sortBy(sArray, function (item) {
      let semNum;
      let curYear = RadGrad.semester.findOne(item.semesterID).year;
      let curSem = RadGrad.semester.findOne(item.semesterID).term;
      if (curSem == "Fall") {
        semNum = "4";
      } else if (curSem == "Spring") {
        semNum = "2";
      }
      else {
        semNum = "3";
      }
      return (curYear.toString().slice(2, 4) + semNum);
    });

    //add classes to appropriate place in the object to be called from the website
    _.each(sArray, function (testobj) {
      //create new class object
      classObj = {
        description: RadGrad.course.findOne(testobj.courseID).description,
        name: RadGrad.course.findOne(testobj.courseID).name,
        number: RadGrad.course.findOne(testobj.courseID).number,
        credithrs: RadGrad.course.findOne(testobj.courseID).credithrs
      };
      //setup sorting variables
      pastSem = thisSem;
      thisSem = testobj.semesterID;

      //same semester, push new class
      if (thisSem === pastSem) {
        semesterObj.classes.push(classObj);
      }
      else {//push old semester to year object and make new semester
        if (semesterObj.classes.length > 0)yearObj.semesters.push(semesterObj);
        let cterm = RadGrad.semester.findOne(testobj.semesterID).term;
        let cyear = RadGrad.semester.findOne(testobj.semesterID).year;
        semesterObj = {
          containerID: cterm.toString().slice(0, 2) + "" + cyear.toString().slice(2, 4),
          term: cterm,
          classes: []
        };
        semesterObj.classes.push(classObj);

        //if in the right year and semester
        if ((yearObj.year.slice(0, 4) == cyear - 1 && (cterm === "Spring" || cterm === "Summer")) || (yearObj.year.slice(0, 4) == cyear && cterm === "Fall")) {
          //do nothing, keep adding to same place
        }

        //push old year to rArray and make new year
        else {
          if (yearObj.semesters.length > 0)rArray.push(yearObj);
          //semesters starting with
          if (cterm === "Fall") {
            yearObj = {year: cyear + "-" + (cyear + 1), semesters: []};
          }
          else {
            yearObj = {year: cyear - 1 + "-" + cyear, semesters: []};
          }
        }
      }
    });
    if (semesterObj.classes.length > 0)yearObj.semesters.push(semesterObj);
    if (yearObj.semesters.length > 0)rArray.push(yearObj);

    return rArray;
  },

  setClassID: function () {
    return this.number.replace(/\s+/g, '');
  }
});

Template.Degreeplanner.events({
  /*
   sets searchFilter state to true if the search field contains text
   */
  'keyup #classSearch': function (event, instance) {
    Session.set('searchFilter', event.target.value);
  },
  /*
   builds a new academic year
   */
  'click .newSemester': function () {
    //get form data
    let year = $('.yearDropdown').dropdown('get text');
    //get dom element to add to
    let ni = document.getElementById('yearList');

    //create title of Academic year
    let newDiv = document.createElement('div');
    let carot = document.createElement('i');
    carot.setAttribute('class', 'dropdown icon');
    newDiv.setAttribute('class', 'title');
    newDiv.appendChild(carot);
    newDiv.innerHTML += year + ' Academic Year';

    //create content of Academic year (Semesters)
    let newCont = document.createElement('div');
    newCont.setAttribute('class', 'ui grid content');

    //fall semester
    let falID = "Fa" + year.toString().slice(2, 4);
    let semContainer = document.createElement('div');
    let classAccordion = document.createElement('div');
    semContainer.setAttribute('class', 'five wide column semesterContainer');
    classAccordion.setAttribute('class', 'accordion');
    classAccordion.setAttribute('id', falID);
    semContainer.innerHTML += 'Fall';
    semContainer.appendChild(classAccordion);

    //spring semester
    let sprID = "Sp" + year.toString().slice(7, 9);
    let semContainerspring = document.createElement('div');
    let classAccordionspring = document.createElement('div');
    semContainerspring.setAttribute('class', 'five wide column semesterContainer');
    classAccordionspring.setAttribute('class', 'accordion');
    classAccordionspring.setAttribute('id', sprID);
    semContainerspring.innerHTML += 'Spring';
    semContainerspring.appendChild(classAccordionspring);

    //summer semester
    let sumID = "Su" + year.toString().slice(7, 9);
    let semContainersummer = document.createElement('div');
    let classAccordionsummer = document.createElement('div');
    semContainersummer.setAttribute('class', 'five wide column semesterContainer');
    classAccordionsummer.setAttribute('class', 'accordion');
    classAccordionsummer.setAttribute('id', sumID);
    semContainersummer.innerHTML += 'Summer';
    semContainersummer.appendChild(classAccordionsummer);
    newCont.appendChild(semContainer);
    newCont.appendChild(semContainerspring);
    newCont.appendChild(semContainersummer);
    ni.appendChild(newDiv);
    ni.appendChild(newCont);

    drake.containers.push(classAccordion);
    drake.containers.push(classAccordionspring);
    drake.containers.push(classAccordionsummer);
  },

  /*
  updates degreeplan for each item in change log
   and clears the log on save button click.
   */
  'click .saveChanges': function () {
    let cl = Session.get('changeLog');
    _.forEach(cl, function (item) {
      //create variables
      let courseSlug=item.class.toLowerCase();
      let courseNumber, courseYear, courseTerm, oldYear, oldTerm, dpChange;
      if (item.class[0] == "E") {
        courseNumber = item.class.slice(0,2);
      } else{
        courseNumber = item.class.slice(0,3);
      }
      if (item.class[item.class.length - 1] == "L") {
        courseNumber += " "+item.class.slice(-4);
      } else {
        courseNumber += " "+item.class.slice(-3);
      }
      courseYear = "20" + item.to.slice(-2);
      courseYear = (courseYear - 1) + 1;
      courseTerm = item.to.slice(0,2);
      if(courseTerm == "Fa"){
        courseTerm += "ll";
      }else if(courseTerm == "Sp"){
        courseTerm += "ring";
      }else{
        courseTerm += "mmer";
      }
      oldYear = "20" + item.from.slice(-2);
      oldYear = (oldYear - 1) + 1;
      oldTerm = item.from.slice(0,2);
      if(oldTerm == "Fa"){
        oldTerm += "ll";
      }else if(oldTerm == "Sp"){
        oldTerm += "ring";
      }else{
        oldTerm += "mmer";
      }
      
      //if moving from addclassList: adding new class to courseinstances and user degreeplan. calls: addCourseInstance
      if (item.from.length > 4) {
        Meteor.call("getSemesterID", courseTerm, courseYear);
        dpChange = {
          course: courseSlug,
          credithrs: RadGrad.course.findOne({number: courseNumber}).credithrs,
          semesterID: Session.get("semesterID"),
          studentID: Meteor.user()._id,
          verified: false
        };
        Meteor.call('addCourseInstance', dpChange);
      }

      //if moving to addclassList: removing courseinstances and degreeplan. calls: removeCourseInstance
      else if (item.to.length > 4) {
        Meteor.call("getSemesterID", oldTerm, oldYear);
        Meteor.call('removeCourseInstance', RadGrad.courseinstance.findOne({courseID: RadGrad.course.findBySlug(courseSlug)._id, semesterID: Session.get("semesterID")}));
      }

      //if moving from semester to semester: updating course instance
      else {
        Meteor.call("getSemesterID", courseTerm, courseYear);
        dpChange = {
          course: courseSlug,
          credithrs: RadGrad.course.findOne({number: courseNumber}).credithrs,
          semesterID: Session.get("semesterID"),
          studentID: Meteor.user()._id,
          verified: false
        };
        Meteor.call("getSemesterID", oldTerm, oldYear);
        Meteor.call('removeCourseInstance', RadGrad.courseinstance.findOne({courseID: RadGrad.course.findBySlug(courseSlug)._id, semesterID: Session.get("semesterID")}));
        Meteor.call('addCourseInstance', dpChange);
      }
    });

    //reset change log after push
    cl = [];
    Session.set('changeLog', cl);
    FlowRouter.go('/homepage');
  },

  /*
   toggles sort order session value
   */
  'change #sortOrder': function (event, instance) {
    Session.set('ratingOrder', event.target.checked);
  }
})
;

Template.Degreeplanner.onRendered(function () {
  //init sticky for add class sidebar
  $('.ui.sticky')
    .sticky()
  ;
//init accordion for sidebar classes
  $('.addClass')
    .accordion()
  ;
//init star rating for classes
  $('.ui.rating')
    .rating()
  ;
//slider checkbox for alpha/rating sort
  $('.ui.checkbox')
    .checkbox()
  ;
//init accordion in schedule section of degree planner
  $('.planner')
    .accordion({exclusive: false})
  ;
//init dropdowns
  $('.ui.dropdown.yearDropdown')
    .dropdown()
  ;

  Meteor.setTimeout(function () {

    this.drake = dragula([
      document.getElementById('addClassList'),
      document.getElementById('Fa17'),
      document.getElementById('Fa18'),
      document.getElementById('Fa19'),
      document.getElementById('Fa20'),
      document.getElementById('Fa21'),
      document.getElementById('Fa22'),
      document.getElementById('Fa23'),
      document.getElementById('Fa24'),
      document.getElementById('Fa25'),
      document.getElementById('Fa26'),
      document.getElementById('Fa27'),
      document.getElementById('Fa28'),
      document.getElementById('Fa29'),
      document.getElementById('Sp16'),
      document.getElementById('Sp17'),
      document.getElementById('Sp18'),
      document.getElementById('Sp19'),
      document.getElementById('Sp20'),
      document.getElementById('Sp21'),
      document.getElementById('Sp22'),
      document.getElementById('Sp23'),
      document.getElementById('Sp24'),
      document.getElementById('Sp25'),
      document.getElementById('Sp26'),
      document.getElementById('Sp27'),
      document.getElementById('Sp28'),
      document.getElementById('Sp29'),
      document.getElementById('Sp30'),
      document.getElementById('Su16'),
      document.getElementById('Su17'),
      document.getElementById('Su18'),
      document.getElementById('Su19'),
      document.getElementById('Su20'),
      document.getElementById('Su21'),
      document.getElementById('Su22'),
      document.getElementById('Su23'),
      document.getElementById('Su24'),
      document.getElementById('Su25'),
      document.getElementById('Su26'),
      document.getElementById('Su27'),
      document.getElementById('Su28'),
      document.getElementById('Su29'),
      document.getElementById('Su30'),
    ]).on('drop', function (el, target, source) {
      let changeArray = Session.get('changeLog');
      let dragE = el.getAttribute("id");
      let dragT = target.getAttribute("id");
      let dragF = source.getAttribute("id");

      let link = _.findWhere(changeArray, {to: dragF, class: dragE});
      if (!link)link = _.findWhere(changeArray, {from: dragT, class: dragE});
      if (link) {
        if (link.to == dragF) {
          link.to = dragT;
        } else if (link.from == dragT) {
          link.from = dragF;
        } else {
          //should not happen
        }
      } else {
        changeArray.push({from: dragF, to: dragT, class: dragE});
      }

      //remove loops
      changeArray = _.filter(changeArray, function (item) {
        return item.from != item.to;
      });

      Session.set('changeLog', changeArray);
    });
  }, 250);
});