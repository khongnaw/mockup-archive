/**
 * Created by rory0 on 4/21/2016.
 */
Template.Login.onRendered(function() {
  $("#radgrad-login-button").click(function(){
    $('.login-modal.modal').modal('show');
  });
});