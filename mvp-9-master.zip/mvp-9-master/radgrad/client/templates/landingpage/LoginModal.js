/**
 * Created by rory0 on 4/27/2016.
 */
Template.LoginModal.events({
  /**
   * Handle the click on the login link.
   * @param e The click event.
   * @returns {boolean} False.
   */

  'submit #js-login-form': function(event, template) {
    event.preventDefault();
    let username = template.find("input[name='login-username']").value;
    let password = template.find("input[name='login-password']").value;
    Meteor.loginWithPassword(username, password);
    $('.login-modal.modal').modal('hide');
    return false;
  }
});