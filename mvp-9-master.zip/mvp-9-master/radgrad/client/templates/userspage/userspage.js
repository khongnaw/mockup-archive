Template.Userspage.helpers({
    /**
     * @returns {[doc]} A (non-reactive) array of objects containing user info.
     */
    userList: function () {
        return _.map(RadGrad.user.find({}, {sort: {lastName: 1}}).fetch(), function(user) {
            // Required fields
            let name = `**${user.lastName}, ${user.firstName}** `;
            let roles = `(${user.roles}) `;
            let slug = `*Slug:* ${RadGrad.slug.findBySlug(user.slugID).name} `;
            let email = `*Email:* ${RadGrad.user.getEmail(user._id)} `;
            // Optional fields
            let aboutMe = (_.isEmpty(user.aboutMe)) ? "" : `<br>*About me:* ${user.aboutMe} `;
            let degreeGoalNames = _.map(user.degreeGoalIDs, function(degreeGoalID) {
                return RadGrad.degreegoal.findOne(degreeGoalID).name;
            }) ;
            let degreeGoals = (_.isEmpty(degreeGoalNames)) ? "" : `<br>*Degree Goals*: ${degreeGoalNames}`;
            let tagNames = RadGrad.tag.getTagNames(user.interestTagIDs);
            let tags = (_.isEmpty(tagNames)) ? "" : `<br>*Tags:* ${tagNames} `;
            let degreePlanString = (user.degreePlanID) ? RadGrad.degreeplan.toString(user.degreePlanID) : "";
            let degreePlan = (_.isEmpty(degreePlanString)) ? "" : `<br>*Degree Plan:* ${degreePlanString} `;
            let gradSemester = (_.isEmpty(user.semesterID)) ? "" : `<br>*Graduation:* ${RadGrad.semester.toString(user.semesterID)}`;

            return { picture: user.picture,
                description: name + roles + '<br>' + slug + email + degreeGoals + aboutMe + tags + degreePlan + gradSemester};
        })
    }
});

