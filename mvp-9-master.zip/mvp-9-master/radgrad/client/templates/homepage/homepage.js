Template.Homepage.rendered = function () {

  $('select.dropdown')
      .dropdown()
  ;

};

Template.Homepage.helpers({
  userinfo: function(){
    let user = Meteor.user();
    let name = `${user.firstName} ${user.lastName}`;
    let roles = `(${user.roles}) `;
    let slug = `*Slug:* ${RadGrad.slug.findBySlug(user.slugID).name} `;
    let email = `${RadGrad.user.getEmail(user._id)} `;
    // Optional fields
    let aboutMe = (_.isEmpty(user.aboutMe)) ? "" : `${user.aboutMe} `;
    let degreeGoalNames = _.map(user.degreeGoalIDs, function(degreeGoalID) {
      return RadGrad.degreegoal.findOne(degreeGoalID).name;
    }) ;

    let degreeGoals = (_.isEmpty(degreeGoalNames)) ? "" : `${degreeGoalNames}`;

    var newList = degreeGoals.split(",");


    var primaryGoal;
    for (var i = 0; i < newList.length; i++) {
      if (newList[i] == "B.A. in Information and Computer Sciences" ||
          newList[i] == "B.S. in Computer Science" ||
          newList[i] == "B.S. in Computer Engineering") {
        primaryGoal = newList[i];
      }
    }


    let tagNames = RadGrad.tag.getTagNames(user.interestTagIDs);
    let tags = (_.isEmpty(tagNames)) ? "" : `${tagNames}`;
    tags = tags.split(",");
    let degreePlanString = (user.degreePlanID) ? RadGrad.degreeplan.toString(user.degreePlanID) : "";
    let degreePlan = (_.isEmpty(degreePlanString)) ? "" : `<br>*Degree Plan:* ${degreePlanString} `;
    let gradSemester = (_.isEmpty(user.semesterID)) ? "" : `${RadGrad.semester.toString(user.semesterID)}`;

    return [{ picture: user.picture, name: name, role: roles, email: email, aboutMe: aboutMe, degreeGoals: newList,
      tagNames:tagNames, tags:tags, degreePlanString: degreePlanString, degreePlan: degreePlan, gradSemester:gradSemester, primaryGoal: primaryGoal}];
  },

  tagList: function () {
    return _.map(RadGrad.tag.find({}, {sort: {name: 1}}).fetch(), function(tag) {
      let name = `${tag.name}`;
      let slug = `${RadGrad.slug.findBySlug(tag.slugID).name}`;
      return {name: name, slug: slug};
    })
  },

  degreeGoalList: function() {
    return _.map(RadGrad.degreegoal.find({}, {sort: {name: 1}}).fetch(), function(degreeGoal) {
      let name = `${degreeGoal.name}`;
      let slugName = `${RadGrad.slug.findBySlug(degreeGoal.slugID).name}`;
      return {name: name, slugName: slugName}
    })
  },

  calculateCredit: function(){
    var credit = 0;

    var courses = _.filter(RadGrad.courseinstance.find({studentID: Meteor.user()._id}).fetch(), function (item){
      return item.verified === true;
    });

    var courseHistory = _.pluck(courses, 'credithrs');
    _.each(courseHistory, function(item){
      credit = credit + item;
    })

    return credit;
  },

  calculateGPA: function(){
    var culmGPA = 0;
    var creditCount = 0;
    var gradeCount = 0;

    var classes = _.filter(RadGrad.courseinstance.find({studentID: Meteor.user()._id}).fetch(), function (item){
      return item.verified === true;
    });

    _.each(classes, function(item){
      creditCount = creditCount + item.credithrs;
      if(item.grade === 'A' || item.grade === 'A+'){
        gradeCount = gradeCount + (4.0 * item.credithrs);
      }
      else if(item.grade === 'A-'){
        gradeCount = gradeCount + (3.7 * item.credithrs);
      }
      else if(item.grade === 'B+'){
        gradeCount = gradeCount + (3.3 * item.credithrs);
      }
      else if(item.grade === 'B'){
        gradeCount = gradeCount + (3 * item.credithrs);
      }
      else if(item.grade === 'B-'){
        gradeCount = gradeCount + (2.7 * item.credithrs);
      }
      else if(item.grade === 'C+'){
        gradeCount = gradeCount + (2.3 * item.credithrs);
      }
      else if(item.grade === 'C'){
        gradeCount = gradeCount + (2.0 * item.credithrs);
      }
      else if(item.grade === 'C-'){
        gradeCount = gradeCount + (1.7 * item.credithrs);
      }
      else if(item.grade === 'D+'){
        gradeCount = gradeCount + (1.3 * item.credithrs);
      }
      else if(item.grade === 'D'){
        gradeCount = gradeCount + (1.0 * item.credithrs);
      }
      else if(item.grade === 'D-') {
        gradeCount = gradeCount + (.7 * item.credithrs);
      }
    });

    culmGPA = (gradeCount/creditCount).toFixed(2);

    return culmGPA;
  },

  innovation: function (){
    var innovation = 0;

    var OppIDs = _.pluck(_.filter(RadGrad.opportunityinstance.find({studentID: Meteor.user()._id}).fetch(), function(item){
      return item.verified === true ;}), 'iScore');

    _.each(OppIDs, function(item){
      innovation = innovation + item;
    });

    if(innovation >= 100){
      innovation = 100;
    }

    return innovation;
  },

  competency: function(){
    var competency = 0;

    //Filter the list
    var verified = _.filter(RadGrad.courseinstance.find({studentID: Meteor.user()._id}).fetch(), function (item){
      return item.verified === true;
    });
    var noOth1xx = _.filter(verified, function(item){
      return item.courseID !== RadGrad.course.findBySlug("oth1xx")._id
    });
    var noOth2xx = _.filter(noOth1xx, function(item){
      return item.courseID !== RadGrad.course.findBySlug("oth2xx")._id
    });
    var noOth3xx = _.filter(noOth2xx, function(item){
      return item.courseID !== RadGrad.course.findBySlug("oth3xx")._id
    });
    var noOth= _.filter(noOth3xx, function(item){
      return item.courseID !== RadGrad.course.findBySlug("oth4xx")._id
    });

    //Calculate the total
    var grades = _.pluck(noOth, 'grade');
    _.each(grades, function(item){
      if(item === 'A+' || item === 'A' || item === 'A-'){
        competency += 9;
      }
      else if(item === 'B+' || item === 'B' || item === 'B-'){
        competency += 5;
      }
    })
    if(competency >= 100){
      competency = 100;
    }

    return competency;
  },

  experience: function(){
    var experience = 0;

    var OppIDs = _.pluck(_.filter(RadGrad.opportunityinstance.find({studentID: Meteor.user()._id}).fetch(), function(item){
      return item.verified === true ;}), 'eScore');

    _.each(OppIDs, function(item){
      experience = experience + item;
    });

    if(experience >= 100){
      experience = 100;
    }

    return experience;
  },

  calcICE: function(){
    var innovation = 0;
    var experience = 0;
    var competency = 0;

    var innovationIDS = _.pluck(_.filter(RadGrad.opportunityinstance.find({studentID: Meteor.user()._id}).fetch(), function(item){
      return item.verified === true ;}), 'iScore');

    _.each(innovationIDS, function(item){
      innovation = innovation + item;
    });

    //Filter the list
    var verified = _.filter(RadGrad.courseinstance.find({studentID: Meteor.user()._id}).fetch(), function (item){
      return item.verified === true;
    });
    var noOth1xx = _.filter(verified, function(item){
      return item.courseID !== RadGrad.course.findBySlug("oth1xx")._id
    });
    var noOth2xx = _.filter(noOth1xx, function(item){
      return item.courseID !== RadGrad.course.findBySlug("oth2xx")._id
    });
    var noOth3xx = _.filter(noOth2xx, function(item){
      return item.courseID !== RadGrad.course.findBySlug("oth3xx")._id
    });
    var noOth= _.filter(noOth3xx, function(item){
      return item.courseID !== RadGrad.course.findBySlug("oth4xx")._id
    });

    //Calculate the total
    var grades = _.pluck(noOth, 'grade');
    _.each(grades, function(item){
      if(item === 'A+' || item === 'A' || item === 'A-'){
        competency += 9;
      }
      else if(item === 'B+' || item === 'B' || item === 'B-'){
        competency += 5;
      }
    })

    var experienceIDS = _.pluck(_.filter(RadGrad.opportunityinstance.find({studentID: Meteor.user()._id}).fetch(), function(item){
      return item.verified === true ;}), 'eScore');

    _.each(experienceIDS, function(item){
      experience = experience + item;
    });


    if(innovation >= 100){
      innovation = 100;
    }
    if(competency >= 100){
      competency = 100;
    }
    if(experience >= 100){
      experience = 100;
    }

    return innovation + competency + experience;
  }
});

Template.Homepage.events({
  'click .removetag': function(e) {
    e.preventDefault();
    
    let accID = RadGrad.user.findBySlug(Meteor.user().slugID)._id;
    let user = RadGrad.user.findBySlug(Meteor.user().slugID);

    var interestName = this.id;
    var tagNames = user.interestTagIDs;
    let tagNames1 = RadGrad.tag.getTagNames(user.interestTagIDs);

    var index;
    for (var i = 0; i < tagNames1.length; i++) {
      if (interestName == tagNames1[i]) {
        index = i;
      }
    }

    tagNames.splice( index, 1 );
    RadGrad.user.setInterestTagIDs(accID, tagNames);
  },

  'click #submittag': function(e) {
    e.preventDefault();

    let accID = RadGrad.user.findBySlug(Meteor.user().slugID)._id;
    let user = RadGrad.user.findBySlug(Meteor.user().slugID);

    var interestTable = $('#taginput').dropdown('get value');
    var interestTable1 = interestTable[interestTable.length - 1];
    var interestInputIDs = [];

    for (var i = 0; i < interestTable1.length; i++) {
      interestInputIDs.push(RadGrad.slug.getEntityID(interestTable1[i], "Tag"));
    }

    var tagNames = user.interestTagIDs;
    var flag = 0;

    for (var j = 0; j < interestInputIDs.length; j++) {
      for (var k = 0; k < tagNames.length; k++) {
        if (interestInputIDs[j] == tagNames[k]) {
          flag = 1;
        }
      }
    }

    if (flag == 0) {
      var newTagList = interestInputIDs.concat(tagNames);
      RadGrad.user.setInterestTagIDs(accID, newTagList);
    }
    else {
      $('#warning').removeClass('hidden');
    }
  },

  'click #interestWarning': function(e) {
    e.preventDefault();

    $('#warning').closest('.message')
        .transition('fade');
  },
  'click .removeDegreeGoals': function(e) {
    e.preventDefault();

    let acID = RadGrad.user.findBySlug(Meteor.user().slugID)._id;
    let user = RadGrad.user.findBySlug(Meteor.user().slugID);

    var degreeGoalName = this.id;
    var degreeGoalNames = user.degreeGoalIDs;
    let degreeGoalNames1 = _.map(user.degreeGoalIDs, function(degreeGoalID) {
      return RadGrad.degreegoal.findOne(degreeGoalID).name;
    });

    var index;
    for (var i = 0; i < degreeGoalNames1.length; i++) {
      if (degreeGoalName == degreeGoalNames1[i]) {
        index = i;
      }
    }
    degreeGoalNames.splice( index, 1 );
    RadGrad.user.setDegreeGoalIDs(acID, degreeGoalNames);
  },

  'click #degreeGoalsSubmit': function(e) {
    e.preventDefault();

    let acID = RadGrad.user.findBySlug(Meteor.user().slugID)._id;
    let user = RadGrad.user.findBySlug(Meteor.user().slugID);

    var degreeGoalsTable = $('#degreeGoalsInput').dropdown('get value');
    var degreeGoalsTable1 = degreeGoalsTable[degreeGoalsTable.length - 1];

    var degreeGoalsInputIDs = [];
    for (var i = 0; i < degreeGoalsTable1.length; i++) {
      degreeGoalsInputIDs.push(RadGrad.slug.getEntityID(degreeGoalsTable1[i], "DegreeGoal"));
    }

    var degreeGoalNames = user.degreeGoalIDs;
    var flag = 0;

    for (var j = 0; j < degreeGoalsInputIDs.length; j++) {
      for (var k = 0; k < degreeGoalNames.length; k++) {
        if (degreeGoalsInputIDs[j] == degreeGoalNames[k]) {
          flag = 1;
        }
      }
    }

    if (flag == 0) {
      var newDegreeGoalsList = degreeGoalsInputIDs.concat(degreeGoalNames);
      RadGrad.user.setDegreeGoalIDs(acID, newDegreeGoalsList);
    }
    else {
      $('#degreeGoalsWarning').removeClass('hidden');
    }
  },

  'click #degreeGoalsWarning': function(e) {
    e.preventDefault();

    $('#degreeGoalsWarning').closest('.message')
        .transition('fade');
  }
});

