/**
 * Created by rory0 on 5/4/2016.
 */
Template.OpportunityItem.helpers({
  showOpportunityName() {
    return RadGrad.opportunity.findOne(this.opportunity.opportunityID).name;
  },
  showOpportunityType() {
    let opportunity = RadGrad.opportunity.findOne(this.opportunity.opportunityID);
    if(opportunity != undefined) {
      return RadGrad.opportunitytype.findOne(opportunity.opportunityTypeID).name;
    }
  },
  showValidation() {
    if(this.opportunity.verified) {
      return "(verified)";
    }
    else {
      return "(unverified)";
    }
  },
  showOpportunitySponsor() {
    let opportunity = RadGrad.opportunity.findOne(this.opportunity.opportunityID);
    let sponsor = RadGrad.user.findOne(opportunity.sponsorID);
    if(sponsor != undefined) {
      return "sponsored by " + sponsor.username;
    }
  },
  showOpportunityDescription() {
    return RadGrad.opportunity.findOne(this.opportunity.opportunityID).description;
  }
});

Template.OpportunityItem.onRendered(function() {
  $('.ui.accordion').accordion()
});