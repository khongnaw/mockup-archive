/**
 * Created by rory0 on 5/4/2016.
 */
Template.CourseItem.helpers({
  showCourseNumber() {
    return RadGrad.course.findOne(this.course.courseID).number;
  },
  showCourseName() {
    return RadGrad.course.findOne(this.course.courseID).name;
  },
  showCourseGrade() {
    return "Grade: " + this.course.grade + "  Credits: " + this.course.credithrs;
  },
  showCourseDescription() {
    return RadGrad.course.findOne(this.course.courseID).description;
  }
});

Template.CourseItem.onRendered(function() {
  $('.ui.accordion').accordion()
});