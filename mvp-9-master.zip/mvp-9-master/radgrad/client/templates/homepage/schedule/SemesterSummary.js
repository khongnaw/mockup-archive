/**
 * Created by rory0 on 5/4/2016.
 */
Template.SemesterSummary.helpers({
  getCourses() {
    return RadGrad.courseinstance.find({semesterID: this.semester});
  },
  getOpportunities() {
    return RadGrad.opportunityinstance.find({semesterID: this.semester});
  },
  showSemesterText() {
    let info = RadGrad.semester.findOne(this.semester);
    if (info != undefined) {
      return info.term + " " + info.year;
    }
  },
  getWorkHours() {
    let work = RadGrad.workinstance.find({semesterID: this.semester}).fetch();
    if (work != undefined) {
      return "Work Hours: " + work[0].hrswk;
    }
  }
});

Template.SemesterSummary.onRendered(function() {
  let options = {
    loop: false,
    stagePadding: 50,
    margin: 10,
    nav: false,
    dotsEach: true,
    startPosition: "5",
    responsive:{
      0: {
        items:1,
        stagePadding:20
      },
      340: {
        items:1,
        stagePadding:60
      },
      390: {
        items:1,
        stagePadding:80
      },
      425: {
        items:1,
        stagePadding:100
      },
      470: {
        items:2,
        stagePadding:15
      },
      500:{
        items:2,
        stagePadding:80
      },
      550:{
        items:3,
        stagePadding:20
      },
      601:{
        items:3,
        stagePadding:15
      },
      670: {
        items:3,
        stagePadding:30
      },
      730:{
        items:3,
        stagePadding:80
      },
      800:{
        items:4,
        stagePadding:20
      },
      993: {
        items:4,
        stagePadding:40
      },
      1012: {
        items:5,
        stagePadding:20
      },
      1100:{
        items:5,
        stagePadding:50
      },
      1300:{
        items:5,
        stagePadding:80
      },
      1401:{
        items:5,
        stagePadding:50
      },
      1500:{
        items:6,
        stagePadding:50
      },
      1800:{
        items:7,
        stagePadding:15
      },
      1900:{
        items:7,
        stagePadding:50
      },
      2100:{
        items:8,
        stagePadding:50
      }
    }
  };

  Tracker.autorun((function() {
    var schedule = $("#schedule");
    schedule.owlCarousel(options);
    /*schedule.on('mousewheel', '.owl-stage', function (e) {
      if (e.originalEvent.deltaY < 0) {
        schedule.trigger('next.owl.carousel');
      } else {
        schedule.trigger('prev.owl.carousel');
      }
      e.preventDefault();
    });*/
  }).bind(this));
});