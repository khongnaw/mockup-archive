/**
 * Created by rory0 on 4/21/2016.
 */
Template.Header.events({
  /**
   * Handle the click on the logout link.
   * @param e The click event.
   * @returns {boolean} False.
   */
  'click .radgrad-logout': function(e) {
    e.preventDefault();
    FlowRouter.go("/logout");
    return false;
  }
});