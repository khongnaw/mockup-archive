/**
 * Created by Rory on 4/27/2016.
 */
Template.HeaderDropdown.onRendered(function() {
  $('.dropdown').dropdown()
});