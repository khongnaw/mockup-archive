Package.describe({
  name: 'radgrad:core',
  summary: 'RadGrad data model.',
  version: '0.0.12',
  git: 'https://github.com/radgrad/core',
  documentation: "README.md"
});

Package.onUse(function (api) {
  api.versionsFrom(['METEOR@1.2']);

  var packages = [
      'radgrad:lib@0.0.4'
  ];

  api.use(packages);

  api.imply(packages);

  api.addFiles([
    'lib/data-model/Course.js',
    'lib/data-model/CourseInstance.js',
    'lib/data-model/DegreeGoal.js',
    'lib/data-model/DegreePlan.js',
    'lib/data-model/Opportunity.js',
    'lib/data-model/OpportunityInstance.js',
    'lib/data-model/OpportunityType.js',
    'lib/data-model/RadGrad.js',
    'lib/data-model/Role.js',
    'lib/data-model/Semester.js',
    'lib/data-model/Slug.js',
    'lib/data-model/Tag.js',
    'lib/data-model/TagType.js',
    'lib/data-model/User.js',
    'lib/data-model/WorkInstance.js'

  ], ['client', 'server']);

  api.export([
    'RadGrad'
  ]);
});