# Overview

radgrad:core implements the [Data Model](http://radgrad.org/development/data-model.html) for [RadGrad](http://radgrad.org).

See the [data-model-example](https://github.com/radgrad/data-model-example) repository for an example application built using this package. 

# API

* [Course](#course)
* [CourseInstance](#courseinstance)
* [DegreeGoal](#degreegoal)
* [DegreePlan](#degreeplan)
* [Opportunity](#opportunity)
* [OpportunityInstance](#opportunityinstance)
* [OpportunityType](#opportunitytype)
* [Semester](#semester)
* [Slug](#slug)
* [Tag](#tag)
* [TagType](#tagtype)
* [User](#user)
* [WorkInstance](#workinstance)

## Course

Schema:

```js
RadGrad.course.collection.attachSchema(new SimpleSchema({
  name: { type: String },
  slugID: { type: SimpleSchema.RegEx.Id },
  number: { type: String },
  credithrs: { type: Number },
  description: { type: String },
  tagIDs: { type: [SimpleSchema.RegEx.Id]}
}));
```

#### RadGrad.course.define (courseDefinition)

Defines a new Course and its associated Slug.

Throws {Meteor.Error} If the course slug exists, or if any of the tag slugs do not exist.

credithrs defaults to 3 if not provided explicitly. 

Returns The newly created docID.

```js
RadGrad.course.define({name: "Program Structure", 
                       slug: "ics212", 
                       number: "ICS 311", 
                       description: "Program organization paradigms, programming environments. Pre: 211 or consent.",
                       tags: ["software-engineering"]});
```

#### RadGrad.course.remove (course)

Removes course and its associated Slug.

course: The document or id associated with this Course.

Throws {Meteor.Error} If course does not correspond to a course, or if there are CourseInstances associated with this course. 

```js
RadGrad.course.remove(courseID);
```


#### RadGrad.course.findBySlug(slug)

Return the Course document corresponding to the passed slugID.

Throws {Meteor.Error} If slugID does not refer to an Course.

```js
let courseDoc = RadGrad.course.findBySlug("ics211");
```

#### RadGrad.course.find() 

Returns a cursor to all courses.

```js
let courseDocs = RadGrad.course.find().fetch();
```

#### RadGrad.course.findOne(courseID)

Returns the document corresponding to courseID.

```js
let courseDoc = RadGrad.course.findOne(courseID)
```


## CourseInstance

Schema:

```js
RadGrad.courseinstance.collection.attachSchema(new SimpleSchema({
  semesterID: { type: SimpleSchema.RegEx.Id },
  courseID: { type: SimpleSchema.RegEx.Id },
  verified: { type: Boolean },
  grade: { type: String },
  credithrs: { type: Number },
  note: { type: String, optional: true},
  studentID: { type: SimpleSchema.RegEx.Id }
}));
```

#### RadGrad.courseinstance.define(courseInstanceDefinition)

Defines a new CourseInstance.

Throws {Meteor.Error} If the course slug cannot be resolved correctly, or if semester is not defined, or if verified is not true or false, or if grade is not a valid grade string.

credithrs defaults to the credithrs associated with the course, but can be overridden if this course instance is being taken for a different number of credits than the default number for this course. 

grade is optional, if not supplied, will default to the empty string.

Returns the new created docID.

```js
RadGrad.courseinstance.define({semesterID: RadGrad.semester.get("Fall", 2015), 
                               course: "ics311", 
                               verified: false, 
                               grade: "B", 
                               studentID: studID});
```

#### RadGrad.courseinstance.remove(courseInstance)

Removes the passed CourseInstance. Always called when removing a DegreePlan.

courseInstance: The document or docId associated with this Courseinstance.

```js
RadGrad.courseinstance.remove(courseInstance)
```

#### RadGrad.courseinstance.find(selector, options) 

Returns a cursor to all course instances.

```js
let courseInstanceDocs = RadGrad.courseinstance.find().fetch();
```

#### RadGrad.courseinstance.findOne(courseInstance)

Returns the document corresponding to courseinstance.

```js
let courseInstanceDoc = RadGrad.courseinstance.findOne(courseInstance)
```

#### RadGrad.courseinstance.findCourseName(courseInstanceID)

Returns {String} The course name associated with courseInstanceID.

Throws {Meteor.Error} If courseInstanceID is not a valid ID.

```js
let courseName = RadGrad.courseinstance.findCourseName(courseInstanceID);
```

#### RadGrad.courseinstance.isID(courseInstanceID)

Returns {boolean} Returns true if the passed ID is a courseInstanceID, false otherwise.

```js
if (RadGrad.courseinstance.isID(docID)) {...}
```

#### RadGrad.courseinstance.toString(courseInstanceID)

Returns {String} A formatted string representing the course instance.

Throws {Meteor.Error} If not a valid course instance ID.

```js
console.log(RadGrad.courseinstance.toString(courseInstanceID));
```

## DegreeGoal

Schema:

```js
RadGrad.degreegoal.collection.attachSchema(new SimpleSchema({
  name: { type: String },
  slugID: { type: SimpleSchema.RegEx.Id },
  description: { type: String }
}));
```

Note: this entity is only partially implemented. 

#### RadGrad.degreegoal.define(degreeGoalDefinition)

Defines a new DegreeGoal and its associated Slug.

Throws {Meteor.Error} If the DegreeGoal definition includes a previously defined slug.

Returns The newly created docID.

```js
RadGrad.degreegoal.define({name: "Silicon Valley Tech", 
                           slug: "sv-tech", 
                           description: "SE for Google."});
```

#### RadGrad.degreegoal.remove(degreeGoal)

Removes the passed DegreeGoal and its associated Slug.

degreeGoal: The document or docId associated with this DegreeGoal.

Throws {Meteor.Error} If degreeGoal is undefined or is associated with an undefined Slug.

```js
RadGrad.degreegoal.remove(degreeGoalID);
```

#### RadGrad.degreegoal.findBySlug(slug)

Return the DegreeGoal document corresponding to the passed slug.

Throws {Meteor.Error} If slug does not refer to an DegreeGoal.

```js
let degreeGoalDoc = RadGrad.degreegoal.findBySlug("sv-tech");
```

#### RadGrad.degreegoal.find(selector, options)

Returns a cursor to all DegreeGoals.

```js
let degreeGoalDocs = RadGrad.degreegoal.find().fetch();
```

#### RadGrad.degreegoal.findOne(degreeGoalID)

Find a specific DegreeGoal.

```js
let degreeGoalDoc = RadGrad.degreegoal.findOne(degreeGoalID);
```

#### RadGrad.degreegoal.getDegreeGoalID(slugName)

Returns the docID of the DegreeGoal associated with slugName.

Throws {Meteor.Error} If the slugName is not defined or is not a DegreeGoal.

```js
let docID = RadGrad.degreegoal.getDegreeGoalID("sv-tech");
```

#### RadGrad.degreegoal.getDegreeGoalIDs(slugNames)

Returns a list of DegreeGoal docIDs associated with slugNames.

Throws {Meteor.Error} If any slugName is not defined or is not a DegreeGoal.

```js
let docIDs = RadGrad.degreegoal.getDegreeGoalIDs(slugNames);
```

#### RadGrad.degreegoal.isID(degreeGoalID)

Returns {boolean} Returns true if degreeGoalID is a docID for DegreeGoals, false otherwise.

```js
if (RadGrad.degreegoal.isID(docID) { ... }
```

## DegreePlan

Schema:

```js
RadGrad.degreeplan.collection.attachSchema(new SimpleSchema({
  courseInstanceIDs: { type: [SimpleSchema.RegEx.Id] },
  opportunityInstanceIDs: { type: [SimpleSchema.RegEx.Id] },
  workInstanceIDs: { type: [SimpleSchema.RegEx.Id] },
  studentID: { type: SimpleSchema.RegEx.Id }
}));
```

#### RadGrad.degreeplan.define(degreePlanDefinition)

Defines a new DegreePlan.

Throws {Meteor.Error} If any of the docIDs are not defined or are not of the appropriate type.

```js
RadGrad.degreeplan.define({courseInstanceIDs: [courseID1, courseID2], 
                           opportunityInstanceIDs: [], 
                           workInstanceIDs: [], 
                           studentID: id});
```

#### RadGrad.degreeplan.remove(degreePlan)

Removes degreePlan and all of its associated CourseInstances, OpportunityInstances, and WorkInstances.

Throws {Meteor.Error} If degreePlan is not a DegreePlan.

```js
RadGrad.degreeplan.remove(degreePlanID);
```

#### RadGrad.degreeplan.find(selector, options)

Returns a cursor to all DegreePlans.

```js
let degreePlanDocs = RadGrad.degreeplan.find().fetch();
```

#### RadGrad.degreeplan.findOne(degreePlanID)

Find a specific Degree Plan.

```js
let degreePlanDoc = RadGrad.degreeplan.findOne(degreePlanID);
```

#### RadGrad.degreeplan.isID(degreePlanID)

Returns {boolean} Returns true if the passed ID is a degreePlanID, false otherwise.

```js
if (RadGrad.degreeplan.isID(degreePlanID)) { ... }
```

#### RadGrad.degreeplan.toString(degreePlanID)

Returns a string with information about this degreePlan.

```js
console.log(RadGrad.degreeplan.toString(degreePlanID));
```

## Opportunity

Schema:
```js
RadGrad.opportunity.collection.attachSchema(new SimpleSchema({
  name: { type: String },
  slugID: { type: String },
  description: { type: String },
  opportunityTypeID: { type: SimpleSchema.RegEx.Id },
  sponsorID: { type: SimpleSchema.RegEx.Id },
  tagIDs: { type: [SimpleSchema.RegEx.Id]},
  iconURL: { type: SimpleSchema.RegEx.Url, optional: true },
  startActive: { type: Date },
  endActive: { type: Date }
}));
```

#### RadGrad.opportunity.define(opportunityDefinition)

Defines a new Opportunity and its associated Slug.

Throws {Meteor.Error} if any of the slugs cannot be resolved correctly.

Returns the newly created docID.

```js
RadGrad.opportunity.define({name: "ATT Hackathon 2015", 
                            slug: "hack15", 
                            description: "Annual hackathon put on by ATT", 
                            opportunityType: "event", 
                            sponsor: "philipjohnson", 
                            tags: ["software-engineering"]
                            startActive: moment("2015-01-12").toDate(),
                            endActive: moment("2015-02-12").toDate() });
```

#### RadGrad.opportunity.remove(opportunity)

Removes opportunity and its associated Slug.

Throws {Meteor.Error} If opportunity is not defined or there are any OpportunityInstances associated with it.

```js
RadGrad.opportunity.remove(docID);
```

#### RadGrad.opportunity.findBySlug(slug)

Return the Opportunity document corresponding to the passed slug.

Throws {Meteor.Error} If slug does not refer to an Opportunity.

```js
let opportunityDoc = RadGrad.opportunity.findBySlug("hack15");
```

#### RadGrad.opportunity.isSlug(slugID)

Returns {boolean} Returns true if slugID refers to an Opportunity, false otherwise.

```js
if (RadGrad.opportunity.isSlug(slugID)) { ... }
```

#### RadGrad.opportunity.find(selector, options)

Returns a cursor to all Opportunitys.

```js
let opportunityDocs = RadGrad.opportunity.find().fetch();
```

#### RadGrad.opportunity.findOne(opportunityID)

Returns the document associated with opportunityID.

```js
let opportunityDoc = RadGrad.opportunity.findOne(opportunityID);
```

## OpportunityInstance

Schema:

```js
RadGrad.opportunityinstance.collection.attachSchema(new SimpleSchema({
  semesterID: { type: SimpleSchema.RegEx.Id },
  opportunityID: { type: SimpleSchema.RegEx.Id },
  verified: { type: Boolean },
  hrswk: { type: Number },
  studentID: { type: SimpleSchema.RegEx.Id }
}));
```

#### RadGrad.opportunityinstance.define(opportunityInstanceDefinition)

Defines a new OpportunityInstance.

Throws {Meteor.Error} If the opportunity slug cannot be resolved correctly, or semester is not defined, or if verified is not true or false, or if hrswk is not a number between 0 and 80.

hrswk is optional. If not supplied, defaults to 0.

Returns The newly created docID.

```js
RadGrad.opportunityinstance.define({semesterID: RadGrad.semester.get("Fall", 2015), 
                                    opportunity: "hack2015", 
                                    verified: false, 
                                    hrswk: 10, 
                                    studentID: id});
```

#### RadGrad.opportunityinstance.remove(opportunityInstance)

Removes the passed OpportunityInstance. Always called when removing a degree plan.

Throws {Meteor.Error} if the opportunityInstance does not exist.

```js
RadGrad.opportunityinstance.remove(opportunityInstanceID);
```

#### RadGrad.opportunityinstance.find(selector, options)

Returns a cursor to all OpportunityInstances.

```js
let opportunityInstanceDocs = RadGrad.opportunityinstance.find().fetch();
```

#### RadGrad.opportunityinstance.findOne(opportunityInstance)

Returns the document associated with opportunityInstance.

```js
let doc = RadGrad.opportunityinstance.findOne(opportunityInstanceID);
```

#### RadGrad.opportunityinstance.isID(opportunityInstanceID)

Returns {boolean} True if opportunityInstanceID is an opportunityInstance ID, false otherwise.

```js
if (RadGrad.opportunityinstance.isID(docID)) { ... }
```

#### RadGrad.opportunityinstance.toString(opportunityInstanceID)

Returns {String} This opportunity instance, formatted as a string.

Throws {Meteor.Error} If not a valid ID.

```js
console.log(RadGrad.opportunityinstance.toString(opportunityInstanceID));
```

## OpportunityType

Schema:

```js
RadGrad.opportunitytype.collection.attachSchema(new SimpleSchema({
  name: { type: String },
  slugID: { type: SimpleSchema.RegEx.Id },
  description: { type: String }
}));
```

#### RadGrad.opportunitytype.define(opportunityTypeDefinition)

Defines a new OpportunityType and its associated slug.

Throws {Meteor.Error} If the definition includes a previously defined slug.

Returns The newly created docID.

```js
RadGrad.opportunitytype.define({name: "Research", 
                                slug: "research", 
                                description: "A research project."});
```

#### RadGrad.opportunitytype.remove(opportunityType)

Removes the passed opportunityType and its associated Slug.

Throws {Meteor.Error} If the passed ID does not correspond to a defined OpportunityType, or if there are still opportunities associated with this opportunity type.

```js
RadGrad.opportunitytype.remove(opportunityTypeID);
```

#### RadGrad.opportunitytype.findBySlug(slug)

Returns {String} The OpportunityType document associated with slug.

Throws {Meteor.Error} If slug does not refer to an OpportunityType.

```js
let opportunityTypeDoc = RadGrad.opportunitytype.findBySlug("research");
```

#### RadGrad.opportunitytype.isSlug(slugID)

Returns {boolean} Returns true if slugID refers to an OpportunityType, false otherwise.

```js
if (RadGrad.opportunitytype.isSlug(slugID)) { ... }
```

#### RadGrad.opportunitytype.find(selector, options)

Returns a cursor to all OpportunityTypes.

```js
let opportunityTypeDocs = RadGrad.opportunitytype.find().fetch();
```

#### RadGrad.opportunitytype.findOne(opportunityType)

Returns the document associated with opportunityType.

```js
let opportunityTypeDoc = RadGrad.opportunitytype.findOne(opportunityTypeID);
```
## Semester

Schema:

```js
RadGrad.semester.collection.attachSchema(new SimpleSchema({
  term: { type: String },
  year: { type: Number }
}));
```

#### RadGrad.semester.get(term, year)

Returns the semesterID associated with the passed term and year.

If the passed term and year do not correspond to a currently defined semesterID, then a new Semester is created and returned.

Term must be one of RadGrad.semester.spring, RadGrad.semester.summer, or RadGrad.semester.fall.

Year must be a number between 1990 and 2050.

```js
let semesterID = RadGrad.semester.get(RadGrad.semester.spring, 2015);
```

#### RadGrad.semester.toString(semesterID, noSpace)

Returns the passed semester, formatted as a string.

If noSpace is true, then term and year are concatenated without a space in between.

```js
console.log(RadGrad.semester.toString(semesterID);
```

## Slug

Schema:

```js
RadGrad.slug.collection.attachSchema(new SimpleSchema({
  name: { type: String },
  entityName: { type: String },
  entityID: { type: SimpleSchema.RegEx.Id, optional: true }
}));
```

#### RadGrad.slug.define(name, entityName)

Defines a Slug.

name: The name of the new Slug.

entityName: The name of the entity it is associated with.

Throws {Meteor.Error} If the name is already used as a Slug.

Returns {String} The docID of the newly created Slug.

```js
let slugID = RadGrad.slug.define("software-engineering", "Tag");
```

#### RadGrad.slug.updateEntityID(slugID, entityID)

Updates a Slug with the docID of the associated entity.

```js
RadGrad.slug.updateEntityID(slugID, entityID);
```

#### RadGrad.slug.getEntityID(slugName, entityName)

Returns the entityID associated with slugName.

entityName: the type of entity ("Course", "User", etc.). 

Throws {Meteor.Error} If slugName does not exist, or the slug is not of the appropriate type.

```js
let courseID = RadGrad.slug.getEntityID("ics311", "Course");
```

## Tag

Schema:

```js
RadGrad.tag.collection.attachSchema(new SimpleSchema({
  name: { type: String },
  slugID: { type: SimpleSchema.RegEx.Id },
  description: { type: String },
  tagTypeID: { type: SimpleSchema.RegEx.Id }
}));
```

#### RadGrad.tag.define(tagDefinition)

Defines a new Tag and its associated Slug.

Throws {Meteor.Error} If the tag definition includes a previously defined slug or an undefined TagType.

Returns The newly created docID.

```js
RadGrad.tag.define({name: "Software Engineering", 
                    slug: "software-engineering", 
                    description: "The application of a systematic approach to the development of software", 
                    tagType: "cs-disciplines"});
```

#### RadGrad.tag.remove(tag)

Removes tag and its associated slug.

Throws {Meteor.Error} If tag is undefined or is associated with an undefined Slug.

```js
RadGrad.tag.remove(tagID);
```

#### RadGrad.tag.findBySlug(slug)

Return the Tag document corresponding to the passed slug.

Throws {Meteor.Error} If slug does not refer to an Tag.

```js
let seDoc = RadGrad.tag.findBySlug("software-engineering");
```

#### RadGrad.tag.isSlug(slugID)

Returns true if slugID refers to an Tag, false otherwise.

```js
if (RadGrad.tag.isSlug(slugID)) { ... }
```

#### RadGrad.tag.find(selector, options)

Returns a cursor to all Tags.

```js
let tagDocs = RadGrad.tag.find().fetch();
```

#### RadGrad.tag.findOne(tagID)

Returns the document corresponding to tagID.

```js
let tagDoc = RadGrad.tag.findOne(tagID);
```

#### RadGrad.tag.getTagID(slugName)

Returns the docID of the Tag associated with slugName.

Throws {Meteor.Error} If the slugName is not defined or is not associated with a tag.

```js
let seDoc = RadGrad.tag.getTagID("software-engineering");
```

#### RadGrad.tag.getTagIDs(slugNames)

Returns a list of docIDs associated with slugNames.

Throws {Meteor.Error} If any of the slugNames are not defined or are not associated with a tag.

```js
let seDocs = RadGrad.tag.getTagIDs(slugNames);
```

#### RadGrad.tag.isID(tagID)

Returns true if the passed ID is a tagID, false otherwise.

```js
if (RadGrad.tag.isID(tagID)) { ... }
```

## TagType

Schema:

```js
RadGrad.tagtype.collection.attachSchema(new SimpleSchema({
  name: { type: String },
  slugID: { type: SimpleSchema.RegEx.Id },
  description: { type: String }
}));
```

#### RadGrad.tagtype.define(tagDefinition)

Defines a new TagType and its associated slug.

Throws {Meteor.Error} If the tag definition includes a previously defined slug.

Returns The newly created docID.

```js
RadGrad.tagtype.define({name: "Locations", 
                        slug: "locations", 
                        description: "Regions of interest."});
```

#### RadGrad.tagtype.remove(tagType)

Removes the passed tagType and its associated Slug.

Throws {Meteor.Error} If the passed tagType does not correspond to a TagType, or if there are Tags associated with this TagType.

```js
RadGrad.tagtype.remove(tagTypeID);
```


#### RadGrad.tagtype.findBySlug(slug)

Return the TagType document corresponding to the passed slug.

Throws {Meteor.Error} If slug does not refer to an TagType.

```js
let locationsDoc = RadGrad.tagtype.findBySlug("locations");
```

#### RadGrad.tagtype.isSlug(slugID)

Returns {boolean} True if slugID refers to an TagType, false otherwise.

```js
if (RadGrad.tagtype.isSlug(slugID)) { ... }
```

#### RadGrad.tagtype.find(selector, options)

Returns a cursor to all TagTypes.

```js
let tagTypeDocs = RadGrad.tagtype.find().fetch();
```

#### RadGrad.tagtype.findOne(tagTypeID)

Returns the document corresponding to tagTypeID.

```js
let locationsDoc = RadGrad.tagtype.findOne(tagTypeID);
```


## User

Schema:

```js
RadGrad.user.schema = new SimpleSchema({
  // username, email, and password are not part of this schema.
  firstName: {type: String},
  middleName: {type: String},
  lastName: {type: String},
  slugID: {type: SimpleSchema.RegEx.Id},
  
  // Everything below is optional.
  degreePlanID: {type: SimpleSchema.RegEx.Id, optional: true},
  degreeGoalIDs: {type: [SimpleSchema.RegEx.Id], optional: true},
  interestTagIDs: {type: [SimpleSchema.RegEx.Id], optional: true},
  picture: {type: String, optional: true},
  aboutMe: {type: String, optional: true},
  graduationSemesterID: {type: SimpleSchema.RegEx.Id, optional: true}
});
```

#### RadGrad.user.define(userDefinition)

Defines a new User and their required data: first, middle, and last names, slug, uhEmail, role, and password.

Throws {Meteor.Error} If the user slug was previously defined.

Returns The newly created docID.

```js
RadGrad.user.define({firstName: "Joe", 
                     middleName: "", 
                     lastName: "Jones", 
                     slug: "joejones", 
                     uhEmail: "jjones@hawaii.edu", 
                     role: RadGrad.role.faculty, 
                     password: "foo"});
```


#### RadGrad.user.remove(userID)

Removes the user associated with userID and its associated Slug.

Throws {Meteor.Error} If userID does not correspond to a User, or if this user is mentioned in any Opportunities.

```js
RadGrad.user.remove(userID);
```

#### RadGrad.user.findBySlug(slug)

Return the User document corresponding to the passed slug.

Throws {Meteor.Error} If slug does not refer to a User.

```js
let userDoc = RadGrad.user.findBySlug("philipmjohnson");
```

#### RadGrad.user.getEmail(userID)

Returns the user's email as a string, or undefined if not published.

Throws {Meteor.Error} If userID is not a user ID.

```js
let email = RadGrad.user.getEmail(userID);
```


#### RadGrad.user.setDegreePlanID(userID, degreePlanID)

Updates userID with a DegreePlanID.

Throws {Meteor.Error} If userID is not a userID, or if degreePlanID is not a degreePlanID.

```js
RadGrad.user.setDegreePlanID(userID, degreePlanID)
```

#### RadGrad.user.setDegreeGoalIDs(userID, degreeGoalIDs)

Updates userID with a list of DegreeGoalIDs.

Throws {Meteor.Error} If userID is not a userID, or if degreeGoalIDs is not a list of degreeGoalID.

```js
RadGrad.user.setDegreeGoalIDs(userID, degreeGoalIDs);
```

#### RadGrad.user.setInterestTagIDs(userID, tagIDs)

Updates userID with a list of TagIDs.

Throws {Meteor.Error} If userID is not a userID, or if tagIDs is not a list of tagID.

```js
RadGrad.user.setInterestTagIDs(userID, tagIDs)
```

#### RadGrad.user.setPicture(userID, picture)

Updates userID with picture URL.

Throws {Meteor.Error} If userID is not a userID, or if picture is not a string.

```js
RadGrad.user.setPicture(userID, "http://gravatar.com/philipmjohnson")
```

#### RadGrad.user.setAboutMe(userID, aboutMe)

Updates userID with aboutMe string.

aboutMe can be in markdown format.

Throws {Meteor.Error} If userID is not a userID, or if aboutMe is not a string.

```js
RadGrad.user.setAboutMe(userID, "I am a [University of Hawaii](http://www.hawaii.edu) student.");
```

#### RadGrad.user.setSemesterID(userID, semesterID)

Updates userID with a graduation SemesterID.

Throws {Meteor.Error} If userID is not a userID, or if semesterID is not a semesterID.

```js
RadGrad.user.setSemesterID(userID, semesterID)
```

## WorkInstance

Schema:

```js
RadGrad.workinstance.collection.attachSchema(new SimpleSchema({
  semesterID: { type: SimpleSchema.RegEx.Id },
  hrswk: { type: Number },
  studentID: { type: SimpleSchema.RegEx.Id }
}));
```

#### RadGrad.workinstance.define(workInstanceDefinition)

Defines a new Workinstance.

Throws {Meteor.Error} If semester is not defined, or if hrswk is not a number between 0 and 80.

Returns The newly created docID.

```js
let workDocID = RadGrad.workinstance.define({semesterID: RadGrad.semester.get("Fall", 2015), 
                                             hrswk: 10, 
                                             studentID: id});
```

#### RadGrad.workinstance.remove(workInstance)

Removes the passed WorkInstance. Always called when deleting a DegreePlan.

Throws {Meteor.Error} If workInstance is not a WorkInstance.

```js
RadGrad.workinstance.remove(workInstance);
```

#### RadGrad.workinstance.find(selector, options)

Returns a cursor to all WorkInstances.

```js
let workInstanceDocs = RadGrad.workinstance.find().fetch();
```

#### RadGrad.workinstance.findOne(workInstanceID);

Returns the document associated with workInstanceID.

Throws {Meteor.Error} If not a valid ID.

```js
let workDoc = RadGrad.workinstance.findOne(workInstanceID);
```

#### RadGrad.workinstance.toString(workInstanceID)

Returns this work instance, formatted as a string.

Throws {Meteor.Error} If not a valid ID.

```js
console.log(RadGrad.workinstance.toString(workInstanceID));
```