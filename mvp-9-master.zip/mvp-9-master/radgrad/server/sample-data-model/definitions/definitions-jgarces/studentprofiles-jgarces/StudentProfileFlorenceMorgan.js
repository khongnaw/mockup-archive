/**
 * This file holds the information for Florence Morgan.
 */

defineFlorenceMorgan = function() {
  let acID = RadGrad.user.findBySlug("florencemorgan")._id;

  /* Work Instances */
  let sampleWorkInstanceData = [
  ];

  let sampleWorkInstanceIDs = _.map(sampleWorkInstanceData, RadGrad.workinstance.define);

  /* Courses */
  let sampleCourseInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: true, grade: "A", studentID: acID,  credithrs: 1},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics111", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics141", verified: true, grade: "B", studentID: acID},

    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: true, grade: "B", studentID: acID,  credithrs: 1},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics211", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics241", verified: true, grade: "B", studentID: acID},

    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth2xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth2xx", verified: true, grade: "B", studentID: acID, credithrs: 4},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth2xx", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ics212", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ics311", verified: true, grade: "A", studentID: acID},

    {semesterID: RadGrad.semester.get("Spring", 2017), course: "oth3xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2017), course: "oth2xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2017), course: "ics313", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2017), course: "ics321", verified: true, grade: "A", studentID: acID, credithrs: 4},

    {semesterID: RadGrad.semester.get("Fall", 2017), course: "oth1xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2017), course: "oth1xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2017), course: "oth2xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2017), course: "ics215", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2017), course: "ics331", verified: true, grade: "A", studentID: acID, credithrs: 4},

    {semesterID: RadGrad.semester.get("Spring", 2018), course: "oth1xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2018), course: "oth2xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2018), course: "oth2xx", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2018), course: "ics451", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2018), course: "ics491", verified: true, grade: "A", studentID: acID},

    {semesterID: RadGrad.semester.get("Fall", 2018), course: "oth1xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2018), course: "oth1xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2018), course: "ics314", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2018), course: "ics332", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2018), course: "ics415", verified: true, grade: "A", studentID: acID},

    {semesterID: RadGrad.semester.get("Spring", 2019), course: "oth1xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2019), course: "oth1xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2019), course: "oth3xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2019), course: "ics414", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2019), course: "ics432", verified: true, grade: "A", studentID: acID}
  ];

  let sampleCourseInstanceIDs = _.map(sampleCourseInstanceData, RadGrad.courseinstance.define);

  /* Opportunities */
  let sampleOpportunityInstanceData = [
    {semesterID: RadGrad.semester.get("Spring", 2016), opportunity: "acm-manoa", verified: true, hrswk: 5, studentID: acID}
  ];

  let sampleOpportunityInstanceIDs = _.map(sampleOpportunityInstanceData, RadGrad.opportunityinstance.define);

  /* Degree Plan */
  let sampleDegreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: sampleCourseInstanceIDs,
    opportunityInstanceIDs: sampleOpportunityInstanceIDs,
    workInstanceIDs: sampleWorkInstanceIDs,
    studentID: acID
  });

  /* Set User Profile */
  RadGrad.user.setDegreePlanID(acID, sampleDegreePlan);
  RadGrad.user.setDegreeGoalIDs(acID,
      [
        RadGrad.slug.getEntityID("bs-cs", "DegreeGoal"),
        RadGrad.slug.getEntityID("web-developer", "DegreeGoal"),
        RadGrad.slug.getEntityID("graduate-school", "DegreeGoal"),
        RadGrad.slug.getEntityID("data-scientist", "DegreeGoal")
      ]);

  RadGrad.user.setInterestTagIDs(acID,
      [
        RadGrad.slug.getEntityID("python", "Tag"),
        RadGrad.slug.getEntityID("algorithms", "Tag"),
        RadGrad.slug.getEntityID("web-design", "Tag"),
        RadGrad.slug.getEntityID("silicon-valley", "Tag"),
        RadGrad.slug.getEntityID("python", "Tag"),
        RadGrad.slug.getEntityID("data-visualization", "Tag"),
        RadGrad.slug.getEntityID("javascript", "Tag")
      ]);

  RadGrad.user.setPicture(acID, "http://faceresearch.org/uploads/base/african_male.jpg");
  RadGrad.user.setAboutMe(acID, "I am a freshman in ICS, and I am interested in creating programs that have practical applications.");
  RadGrad.user.setSemesterID(acID, RadGrad.semester.get("Spring", 2019));

};