/**
 * This file holds the information for Danny Lewis.
 */

defineDannyLewis = function() {
  let acID = RadGrad.user.findBySlug("dannylewis")._id;

  /* Work Instances */
  let sampleWorkInstanceData = [
  ];

  let sampleWorkInstanceIDs = _.map(sampleWorkInstanceData, RadGrad.workinstance.define);

  /* Courses */
  let sampleCourseInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2012), course: "oth1xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2012), course: "oth1xx", verified: true, grade: "A", studentID: acID,  credithrs: 1},
    {semesterID: RadGrad.semester.get("Fall", 2012), course: "oth1xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2012), course: "ics111", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2012), course: "ics141", verified: true, grade: "B", studentID: acID},

    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth1xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth1xx", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth1xx", verified: true, grade: "B", studentID: acID,  credithrs: 1},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth1xx", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "ics211", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "ics241", verified: true, grade: "B", studentID: acID},

    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "B", studentID: acID, credithrs: 4},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "ics212", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "ics311", verified: true, grade: "A", studentID: acID},

    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth3xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ics313", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ics321", verified: true, grade: "A", studentID: acID, credithrs: 4},

    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth1xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth1xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ics331", verified: true, grade: "A", studentID: acID, credithrs: 4},

    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth1xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth2xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth2xx", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ics451", verified: true, grade: "A", studentID: acID},

    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics314", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics331", verified: true, grade: "A", studentID: acID},

    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth3xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics455", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics432", verified: true, grade: "A", studentID: acID}
  ];

  let sampleCourseInstanceIDs = _.map(sampleCourseInstanceData, RadGrad.courseinstance.define);

  /* Opportunities */
  let sampleOpportunityInstanceData = [
    {semesterID: RadGrad.semester.get("Spring", 2013), opportunity: "acm-manoa", verified: true, hrswk: 5, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2013), opportunity: "acm-manoa", verified: true, hrswk: 5, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), opportunity: "acm-manoa", verified: true, hrswk: 5, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), opportunity: "acm-manoa", verified: true, hrswk: 5, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), opportunity: "acm-manoa", verified: true, hrswk: 5, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), opportunity: "acm-manoa", verified: true, hrswk: 5, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), opportunity: "acm-manoa", verified: true, hrswk: 5, studentID: acID}
  ];

  let sampleOpportunityInstanceIDs = _.map(sampleOpportunityInstanceData, RadGrad.opportunityinstance.define);

  /* Degree Plan */
  let sampleDegreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: sampleCourseInstanceIDs,
    opportunityInstanceIDs: sampleOpportunityInstanceIDs,
    workInstanceIDs: sampleWorkInstanceIDs,
    studentID: acID
  });

  /* Set User Profile */
  RadGrad.user.setDegreePlanID(acID, sampleDegreePlan);
  RadGrad.user.setDegreeGoalIDs(acID,
      [
        RadGrad.slug.getEntityID("bs-cs", "DegreeGoal"),
        RadGrad.slug.getEntityID("game-designer", "DegreeGoal"),
        RadGrad.slug.getEntityID("graduate-school", "DegreeGoal")
      ]);

  RadGrad.user.setInterestTagIDs(acID,
      [
        RadGrad.slug.getEntityID("game-design", "Tag"),
        RadGrad.slug.getEntityID("python", "Tag"),
        RadGrad.slug.getEntityID("machine-learning", "Tag"),
        RadGrad.slug.getEntityID("cplusplus", "Tag"),
        RadGrad.slug.getEntityID("c", "Tag"),
        RadGrad.slug.getEntityID("c-sharp", "Tag"),
        RadGrad.slug.getEntityID("javascript", "Tag"),
      ]);

  RadGrad.user.setPicture(acID, "http://faceresearch.org/uploads/base/rugby.jpg");
  RadGrad.user.setAboutMe(acID, "I am a Senior in ICS, and I am interested cryptography and security.");
  RadGrad.user.setSemesterID(acID, RadGrad.semester.get("Spring", 2016));

};