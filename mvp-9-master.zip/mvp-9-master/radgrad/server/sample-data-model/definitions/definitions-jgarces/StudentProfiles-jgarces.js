/**
 * This function calls Jgarces' student profiles.
 */

defineStudentProfilesJgarces = function() {
  defineAleAlex();
  defineDannyLewis();
  defineEunKyung();
  defineFlorenceMorgan();
  defineGarnettJaylin();
  defineMichiYoshi();
  defineSomiJewel();
  defineJordanMerrow();
};