defineMosesWarrenProfile = function() {
  let acID = RadGrad.user.findBySlug("moseswarren")._id;

  let workInstanceData = [
      {semesterID: RadGrad.semester.get("Spring", 2015), hrswk: 10, studentID: acID},
  ];

  let workInstanceIDs = _.map(workInstanceData, RadGrad.workinstance.define);

  let courseInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ics111", verified: true, grade: "A",studentID: acID, credithrs:4},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ics141", verified: true, grade: "A",studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: true, grade: "A",studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth1xx", verified: true, grade: "B",studentID: acID, credithrs:3},

    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ics211", verified: true, grade: "A",studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ics212", verified: true, grade: "B",studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ics241", verified: true, grade: "A",studentID: acID, credithrs:3},

    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth2xx", verified: true, grade: "A",studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth1xx", verified: true, grade: "A",studentID: acID, credithrs:3},
  ];

  let courseInstanceIDs = _.map(courseInstanceData, RadGrad.courseinstance.define);

  let opportunityInstanceData = [

  ];

  let opportunityInstanceIDs = _.map(opportunityInstanceData, RadGrad.opportunityinstance.define);

  let degreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: courseInstanceIDs,
    opportunityInstanceIDs: opportunityInstanceIDs,
    workInstanceIDs: workInstanceIDs,
    studentID: acID
  });

  RadGrad.user.setDegreePlanID(acID, degreePlan);
  RadGrad.user.setDegreeGoalIDs(acID,
      [
          RadGrad.slug.getEntityID("game-designer", "DegreeGoal")
      ]);
  RadGrad.user.setInterestTagIDs(acID,
      [
        RadGrad.slug.getEntityID("marketing", "Tag"),
      ]);

  RadGrad.user.setPicture(acID, "http://www.eng.cam.ac.uk/sites/www.eng.cam.ac.uk/files/styles/full_bleed_inner_page_leading/public/uploads/news/images/590x288_290.jpg?itok=0DJgn4TE");
  RadGrad.user.setAboutMe(acID, "I've been interested in gaming as long as I can remember. I'm now interested in the challenge of making games for others to enjoy. ");
  RadGrad.user.setSemesterID(acID, RadGrad.semester.get("Spring", 2018));

};

