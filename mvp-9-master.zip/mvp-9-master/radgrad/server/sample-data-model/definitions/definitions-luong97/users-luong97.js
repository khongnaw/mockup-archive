defineUsersLuong97 = function() {
    let luong97Users = [
        {
          firstName: "Avery",
          middleName: "",
          lastName: "Upton",
          slug: "averyupton",
          password: "foo",
          uhEmail: "averyupton@hawaii.edu",
          role: RadGrad.role.student
        },
        {
          firstName: "Nate",
          middleName: "",
          lastName: "Fletcher",
          slug: "natefletcher",
          password: "foo",
          uhEmail: "natefletcher@hawaii.edu",
          role: RadGrad.role.student
        },
        {
          firstName: "Moses",
          middleName: "",
          lastName: "Warren",
          slug: "moseswarren",
          password: "foo",
          uhEmail: "moseswarren@hawaii.edu",
          role: RadGrad.role.student
        },
        {
          firstName: "Leighton",
          middleName: "",
          lastName: "Rogerson",
          slug: "leightonrogerson",
          password: "foo",
          uhEmail: "leightonrogerson@hawaii.edu",
          role: RadGrad.role.student
        },
        {
          firstName: "Kailyn",
          middleName: "",
          lastName: "Daniell",
          slug: "kailyndaniell",
          password: "foo",
          uhEmail: "kailyndaniell@hawaii.edu",
          role: RadGrad.role.student
        },
        {
          firstName: "Clara",
          middleName: "",
          lastName: "Hallman",
          slug: "clarahallman",
          password: "foo",
          uhEmail: "clarahallman@hawaii.edu",
          role: RadGrad.role.student
        },
        {
          firstName: "Debby",
          middleName: "",
          lastName: "Polley",
          slug: "debbypolley",
          password: "foo",
          uhEmail: "debbypolley@hawaii.edu",
          role: RadGrad.role.student
        },
        {
          firstName: "Zena",
          middleName: "",
          lastName: "Rush",
          slug: "zenarush",
          password: "foo",
          uhEmail: "zenarush@hawaii.edu",
          role: RadGrad.role.student
        }
    ];
    _.each(luong97Users, RadGrad.user.define);
};
