defineLeightonRogersonProfile = function() {
  let acID = RadGrad.user.findBySlug("leightonrogerson")._id;

  let workInstanceData = [
  ];

  let workInstanceIDs = _.map(workInstanceData, RadGrad.workinstance.define);

  let courseInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: true, grade: "A",studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth1xx", verified: true, grade: "B",studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth1xx", verified: true, grade: "B",studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth1xx", verified: true, grade: "A",studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth1xx", verified: true, grade: "A",studentID: acID, credithrs:3},

    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee160", verified: true, grade: "A+",studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth2xx", verified: true, grade: "B",studentID: acID, credithrs:4},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth2xx", verified: true, grade: "A",studentID: acID, credithrs:4},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth1xx", verified: true, grade: "A",studentID: acID, credithrs:1},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth1xx", verified: true, grade: "A",studentID: acID, credithrs:3},

    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee211", verified: true, studentID: acID, credithrs:4},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee260", verified: true, studentID: acID, credithrs:4},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: true,studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: true,studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: true,studentID: acID, credithrs:1},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: true,studentID: acID, credithrs:1},

    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee205", verified: true, studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee213", verified: true, studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee211", verified: true, studentID: acID, credithrs:4},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: true,studentID: acID, credithrs:4},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: true,studentID: acID, credithrs:4},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: true,studentID: acID, credithrs:3},

    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ee324", verified: true, studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ee371", verified: true, studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ee361", verified: true, studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ee361l", verified: true,studentID: acID, credithrs:1},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ics414", verified: true,studentID: acID, credithrs:3},

    {semesterID: RadGrad.semester.get("Spring", 2017), course: "ee315", verified: true, studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Spring", 2017), course: "ee323", verified: true, studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Spring", 2017), course: "ee323l", verified: true, studentID: acID, credithrs:1},
    {semesterID: RadGrad.semester.get("Spring", 2017), course: "ee367", verified: true, studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Spring", 2017), course: "ee367l", verified: true, studentID: acID, credithrs:1},
    {semesterID: RadGrad.semester.get("Spring", 2017), course: "ee396", verified: true, studentID: acID, credithrs:3},
  ];

  let courseInstanceIDs = _.map(courseInstanceData, RadGrad.courseinstance.define);

  let opportunityInstanceData = [

  ];

  let opportunityInstanceIDs = _.map(opportunityInstanceData, RadGrad.opportunityinstance.define);

  let degreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: courseInstanceIDs,
    opportunityInstanceIDs: opportunityInstanceIDs,
    workInstanceIDs: workInstanceIDs,
    studentID: acID
  });

  RadGrad.user.setDegreePlanID(acID, degreePlan);
  RadGrad.user.setDegreeGoalIDs(acID,
      [
          RadGrad.slug.getEntityID("robotics-engineer", "DegreeGoal")
      ]);
  RadGrad.user.setInterestTagIDs(acID,
      [
        RadGrad.slug.getEntityID("software-engineering", "Tag"),
        RadGrad.slug.getEntityID("operating-systems", "Tag"),
        RadGrad.slug.getEntityID("robotics", "Tag"),
      ]);

  RadGrad.user.setPicture(acID, "http://www.iesabroad.org/files/Leighton%20Rice_headshot%20200x200_2.jpg");
  RadGrad.user.setAboutMe(acID, "I'm interested in Computer Enginering and any related topics such as software engineering and network engineering!");
  RadGrad.user.setSemesterID(acID, RadGrad.semester.get("Spring", 2018));

};

