defineStudentProfilesLuong97 = function(){
    defineAveryUptonProfile();
    defineClaraHallmanProfile();
    defineDebbyPolleyProfile();
    defineKailynDaniellProfile();
    defineLeightonRogersonProfile();
    defineNateFletcherProfile();
    defineMosesWarrenProfile();
    defineZenaRushProfile();
}
