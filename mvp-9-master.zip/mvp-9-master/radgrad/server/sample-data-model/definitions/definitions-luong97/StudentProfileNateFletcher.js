defineNateFletcherProfile = function() {
  let acID = RadGrad.user.findBySlug("natefletcher")._id;

  let workInstanceData = [
  ];

  let workInstanceIDs = _.map(workInstanceData, RadGrad.workinstance.define);

  let courseInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: true, grade: "A",studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth1xx", verified: true, grade: "A",studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth1xx", verified: true, grade: "B",studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth1xx", verified: true, grade: "B",studentID: acID, credithrs:3},

    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee160", verified: true, grade: "A",studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee296", verified: true, grade: "A",studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth2xx", verified: true, grade: "A",studentID: acID, credithrs:4},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth1xx", verified: true, grade: "B",studentID: acID, credithrs:1},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth1xx", verified: true, grade: "B",studentID: acID, credithrs:3},
  ];

  let courseInstanceIDs = _.map(courseInstanceData, RadGrad.courseinstance.define);

  let opportunityInstanceData = [
    {semesterID: RadGrad.semester.get("Spring", 2015), opportunity: "acm-manoa", verified: true, hrswk: 10, studentID: acID},
  ];

  let opportunityInstanceIDs = _.map(opportunityInstanceData, RadGrad.opportunityinstance.define);

  let degreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: courseInstanceIDs,
    opportunityInstanceIDs: opportunityInstanceIDs,
    workInstanceIDs: workInstanceIDs,
    studentID: acID
  });

  RadGrad.user.setDegreePlanID(acID, degreePlan);
  RadGrad.user.setDegreeGoalIDs(acID,
      [
          RadGrad.slug.getEntityID("computer-system-engineer", "DegreeGoal")
      ]);
  RadGrad.user.setInterestTagIDs(acID,
      [
        RadGrad.slug.getEntityID("integrated-circuit-design", "Tag"),
        RadGrad.slug.getEntityID("oop", "Tag")
      ]);

  RadGrad.user.setPicture(acID, "http://www.thegazette.com/storyimage/GA/20151229/ARTICLE/151229736/EP/1/1/EP-151229736.jpg");
  RadGrad.user.setAboutMe(acID, "My father was an electrical engineer and passed on his passion for electronics to me. I've had a lot of experience with electronics as a kid and hope to continue with a career in Computer Engineering.");
  RadGrad.user.setSemesterID(acID, RadGrad.semester.get("Spring", 2018));

};
