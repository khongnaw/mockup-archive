defineStudentProfileAllenSteafan = function() {
  let asID = RadGrad.user.findBySlug("allensteafan")._id;

  let sampleWorkInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2014), hrswk: 12, studentID: asID},
    {semesterID: RadGrad.semester.get("Spring", 2015), hrswk: 12, studentID: asID},
    {semesterID: RadGrad.semester.get("Summer", 2015), hrswk: 25, studentID: asID},
    {semesterID: RadGrad.semester.get("Fall", 2015), hrswk: 12, studentID: asID},
    {semesterID: RadGrad.semester.get("Spring", 2016), hrswk: 12, studentID: asID},
    {semesterID: RadGrad.semester.get("Summer", 2016), hrswk: 40, studentID: asID},
    {semesterID: RadGrad.semester.get("Fall", 2016), hrswk: 10, studentID: asID},
    {semesterID: RadGrad.semester.get("Spring", 2017), hrswk: 10, studentID: asID},
    {semesterID: RadGrad.semester.get("Summer", 2017), hrswk: 40, studentID: asID},
    {semesterID: RadGrad.semester.get("Fall", 2017), hrswk: 10, studentID: asID}
  ];

  let sampleWorkInstanceIDs = _.map(sampleWorkInstanceData, RadGrad.workinstance.define);

  let sampleCourseInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth1xx", verified: false, grade: "B", studentID: asID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: false, grade: "A", studentID: asID, credithrs: 4},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth1xx", verified: false, grade: "A", studentID: asID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth1xx", verified: false, grade: "A", studentID: asID, credithrs: 1},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth1xx", verified: false, grade: "B", studentID: asID},

    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee160", verified: false, grade: "B", studentID: asID, credithrs: 4},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth2xx", verified: false, grade: "A", studentID: asID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth1xx", verified: false, grade: "B", studentID: asID, credithrs: 4},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth1xx", verified: false, grade: "A", studentID: asID, credithrs: 1},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth1xx", verified: false, grade: "B", studentID: asID},

    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee211", verified: false, grade: "A", studentID: asID, credithrs: 4},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee260", verified: false, grade: "A", studentID: asID, credithr: 4},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: false, grade: "B", studentID: asID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: false, grade: "A", studentID: asID, credithrs: 1},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: false, grade: "A", studentID: asID},

    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee213", verified: false, studentID: asID, credithrs: 4},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee205", verified: false, studentID: asID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee296", verified: false, studentID: asID, credithrs: 1},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: false, studentID: asID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: asID},

    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ee324", verified: false, studentID: asID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ee361", verified: false, studentID: asID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth3xx", verified: false, studentID: asID, credithrs: 1},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ee371", verified: false, studentID: asID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth2xx", verified: false, studentID: asID},

    {semesterID: RadGrad.semester.get("Spring", 2017), course: "ee323", verified: false, studentID: asID},
    {semesterID: RadGrad.semester.get("Spring", 2017), course: "oth3xx", verified: false, studentID: asID, credithrs: 1},
    {semesterID: RadGrad.semester.get("Spring", 2017), course: "ee342", verified: false, studentID: asID},
    {semesterID: RadGrad.semester.get("Spring", 2017), course: "ee406", verified: false, studentID: asID},
    {semesterID: RadGrad.semester.get("Spring", 2017), course: "ee396", verified: false, studentID: asID, credithrs: 2},
    {semesterID: RadGrad.semester.get("Spring", 2017), course: "oth1xx", verified: false, studentID: asID},

    {semesterID: RadGrad.semester.get("Fall", 2018), course: "ee468", verified: false, studentID: asID},
    {semesterID: RadGrad.semester.get("Fall", 2018), course: "ee367", verified: false, studentID: asID},
    {semesterID: RadGrad.semester.get("Fall", 2018), course: "oth3xx", verified: false, studentID: asID, credithrs: 1},
    {semesterID: RadGrad.semester.get("Fall", 2018), course: "ee495", verified: false, studentID: asID, credithrs: 1},
    {semesterID: RadGrad.semester.get("Fall", 2018), course: "ics141", verified: false, studentID: asID},
    {semesterID: RadGrad.semester.get("Fall", 2018), course: "ics314", verified: false, studentID: asID}
  ];

  let sampleCourseInstanceIDs = _.map(sampleCourseInstanceData, RadGrad.courseinstance.define);

  let sampleOpportunityInstanceData = [
    {semesterID: RadGrad.semester.get("Spring", 2016), opportunity: "ieee-manoa", verified: true, hrswk: 10, studentID: asID}
  ];

  let sampleOpportunityInstanceIDs = _.map(sampleOpportunityInstanceData, RadGrad.opportunityinstance.define);

  let sampleDegreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: sampleCourseInstanceIDs,
    opportunityInstanceIDs: sampleOpportunityInstanceIDs,
    workInstanceIDs: sampleWorkInstanceIDs,
    studentID: asID
  });

  RadGrad.user.setDegreePlanID(asID, sampleDegreePlan);
  RadGrad.user.setDegreeGoalIDs(asID, [RadGrad.slug.getEntityID("robotics-engineer", "DegreeGoal")]);

  RadGrad.user.setInterestTagIDs(asID,
      [RadGrad.slug.getEntityID("arduino", "Tag"),
        RadGrad.slug.getEntityID("circuit-design", "Tag"),
        RadGrad.slug.getEntityID("microprocessor-design", "Tag"),
        RadGrad.slug.getEntityID("human-computer-interaction", "Tag")
      ]);

  RadGrad.user.setPicture(asID, "https://media.licdn.com/mpr/mpr/shrinknp_200_200/p/3/005/022/037/330bdd9.jpg");
  RadGrad.user.setAboutMe(asID, "I have always been interested in electronics and robotics, so I am looking to pursue a carrer in this field by obtaining a Computer Engineering degree.");
  RadGrad.user.setSemesterID(asID, RadGrad.semester.get("Spring", 2018));
};
