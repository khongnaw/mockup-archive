defineStudentProfileShotaIchirou = function() {
  let siID = RadGrad.user.findBySlug("shotaichirou")._id;

  let sampleWorkInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2012), hrswk: 24, studentID: siID},
    {semesterID: RadGrad.semester.get("Spring", 2013), hrswk: 24, studentID: siID},
    {semesterID: RadGrad.semester.get("Summer", 2013), hrswk: 35, studentID: siID},
    {semesterID: RadGrad.semester.get("Fall", 2013), hrswk: 20, studentID: siID},
    {semesterID: RadGrad.semester.get("Spring", 2014), hrswk: 20, studentID: siID},
    {semesterID: RadGrad.semester.get("Summer", 2014), hrswk: 30, studentID: siID},
    {semesterID: RadGrad.semester.get("Fall", 2014), hrswk: 10, studentID: siID},
    {semesterID: RadGrad.semester.get("Spring", 2015), hrswk: 10, studentID: siID},
    {semesterID: RadGrad.semester.get("Summer", 2015), hrswk: 30, studentID: siID},
    {semesterID: RadGrad.semester.get("Fall", 2015), hrswk: 10, studentID: siID},
    {semesterID: RadGrad.semester.get("Spring", 2016), hrswk: 10, studentID: siID}
  ];

  let sampleWorkInstanceIDs = _.map(sampleWorkInstanceData, RadGrad.workinstance.define);

  let sampleCourseInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2012), course: "oth1xx", verified: false, grade: "A", studentID: siID},
    {semesterID: RadGrad.semester.get("Fall", 2012), course: "oth2xx", verified: false, grade: "B", studentID: siID, credithrs: 4},
    {semesterID: RadGrad.semester.get("Fall", 2012), course: "oth1xx", verified: false, grade: "A", studentID: siID},
    {semesterID: RadGrad.semester.get("Fall", 2012), course: "oth1xx", verified: false, grade: "A", studentID: siID, credithrs: 1},
    {semesterID: RadGrad.semester.get("Fall", 2012), course: "oth1xx", verified: false, grade: "B", studentID: siID},

    {semesterID: RadGrad.semester.get("Spring", 2013), course: "ee160", verified: false, grade: "B", studentID: siID, credithrs: 4},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth2xx", verified: false, grade: "A", studentID: siID, credithrs: 4},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth1xx", verified: false, grade: "A", studentID: siID, credithrs: 4},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth1xx", verified: false, grade: "A", studentID: siID, credithrs: 1},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth1xx", verified: false, grade: "B", studentID: siID},

    {semesterID: RadGrad.semester.get("Summer", 2013), course: "oth1xx", verified: false, grade: "A", studentID: siID},

    {semesterID: RadGrad.semester.get("Fall", 2013), course: "ee211", verified: false, grade: "B", studentID: siID, credithrs: 4},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: false, grade: "A", studentID: siID},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: false, grade: "A", studentID: siID},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: false, grade: "A", studentID: siID, credithrs: 1},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: false, grade: "B", studentID: siID},

    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ee213", verified: false, grade: "A", studentID: siID, credithrs: 4},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ee260", verified: false, grade: "C", studentID: siID, credithrs: 4},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: false, grade: "A", studentID: siID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: false, grade: "B", studentID: siID},

    {semesterID: RadGrad.semester.get("Summer", 2014), course: "oth1xx", verified: false, grade: "A", studentID: siID},

    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee205", verified: false, grade: "B", studentID: siID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee315", verified: false, grade: "A", studentID: siID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee371", verified: false, grade: "C", studentID: siID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ics141", verified: false, grade: "A", studentID: siID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth1xx", verified: false, grade: "A", studentID: siID},

    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee324", verified: false, grade: "B", studentID: siID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee361", verified: false, grade: "A", studentID: siID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth4xx", verified: false, grade: "A", studentID: siID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee296", verified: false, grade: "A", studentID: siID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth3xx", verified: false, grade: "A", studentID: siID,credithrs: 1},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee296", verified: false, grade: "A", studentID: siID, credithrs: 1},

    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee323", verified: false, grade: "B", studentID: siID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth3xx", verified: false, grade: "A", studentID: siID, credithrs: 1},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee342", verified: false, grade: "B", studentID: siID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee367", verified: false, grade: "A", studentID: siID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth3xx", verified: false, grade: "A", studentID: siID, credithrs: 1},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee396", verified: false, grade: "A", studentID: siID, credithrs: 2},

    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee496", verified: false, grade: "B", studentID: siID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee495", verified: false, grade: "B", studentID: siID, credithrs: 1},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee468", verified: false, grade: "A", studentID: siID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics314", verified: false, grade: "A", studentID: siID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee406", verified: false, grade: "A", studentID: siID}
  ];

  let sampleCourseInstanceIDs = _.map(sampleCourseInstanceData, RadGrad.courseinstance.define);

  let sampleOpportunityInstanceData = [
    {semesterID: RadGrad.semester.get("Spring", 2014), opportunity: "ieee-manoa", verified: true, hrswk: 10, studentID: siID},
    {semesterID: RadGrad.semester.get("Fall", 2014), opportunity: "ieee-manoa", verified: true, hrswk: 10, studentID: siID},
    {semesterID: RadGrad.semester.get("Spring", 2015), opportunity: "ieee-manoa", verified: true, hrswk: 10, studentID: siID},
    {semesterID: RadGrad.semester.get("Summer", 2015), opportunity: "qualcomm", verified: true, hrswk: 10, studentID: siID},
    {semesterID: RadGrad.semester.get("Fall", 2015), opportunity: "ieee-manoa", verified: true, hrswk: 10, studentID: siID},
    {semesterID: RadGrad.semester.get("Fall", 2015), opportunity: "global-game-jam", verified: true, hrswk: 10, studentID: siID},
    {semesterID: RadGrad.semester.get("Spring", 2016), opportunity: "ieee-manoa", verified: true, hrswk: 10, studentID: siID}
  ];

  let sampleOpportunityInstanceIDs = _.map(sampleOpportunityInstanceData, RadGrad.opportunityinstance.define);

  let sampleDegreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: sampleCourseInstanceIDs,
    opportunityInstanceIDs: sampleOpportunityInstanceIDs,
    workInstanceIDs: sampleWorkInstanceIDs,
    studentID: siID
  });

  RadGrad.user.setDegreePlanID(siID, sampleDegreePlan);
  RadGrad.user.setDegreeGoalIDs(siID, [RadGrad.slug.getEntityID("game-designer", "DegreeGoal"), RadGrad.slug.getEntityID("user-experience-designer", "DegreeGoal"), RadGrad.slug.getEntityID("robotics-engineer", "DegreeGoal"), RadGrad.slug.getEntityID("bioinformatics-developer", "DegreeGoal")]);

  RadGrad.user.setInterestTagIDs(siID,
      [RadGrad.slug.getEntityID("arduino", "Tag"),
        RadGrad.slug.getEntityID("android", "Tag"),
        RadGrad.slug.getEntityID("c", "Tag"),
        RadGrad.slug.getEntityID("cplusplus", "Tag"),
        RadGrad.slug.getEntityID("python", "Tag"),
        RadGrad.slug.getEntityID("javascript", "Tag"),
        RadGrad.slug.getEntityID("linux", "Tag"),
        RadGrad.slug.getEntityID("css", "Tag"),
        RadGrad.slug.getEntityID("web-design", "Tag"),
        RadGrad.slug.getEntityID("eclipse", "Tag"),
        RadGrad.slug.getEntityID("robotics", "Tag"),
        RadGrad.slug.getEntityID("game-design", "Tag"),
        RadGrad.slug.getEntityID("java", "Tag"),
        RadGrad.slug.getEntityID("software-engineering", "Tag"),
        RadGrad.slug.getEntityID("human-computer-interaction", "Tag"),
        RadGrad.slug.getEntityID("mobile-devices", "Tag"),
        RadGrad.slug.getEntityID("oop", "Tag")
      ]);

  RadGrad.user.setPicture(siID, "http://diverseeducation.com/wp-content/uploads/2013/06/060313_Irwin_Tang.jpg");
  RadGrad.user.setAboutMe(siID, "I am currently in my last semester at UH and have been applying to all different types of software engineering jobs. But my main interest would be in game design and user interface design, although I also have interests in robotics and bioinformatics.");
  RadGrad.user.setSemesterID(siID, RadGrad.semester.get("Spring", 2016));
};
