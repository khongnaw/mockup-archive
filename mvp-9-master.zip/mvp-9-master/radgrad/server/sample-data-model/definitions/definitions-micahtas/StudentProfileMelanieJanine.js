defineStudentProfileMelanieJanine = function() {
  let mj = RadGrad.user.findBySlug("melaniejanine")._id;

  let sampleWorkInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2012), hrswk: 10, studentID: mj},
    {semesterID: RadGrad.semester.get("Spring", 2013), hrswk: 10, studentID: mj},
    {semesterID: RadGrad.semester.get("Summer", 2013), hrswk: 30, studentID: mj},
    {semesterID: RadGrad.semester.get("Fall", 2013), hrswk: 10, studentID: mj},
    {semesterID: RadGrad.semester.get("Spring", 2014), hrswk: 10, studentID: mj},
    {semesterID: RadGrad.semester.get("Summer", 2014), hrswk: 30, studentID: mj},
    {semesterID: RadGrad.semester.get("Fall", 2014), hrswk: 10, studentID: mj},
    {semesterID: RadGrad.semester.get("Spring", 2015), hrswk: 10, studentID: mj},
    {semesterID: RadGrad.semester.get("Summer", 2015), hrswk: 30, studentID: mj},
    {semesterID: RadGrad.semester.get("Fall", 2015), hrswk: 10, studentID: mj},
    {semesterID: RadGrad.semester.get("Spring", 2016), hrswk: 10, studentID: mj}
  ];

  let sampleWorkInstanceIDs = _.map(sampleWorkInstanceData, RadGrad.workinstance.define);

  let sampleCourseInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2012), course: "oth1xx", verified: false, grade: "B", studentID: mj},
    {semesterID: RadGrad.semester.get("Fall", 2012), course: "oth2xx", verified: false, grade: "B", studentID: mj, credithrs: 4},
    {semesterID: RadGrad.semester.get("Fall", 2012), course: "oth1xx", verified: false, grade: "A", studentID: mj},
    {semesterID: RadGrad.semester.get("Fall", 2012), course: "oth1xx", verified: false, grade: "A", studentID: mj, credithrs: 1},
    {semesterID: RadGrad.semester.get("Fall", 2012), course: "oth1xx", verified: false, grade: "A", studentID: mj},

    {semesterID: RadGrad.semester.get("Spring", 2013), course: "ee160", verified: false, grade: "B", studentID: mj, credithrs: 4},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth2xx", verified: false, grade: "A", studentID: mj, credithrs: 4},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth1xx", verified: false, grade: "A", studentID: mj, credithrs: 4},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth1xx", verified: false, grade: "A", studentID: mj, credithrs: 1},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth1xx", verified: false, grade: "A", studentID: mj},

    {semesterID: RadGrad.semester.get("Fall", 2013), course: "ee211", verified: false, grade: "A", studentID: mj, credithrs: 4},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "ee260", verified: false, grade: "B", studentID: mj, credithrs: 4},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: false, grade: "A", studentID: mj},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: false, grade: "A", studentID: mj, credithrs: 1},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: false, grade: "A", studentID: mj},

    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ee213", verified: false, grade: "A", studentID: mj, credithrs: 4},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ee205", verified: false, grade: "A", studentID: mj},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ee296", verified: false, grade: "A", studentID: mj, credithrs: 1},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: false, grade: "A", studentID: mj},

    {semesterID: RadGrad.semester.get("Summer", 2014), course: "oth1xx", verified: false, grade: "A", studentID: mj},

    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee324", verified: false, grade: "B", studentID: mj},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee371", verified: false, grade: "C", studentID: mj},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ics141", verified: false, grade: "A", studentID: mj},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: false, grade: "A", studentID: mj},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth1xx", verified: false, grade: "A", studentID: mj},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth1xx", verified: false, grade: "A", studentID: mj},

    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee315", verified: false, grade: "B", studentID: mj},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee361", verified: false, grade: "A", studentID: mj},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee342", verified: false, grade: "B", studentID: mj},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth3xx", verified: false, grade: "A", studentID: mj,credithrs: 1},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee396", verified: false, grade: "A", studentID: mj, credithrs: 2},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth1xx", verified: false, grade: "A", studentID: mj},

    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee367", verified: false, grade: "A", studentID: mj},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth3xx", verified: false, grade: "A", studentID: mj, credithrs: 1},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee406", verified: false, grade: "A", studentID: mj},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics314", verified: false, grade: "B", studentID: mj},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: false, grade: "A", studentID: mj},

    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee496", verified: false, grade: "A", studentID: mj},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee495", verified: false, grade: "A", studentID: mj, credithrs: 1},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee468", verified: false, grade: "A", studentID: mj},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics311", verified: false, grade: "B", studentID: mj},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: false, grade: "A", studentID: mj},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, grade: "A", studentID: mj}
  ];

  let sampleCourseInstanceIDs = _.map(sampleCourseInstanceData, RadGrad.courseinstance.define);

  let sampleOpportunityInstanceData = [
    {semesterID: RadGrad.semester.get("Spring", 2014), opportunity: "ieee-manoa", verified: true, hrswk: 10, studentID: mj},
    {semesterID: RadGrad.semester.get("Fall", 2014), opportunity: "ieee-manoa", verified: true, hrswk: 10, studentID: mj},
    {semesterID: RadGrad.semester.get("Spring", 2015), opportunity: "ieee-manoa", verified: true, hrswk: 10, studentID: mj},
    {semesterID: RadGrad.semester.get("Summer", 2015), opportunity: "summer-intern", verified: true, hrswk: 10, studentID: mj},
    {semesterID: RadGrad.semester.get("Fall", 2015), opportunity: "ieee-manoa", verified: true, hrswk: 10, studentID: mj},
    {semesterID: RadGrad.semester.get("Fall", 2015), opportunity: "atthack16", verified: true, hrswk: 10, studentID: mj},
    {semesterID: RadGrad.semester.get("Spring", 2016), opportunity: "ieee-manoa", verified: true, hrswk: 10, studentID: mj}
  ];

  let sampleOpportunityInstanceIDs = _.map(sampleOpportunityInstanceData, RadGrad.opportunityinstance.define);

  let sampleDegreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: sampleCourseInstanceIDs,
    opportunityInstanceIDs: sampleOpportunityInstanceIDs,
    workInstanceIDs: sampleWorkInstanceIDs,
    studentID: mj
  });

  RadGrad.user.setDegreePlanID(mj, sampleDegreePlan);
  RadGrad.user.setDegreeGoalIDs(mj, [RadGrad.slug.getEntityID("animation-designer", "DegreeGoal"), RadGrad.slug.getEntityID("user-experience-designer", "DegreeGoal")]);

  RadGrad.user.setInterestTagIDs(mj,
      [RadGrad.slug.getEntityID("android", "Tag"),
        RadGrad.slug.getEntityID("c", "Tag"),
        RadGrad.slug.getEntityID("cplusplus", "Tag"),
        RadGrad.slug.getEntityID("amazon-web-services", "Tag"),
        RadGrad.slug.getEntityID("algorithms", "Tag"),
        RadGrad.slug.getEntityID("system-programming", "Tag"),
        RadGrad.slug.getEntityID("artificial-intelligence", "Tag")
      ]);

  RadGrad.user.setPicture(mj, "https://leahdarrow.com/wp-content/uploads/2015/02/2015-02-LeahDarrow-Speaking-CollegeStudents-200x200.jpg");
  RadGrad.user.setAboutMe(mj, "I am currently in my last semester at UH Manoa, while attending I have been apart of IEEE since my fourth semester. I have also participated in a Hackathon. I am looking to pursue a career in User Experience Design or Animation Design.");
  RadGrad.user.setSemesterID(mj, RadGrad.semester.get("Spring", 2016));
};
