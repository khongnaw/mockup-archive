defineStudentProfileYunAi = function() {
  let ya = RadGrad.user.findBySlug("yunai")._id;

  let sampleWorkInstanceData = [
  ];

  let sampleWorkInstanceIDs = _.map(sampleWorkInstanceData, RadGrad.workinstance.define);

  let sampleCourseInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: false, grade: "A", studentID: ya},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: false, grade: "B", studentID: ya, credithrs: 4},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: false, grade: "A", studentID: ya, credithrs: 4},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: false, grade: "B", studentID: ya},

    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: ya},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: ya},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: false, studentID: ya, credithrs: 4},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: ya}
  ];

  let sampleCourseInstanceIDs = _.map(sampleCourseInstanceData, RadGrad.courseinstance.define);

  let sampleOpportunityInstanceData = [
  ];

  let sampleOpportunityInstanceIDs = _.map(sampleOpportunityInstanceData, RadGrad.opportunityinstance.define);

  let sampleDegreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: sampleCourseInstanceIDs,
    opportunityInstanceIDs: sampleOpportunityInstanceIDs,
    workInstanceIDs: sampleWorkInstanceIDs,
    studentID: ya
  });

  /*RadGrad.user.setDegreePlanID(ya, sampleDegreePlan);
   RadGrad.user.setDegreeGoalIDs(ya, [RadGrad.slug.getEntityID("game-designer", "DegreeGoal")]);*/

  RadGrad.user.setInterestTagIDs(ya,
      [RadGrad.slug.getEntityID("web-design", "Tag"),
        RadGrad.slug.getEntityID("music", "Tag"),
        RadGrad.slug.getEntityID("foreign-languages", "Tag"),
        RadGrad.slug.getEntityID("aerospace", "Tag")
      ]);

  RadGrad.user.setPicture(ya, "http://www.apsense.com/upload/bmc/page/20151023/1445605833349354.jpg");
  RadGrad.user.setAboutMe(ya, "I am going to be starting my first semester at University of Hawaii at Manoa and am unsure of exaclty what type of degree I am going to pursue but am looking into web development.");
  RadGrad.user.setSemesterID(ya, RadGrad.semester.get("Spring", 2019));
};
