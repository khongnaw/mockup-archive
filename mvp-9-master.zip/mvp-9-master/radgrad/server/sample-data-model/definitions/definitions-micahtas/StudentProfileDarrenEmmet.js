defineStudentProfileDarrenEmmet = function() {
  let de = RadGrad.user.findBySlug("darrenemmet")._id;

  let sampleWorkInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2014), hrswk: 12, studentID: de},
    {semesterID: RadGrad.semester.get("Spring", 2015), hrswk: 12, studentID: de},
    {semesterID: RadGrad.semester.get("Summer", 2015), hrswk: 40, studentID: de},
    {semesterID: RadGrad.semester.get("Fall", 2015), hrswk: 12, studentID: de},
    {semesterID: RadGrad.semester.get("Spring", 2016), hrswk: 12, studentID: de},
    {semesterID: RadGrad.semester.get("Summer", 2016), hrswk: 40, studentID: de},
    {semesterID: RadGrad.semester.get("Fall", 2016), hrswk: 10, studentID: de},
    {semesterID: RadGrad.semester.get("Spring", 2017), hrswk: 10, studentID: de}
  ];

  let sampleWorkInstanceIDs = _.map(sampleWorkInstanceData, RadGrad.workinstance.define);

  let sampleCourseInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth1xx", verified: false, grade: "A", studentID: de},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: false, grade: "B", studentID: de, credithrs: 4},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth1xx", verified: false, grade: "B", studentID: de},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth1xx", verified: false, grade: "A", studentID: de, credithrs: 1},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth1xx", verified: false, grade: "B", studentID: de},

    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee160", verified: false, grade: "C", studentID: de, credithrs: 4},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee211", verified: false, grade: "B", studentID: de, credithrs: 4},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth2xx", verified: false, grade: "B", studentID: de, credithrs: 4},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth1xx", verified: false, grade: "B", studentID: de, credithrs: 4},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth1xx", verified: false, grade: "A", studentID: de, credithrs: 1},

    {semesterID: RadGrad.semester.get("Summer", 2015), course: "oth1xx", verified: false, grade: "A", studentID: de},

    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee260", verified: false, grade: "B", studentID: de, credithrs: 4},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee211", verified: false, grade: "B", studentID: de, credithrs: 4},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: false, grade: "B", studentID: de},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: false, grade: "A", studentID: de, credithrs: 1},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: false, grade: "B", studentID: de},

    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee205", verified: false, studentID: de},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee315", verified: false, studentID: de},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee296", verified: false, studentID: de, credithrs: 1},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: false, studentID: de},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: false, studentID: de},

    {semesterID: RadGrad.semester.get("Summer", 2016), course: "oth1xx", verified: false, studentID: de},

    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ee324", verified: false, studentID: de},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ee371", verified: false, studentID: de},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ee361", verified: false, studentID: de},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth3xx", verified: false, studentID: de, credithrs: 1},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ics141", verified: false, studentID: de},

    {semesterID: RadGrad.semester.get("Spring", 2017), course: "ee323", verified: false, studentID: de},
    {semesterID: RadGrad.semester.get("Spring", 2017), course: "oth3xx", verified: false, studentID: de, credithrs: 1},
    {semesterID: RadGrad.semester.get("Spring", 2017), course: "ee367", verified: false, studentID: de},
    {semesterID: RadGrad.semester.get("Spring", 2017), course: "oth3xx", verified: false, studentID: de,credithrs: 1},
    {semesterID: RadGrad.semester.get("Spring", 2017), course: "ee396", verified: false, studentID: de, credithrs: 1},
    {semesterID: RadGrad.semester.get("Spring", 2017), course: "oth3xx", verified: false, studentID: de},

    {semesterID: RadGrad.semester.get("Fall", 2017), course: "ee342", verified: false, studentID: de},
    {semesterID: RadGrad.semester.get("Fall", 2017), course: "ee468", verified: false, studentID: de},
    {semesterID: RadGrad.semester.get("Fall", 2017), course: "ics314", verified: false, studentID: de},
    {semesterID: RadGrad.semester.get("Fall", 2017), course: "oth1xx", verified: false, studentID: de},
    {semesterID: RadGrad.semester.get("Fall", 2017), course: "oth2xx", verified: false, studentID: de},

    {semesterID: RadGrad.semester.get("Spring", 2018), course: "ee496", verified: false, studentID: de},
    {semesterID: RadGrad.semester.get("Spring", 2018), course: "ee495", verified: false, studentID: de, credithrs: 1},
    {semesterID: RadGrad.semester.get("Spring", 2018), course: "ics311", verified: false, studentID: de},
    {semesterID: RadGrad.semester.get("Spring", 2018), course: "ee406", verified: false, studentID: de},
    {semesterID: RadGrad.semester.get("Spring", 2018), course: "oth1xx", verified: false, studentID: de},
    {semesterID: RadGrad.semester.get("Spring", 2018), course: "oth1xx", verified: false, studentID: de}
  ];

  let sampleCourseInstanceIDs = _.map(sampleCourseInstanceData, RadGrad.courseinstance.define);

  let sampleOpportunityInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2016), opportunity: "student-research-symposium", verified: true, hrswk: 10, studentID: de},
    {semesterID: RadGrad.semester.get("Spring", 2016), opportunity: "atthack16", verified: true, hrswk: 10, studentID: de},
    {semesterID: RadGrad.semester.get("Summer", 2016), opportunity: "qualcomm", verified: true, hrswk: 10, studentID: de}
  ];

  let sampleOpportunityInstanceIDs = _.map(sampleOpportunityInstanceData, RadGrad.opportunityinstance.define);

  let sampleDegreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: sampleCourseInstanceIDs,
    opportunityInstanceIDs: sampleOpportunityInstanceIDs,
    workInstanceIDs: sampleWorkInstanceIDs,
    studentID: de
  });

  RadGrad.user.setDegreePlanID(de, sampleDegreePlan);
  RadGrad.user.setDegreeGoalIDs(de, [RadGrad.slug.getEntityID("network-engineer", "DegreeGoal"), RadGrad.slug.getEntityID("operations-research-analyst", "DegreeGoal"), RadGrad.slug.getEntityID("computer-system-engineer", "DegreeGoal")]);

  RadGrad.user.setInterestTagIDs(de,
      [RadGrad.slug.getEntityID("system-programming", "Tag"),
        RadGrad.slug.getEntityID("android", "Tag"),
        RadGrad.slug.getEntityID("c", "Tag"),
        RadGrad.slug.getEntityID("cplusplus", "Tag"),
        RadGrad.slug.getEntityID("cryptography", "Tag"),
        RadGrad.slug.getEntityID("network-security", "Tag"),
        RadGrad.slug.getEntityID("computer-security", "Tag"),
        RadGrad.slug.getEntityID("mathematica", "Tag"),
        RadGrad.slug.getEntityID("algorithms", "Tag")
      ]);

  RadGrad.user.setPicture(de, "http://media.vocativ.com/photos/2014/04/vocativ-user-avatar-6556-9ce5d56899fe9b10f425fcd7745a4703-me_ecu.png");
  RadGrad.user.setAboutMe(de, "I am currently a Computer Engineering student in my third year. I have not really enjoyed too much of the hardware aspects but it seems like it could prove to be useful. I am looking to pursue some kind of systems programming career.");
  RadGrad.user.setSemesterID(de, RadGrad.semester.get("Spring", 2018));
};
