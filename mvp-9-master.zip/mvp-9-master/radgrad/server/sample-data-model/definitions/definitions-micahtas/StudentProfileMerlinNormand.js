defineStudentProfileMerlinNormand = function() {
  let mn = RadGrad.user.findBySlug("merlinnormand")._id;

  let sampleWorkInstanceData = [
  ];

  let sampleWorkInstanceIDs = _.map(sampleWorkInstanceData, RadGrad.workinstance.define);

  let sampleCourseInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2012), course: "ics141", verified: false, grade: "B", studentID: mn},
    {semesterID: RadGrad.semester.get("Fall", 2012), course: "ics111", verified: false, grade: "B", studentID: mn, credithrs: 4},
    {semesterID: RadGrad.semester.get("Fall", 2012), course: "oth2xx", verified: false, grade: "B", studentID: mn, credithrs: 4},
    {semesterID: RadGrad.semester.get("Fall", 2012), course: "oth1xx", verified: false, grade: "B", studentID: mn},

    {semesterID: RadGrad.semester.get("Spring", 2013), course: "ics211", verified: false, grade: "B", studentID: mn, credithrs: 4},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "ics241", verified: false, grade: "B", studentID: mn},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth2xx", verified: false, grade: "B", studentID: mn, credithrs: 4},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth1xx", verified: false, grade: "B", studentID: mn},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth1xx", verified: false, grade: "B", studentID: mn},

    {semesterID: RadGrad.semester.get("Summer", 2013), course: "oth1xx", verified: false, grade: "A", studentID: mn},

    {semesterID: RadGrad.semester.get("Fall", 2013), course: "ics311", verified: false, grade: "B", studentID: mn, credithrs: 4},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "ics212", verified: false, grade: "B", studentID: mn},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: false, grade: "B", studentID: mn},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: false, grade: "B", studentID: mn, credithrs: 1},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: false, grade: "B", studentID: mn},

    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ics312", verified: false, grade: "B", studentID: mn},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ics321", verified: false, grade: "B", studentID: mn},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth1xx", verified: false, grade: "B", studentID: mn},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth1xx", verified: false, grade: "B", studentID: mn},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth1xx", verified: false, grade: "B", studentID: mn},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth1xx", verified: false, grade: "B", studentID: mn, credithrs: 1},

    {semesterID: RadGrad.semester.get("Summer", 2014), course: "oth1xx", verified: false, grade: "A", studentID: mn},

    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ics361", verified: false, grade: "B", studentID: mn},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ics314", verified: false, grade: "B", studentID: mn},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ics313", verified: false, grade: "B", studentID: mn},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: false, grade: "B", studentID: mn},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth1xx", verified: false, grade: "B", studentID: mn},

    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ics332", verified: false, grade: "B", studentID: mn},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ics421", verified: false, grade: "B", studentID: mn},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth1xx", verified: false, grade: "B", studentID: mn},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth2xx", verified: false, grade: "B", studentID: mn},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth1xx", verified: false, grade: "B", studentID: mn,credithrs: 1},

    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics422", verified: false, grade: "B", studentID: mn},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics423", verified: false, grade: "B", studentID: mn},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics351", verified: false, grade: "B", studentID: mn},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: false, grade: "B", studentID: mn},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: false, grade: "B", studentID: mn, credithrs: 1},

    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics451", verified: false, grade: "B", studentID: mn},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics484", verified: false, grade: "B", studentID: mn},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics432", verified: false, grade: "B", studentID: mn},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: false, grade: "B", studentID: mn},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: false, grade: "B", studentID: mn, credithrs: 1}
  ];

  let sampleCourseInstanceIDs = _.map(sampleCourseInstanceData, RadGrad.courseinstance.define);

  let sampleOpportunityInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2015), opportunity: "data-science-specialization", verified: true, hrswk: 10, studentID: mn},
    {semesterID: RadGrad.semester.get("Spring", 2016), opportunity: "atthack16", verified: true, hrswk: 10, studentID: mn}
  ];

  let sampleOpportunityInstanceIDs = _.map(sampleOpportunityInstanceData, RadGrad.opportunityinstance.define);

  let sampleDegreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: sampleCourseInstanceIDs,
    opportunityInstanceIDs: sampleOpportunityInstanceIDs,
    workInstanceIDs: sampleWorkInstanceIDs,
    studentID: mn
  });

  RadGrad.user.setDegreePlanID(mn, sampleDegreePlan);
  RadGrad.user.setDegreeGoalIDs(mn, [RadGrad.slug.getEntityID("database-administrator", "DegreeGoal"), RadGrad.slug.getEntityID("data-mining", "DegreeGoal"), RadGrad.slug.getEntityID("data-scientist", "DegreeGoal")]);

  RadGrad.user.setInterestTagIDs(mn,
      [RadGrad.slug.getEntityID("dynamic-programming", "Tag"),
        RadGrad.slug.getEntityID("java", "Tag"),
        RadGrad.slug.getEntityID("database", "Tag"),
        RadGrad.slug.getEntityID("data-science", "Tag"),
        RadGrad.slug.getEntityID("data-visualization", "Tag"),
        RadGrad.slug.getEntityID("javascript", "Tag")
      ]);

  RadGrad.user.setPicture(mn, "http://product.nuji.com/large/5c43b80c-0126-4fdb-95f4-ffa3d7e18da6.jpg");
  RadGrad.user.setAboutMe(mn, "I am a Computer Science major and am in my last semester at UH. I am looking to pursue a career in databases.");
  RadGrad.user.setSemesterID(mn, RadGrad.semester.get("Spring", 2016));
};
