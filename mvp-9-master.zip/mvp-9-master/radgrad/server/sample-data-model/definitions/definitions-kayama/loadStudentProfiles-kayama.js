defineStudentProfileskayama = function () {
  defineStudentProfileSusumuKimura();
  defineStudentProfileMastermanMichael();
  defineStudentProfileJohnnaGiffard();
  defineStudentProfileKerrCoburn();
  defineStudentProfileRickyBurrell();
  defineStudentProfileKiraPower();
  defineStudentProfileMoeThurstan();
  defineStudentProfileAkaneKurosawa();
}