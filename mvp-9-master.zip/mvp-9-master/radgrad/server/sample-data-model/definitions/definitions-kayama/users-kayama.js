defineUsers_kayama = function() {
  let Users = [
    {
      firstName: "Susumu",
      middleName: "",
      lastName: "Kimura",
      slug: "susumukimura",
      password: "foo",
      uhEmail: "skimura@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Masterman",
      middleName: "",
      lastName: "Michael",
      slug: "mastermanmichael",
      password: "foo",
      uhEmail: "masterman@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Johnna",
      middleName: "",
      lastName: "Giffard",
      slug: "johnnagiffard",
      password: "foo",
      uhEmail: "jgiffard@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Kerr",
      middleName: "",
      lastName: "Coburn",
      slug: "kerrcoburn",
      password: "foo",
      uhEmail: "kcoburn@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Ricky",
      middleName: "",
      lastName: "Burrell",
      slug: "rickyburrell",
      password: "foo",
      uhEmail: "rburrell@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Kira",
      middleName: "",
      lastName: "Power",
      slug: "kirapower",
      password: "foo",
      uhEmail: "kpower@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Moe",
      middleName: "",
      lastName: "Thurstan",
      slug: "moethurstan",
      password: "foo",
      uhEmail: "mthurstan@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Akane",
      middleName: "",
      lastName: "Kurosawa",
      slug: "akanekurosawa",
      password: "foo",
      uhEmail: "akurosawa@hawaii.edu",
      role: RadGrad.role.student
    }
  ];

  _.each(Users, RadGrad.user.define);
}