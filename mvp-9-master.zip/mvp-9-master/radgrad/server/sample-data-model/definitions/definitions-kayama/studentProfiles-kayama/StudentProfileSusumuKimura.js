defineStudentProfileSusumuKimura = function() {
  let skID = RadGrad.user.findBySlug("susumukimura")._id;

  let sampleWorkInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2015), hrswk: 10, studentID: skID}];

  let sampleWorkInstanceIDs = _.map(sampleWorkInstanceData, RadGrad.workinstance.define);

  let sampleCourseInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: false, studentID: skID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: false, studentID: skID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: false, studentID: skID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: false, studentID: skID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: false, studentID: skID}
  ];

  let sampleCourseInstanceIDs = _.map(sampleCourseInstanceData, RadGrad.courseinstance.define);

  let sampleOpportunityInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2015), opportunity: "ieee-manoa", verified: true, hrswk: 10, studentID: skID}];

  let sampleOpportunityInstanceIDs = _.map(sampleOpportunityInstanceData, RadGrad.opportunityinstance.define);

  let sampleDegreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: sampleCourseInstanceIDs,
    opportunityInstanceIDs: sampleOpportunityInstanceIDs,
    workInstanceIDs: sampleWorkInstanceIDs,
    studentID: skID
  });

  RadGrad.user.setDegreePlanID(skID, sampleDegreePlan);
  RadGrad.user.setDegreeGoalIDs(skID, [RadGrad.slug.getEntityID("web-developer", "DegreeGoal")]);

  RadGrad.user.setInterestTagIDs(skID,
      [RadGrad.slug.getEntityID("web-design", "Tag"),
        RadGrad.slug.getEntityID("software-engineering", "Tag")]);

  RadGrad.user.setPicture(skID, "https://s-media-cache-ak0.pinimg.com/236x/88/d3/36/88d3360020b09fd02f6dfcf081da840d.jpg");
  RadGrad.user.setAboutMe(skID, "I am a freshman at UH.  Currently, my major is undeclared, but I would like to try out web development.");
  RadGrad.user.setSemesterID(skID, RadGrad.semester.get("Spring", 2019));
};

