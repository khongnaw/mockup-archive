defineStudentProfileAkaneKurosawa = function() {
  let akID = RadGrad.user.findBySlug("akanekurosawa")._id;

  let sampleWorkInstanceData = [
    {semesterID: RadGrad.semester.get("Spring", 2013), hrswk: 10, studentID: akID},
    {semesterID: RadGrad.semester.get("Fall", 2013), hrswk: 15, studentID: akID},
    {semesterID: RadGrad.semester.get("Spring", 2014), hrswk: 15, studentID: akID},
    {semesterID: RadGrad.semester.get("Fall", 2014), hrswk: 15, studentID: akID},
    {semesterID: RadGrad.semester.get("Spring", 2015), hrswk: 15, studentID: akID}
  ];

  let sampleWorkInstanceIDs = _.map(sampleWorkInstanceData, RadGrad.workinstance.define);

  let sampleCourseInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2012), course: "oth1xx", verified: true, grade: "A", studentID: akID},
    {semesterID: RadGrad.semester.get("Fall", 2012), course: "oth2xx", verified: true, grade: "A", studentID: akID},
    {semesterID: RadGrad.semester.get("Fall", 2012), course: "oth1xx", verified: true, grade: "A", studentID: akID},
    {semesterID: RadGrad.semester.get("Fall", 2012), course: "oth1xx", verified: true, grade: "A", studentID: akID},
    {semesterID: RadGrad.semester.get("Fall", 2012), course: "oth1xx", verified: true, grade: "A", studentID: akID},

    {semesterID: RadGrad.semester.get("Spring", 2013), course: "ee160", verified: true, grade: "A", studentID: akID},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth2xx", verified: true, grade: "B", studentID: akID},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth1xx", verified: true, grade: "B", studentID: akID},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth1xx", verified: true, grade: "A", studentID: akID},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth1xx", verified: true, grade: "B+", studentID: akID},

    {semesterID: RadGrad.semester.get("Fall", 2013), course: "ee211", verified: true, grade: "B", studentID: akID},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "ee260", verified: true, grade: "B", studentID: akID},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "B", studentID: akID},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "A", studentID: akID},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "A", studentID: akID},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "ee296", verified: true, grade: "A", studentID: akID},

    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ee213", verified: true, grade: "B", studentID: akID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ee205", verified: true, grade: "B", studentID: akID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: true, grade: "B", studentID: akID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: true, grade: "B", studentID: akID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth1xx", verified: true, grade: "B", studentID: akID},

    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee324", verified: true, grade: "B", studentID: akID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee371", verified: true, grade: "B", studentID: akID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee361", verified: true, grade: "B", studentID: akID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee361l", verified: true, grade: "A", studentID: akID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee396", verified: true, grade: "A", studentID: akID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ics141", verified: true, grade: "B-", studentID: akID},

    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee315", verified: true, grade: "B", studentID: akID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee323", verified: true, grade: "B", studentID: akID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee323l", verified: true, grade: "A", studentID: akID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee367", verified: true, grade: "B", studentID: akID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee367l", verified: true, grade: "A", studentID: akID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ics311", verified: true, grade: "B", studentID: akID},

    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee342", verified: false, studentID: akID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth3xx", verified: false, studentID: akID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics314", verified: false, studentID: akID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: false, studentID: akID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: false, studentID: akID},

    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee496", verified: false, studentID: akID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee495", verified: false, studentID: akID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics414", verified: false, studentID: akID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: false, studentID: akID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: false, studentID: akID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: false, studentID: akID}
  ];

  let sampleCourseInstanceIDs = _.map(sampleCourseInstanceData, RadGrad.courseinstance.define);

  let sampleOpportunityInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2012), opportunity: "ieee-manoa", verified: true, hrswk: 10, studentID: akID},
    {semesterID: RadGrad.semester.get("Fall", 2012), opportunity: "acm-manoa", verified: true, hrswk: 10, studentID: akID},
    {semesterID: RadGrad.semester.get("Spring", 2013), opportunity: "ieee-manoa", verified: true, hrswk: 10, studentID: akID},
    {semesterID: RadGrad.semester.get("Spring", 2013), opportunity: "acm-manoa", verified: true, hrswk: 10, studentID: akID},
    {semesterID: RadGrad.semester.get("Fall", 2013), opportunity: "ieee-manoa", verified: true, hrswk: 10, studentID: akID},
    {semesterID: RadGrad.semester.get("Fall", 2013), opportunity: "acm-manoa", verified: true, hrswk: 10, studentID: akID},
    {semesterID: RadGrad.semester.get("Spring", 2014), opportunity: "ieee-manoa", verified: true, hrswk: 10, studentID: akID},
    {semesterID: RadGrad.semester.get("Spring", 2014), opportunity: "acm-manoa", verified: true, hrswk: 10, studentID: akID},
    {semesterID: RadGrad.semester.get("Fall", 2014), opportunity: "ieee-manoa", verified: true, hrswk: 10, studentID: akID},
    {semesterID: RadGrad.semester.get("Fall", 2014), opportunity: "acm-manoa", verified: true, hrswk: 10, studentID: akID},
    {semesterID: RadGrad.semester.get("Spring", 2015), opportunity: "ieee-manoa", verified: true, hrswk: 10, studentID: akID},
    {semesterID: RadGrad.semester.get("Spring", 2015), opportunity: "acm-manoa", verified: true, hrswk: 10, studentID: akID}
  ];

  let sampleOpportunityInstanceIDs = _.map(sampleOpportunityInstanceData, RadGrad.opportunityinstance.define);

  let sampleDegreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: sampleCourseInstanceIDs,
    opportunityInstanceIDs: sampleOpportunityInstanceIDs,
    workInstanceIDs: sampleWorkInstanceIDs,
    studentID: akID
  });

  RadGrad.user.setDegreePlanID(akID, sampleDegreePlan);
  RadGrad.user.setDegreeGoalIDs(akID, [RadGrad.slug.getEntityID("web-developer", "DegreeGoal")]);

  RadGrad.user.setInterestTagIDs(akID,
      [RadGrad.slug.getEntityID("web-design", "Tag"),
        RadGrad.slug.getEntityID("software-engineering", "Tag")
      ]);

  RadGrad.user.setPicture(akID, "http://missbuttercup.com/wp-content/uploads/2012/05/IMG_1283-1000x816.jpg");
  RadGrad.user.setAboutMe(akID, "I am a senior in CE and interested in becoming a web developer.");
  RadGrad.user.setSemesterID(akID, RadGrad.semester.get("Spring", 2016));
};

