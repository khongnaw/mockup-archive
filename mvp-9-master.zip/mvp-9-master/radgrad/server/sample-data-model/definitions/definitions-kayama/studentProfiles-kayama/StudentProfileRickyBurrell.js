defineStudentProfileRickyBurrell = function() {
  let rbID = RadGrad.user.findBySlug("rickyburrell")._id;

  let sampleWorkInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2014), hrswk: 10, studentID: rbID},
    {semesterID: RadGrad.semester.get("Spring", 2015), hrswk: 10, studentID: rbID}];

  let sampleWorkInstanceIDs = _.map(sampleWorkInstanceData, RadGrad.workinstance.define);

  let sampleCourseInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: true, grade: "A", studentID: rbID},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "A", studentID: rbID},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: true, grade: "A", studentID: rbID},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: true, grade: "A", studentID: rbID},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: true, grade: "A", studentID: rbID},

    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ee160", verified: true, grade: "A", studentID: rbID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: true, grade: "B", studentID: rbID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth1xx", verified: true, grade: "B", studentID: rbID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth1xx", verified: true, grade: "A", studentID: rbID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth1xx", verified: true, grade: "B+", studentID: rbID},

    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee211", verified: true, grade: "B", studentID: rbID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee260", verified: true, grade: "B", studentID: rbID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: true, grade: "B", studentID: rbID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: true, grade: "A", studentID: rbID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: true, grade: "A", studentID: rbID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee296", verified: true, grade: "A", studentID: rbID},

    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee213", verified: true, grade: "B", studentID: rbID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee205", verified: true, grade: "B", studentID: rbID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth2xx", verified: true, grade: "B", studentID: rbID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth2xx", verified: true, grade: "B", studentID: rbID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth1xx", verified: true, grade: "B", studentID: rbID},

    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee324", verified: false, studentID: rbID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee371", verified: false, studentID: rbID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee361", verified: false, studentID: rbID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee361l", verified: false, studentID: rbID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee396", verified: false, studentID: rbID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics141", verified: false, studentID: rbID},

    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee315", verified: false, studentID: rbID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee323", verified: false, studentID: rbID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee323l", verified: false, studentID: rbID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee367", verified: false, studentID: rbID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee367l", verified: false, studentID: rbID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee344", verified: false, studentID: rbID},

    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ee342", verified: false, studentID: rbID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ee468", verified: false, studentID: rbID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth3xx", verified: false, studentID: rbID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth2xx", verified: false, studentID: rbID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth1xx", verified: false, studentID: rbID},

    {semesterID: RadGrad.semester.get("Spring", 2017), course: "ee496", verified: false, studentID: rbID},
    {semesterID: RadGrad.semester.get("Spring", 2017), course: "ee495", verified: false, studentID: rbID},
    {semesterID: RadGrad.semester.get("Spring", 2017), course: "ee406", verified: false, studentID: rbID},
    {semesterID: RadGrad.semester.get("Spring", 2017), course: "oth2xx", verified: false, studentID: rbID},
    {semesterID: RadGrad.semester.get("Spring", 2017), course: "oth2xx", verified: false, studentID: rbID},
    {semesterID: RadGrad.semester.get("Spring", 2017), course: "oth2xx", verified: false, studentID: rbID}
  ];

  let sampleCourseInstanceIDs = _.map(sampleCourseInstanceData, RadGrad.courseinstance.define);

  let sampleOpportunityInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2013), opportunity: "ieee-manoa", verified: true, hrswk: 10, studentID: rbID},
    {semesterID: RadGrad.semester.get("Spring", 2014), opportunity: "ieee-manoa", verified: true, hrswk: 10, studentID: rbID},
    {semesterID: RadGrad.semester.get("Fall", 2014), opportunity: "ieee-manoa", verified: true, hrswk: 10, studentID: rbID},
    {semesterID: RadGrad.semester.get("Spring", 2015), opportunity: "ieee-manoa", verified: true, hrswk: 10, studentID: rbID}
  ];

  let sampleOpportunityInstanceIDs = _.map(sampleOpportunityInstanceData, RadGrad.opportunityinstance.define);

  let sampleDegreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: sampleCourseInstanceIDs,
    opportunityInstanceIDs: sampleOpportunityInstanceIDs,
    workInstanceIDs: sampleWorkInstanceIDs,
    studentID: rbID
  });

  RadGrad.user.setDegreePlanID(rbID, sampleDegreePlan);
  RadGrad.user.setDegreeGoalIDs(rbID, [RadGrad.slug.getEntityID("network-engineer", "DegreeGoal")]);

  RadGrad.user.setInterestTagIDs(rbID,
      [RadGrad.slug.getEntityID("network-design", "Tag"),
        RadGrad.slug.getEntityID("network-security", "Tag")]);

  RadGrad.user.setPicture(rbID, "http://l2.yimg.com/bt/api/res/1.2/ldigwoFbdlI57H.RgVU_gA--/YXBwaWQ9eW5ld3NfbGVnbztpbD1wbGFuZTtxPTc1O3c9NjAw/http://media.zenfs.com/en/person/Ysports/ricky-rubio-basketball-headshot-photo.jpg");
  RadGrad.user.setAboutMe(rbID, "I am a junior in CE and interested in networking.");
  RadGrad.user.setSemesterID(rbID, RadGrad.semester.get("Spring", 2017));
};

