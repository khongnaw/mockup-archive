/**
 * This function calls Aljon's student profiles.
 */

defineStudentProfilesAljonp = function() {
  defineLaraBryan();
  defineAmadiClarus();
  defineLisaChen();
  defineLaloThatom();
  defineSophieWedekind();
  defineHenieBrose();
  defineAkselReachtain();
  defineNowellAlthaus();
};