/**
 * Created by mike on 1/27/2016.
 */

defineStudentProfileAlexanderAnderson = function() {
  let acID = RadGrad.user.findBySlug("alexanderanderson")._id;

  let workInstanceData = [
  ];

  let workInstanceIDs = _.map(workInstanceData, RadGrad.workinstance.define);

  let courseInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "ics111", verified: true, grade: "B", studentID: acID, credithrs : 4},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "ics141", verified: true, grade: "C", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: true, grade: "B", studentID: acID},

    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ics211", verified: true, grade: "B",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ics241", verified: true, grade: "C",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: true, grade: "A",studentID: acID,credithrs : 4},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: true, grade: "A",studentID: acID},

    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ics311", verified: true, grade: "B",studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ics212", verified: true, grade: "C",studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ics314", verified: true, grade: "C",studentID: acID,credithrs : 4},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: true, grade: "B",studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: true,  grade: "B",studentID: acID},

    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ics331", verified: true, grade: "B",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ics361", verified: true, grade: "B",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ics321", verified: true, grade: "A",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth2xx", verified: true, grade: "B",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth2xx", verified: true,  grade: "A",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ics432", verified: true,  grade: "A",studentID: acID},

    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics332", verified: true, grade: "A",studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics435", verified: true, grade: "B",studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics423", verified: true, grade: "B",studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics421", verified: true, grade: "B",studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth3xx", verified: true,  grade: "B",studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics484", verified: true,  grade: "B",studentID: acID}



  ];

  let courseInstanceIDs = _.map(courseInstanceData, RadGrad.courseinstance.define);

  let opportunityInstanceData = [

    {semesterID: RadGrad.semester.get("Summer", 2014), opportunity: "qualcomm", verified: true, hrswk: 1, studentID: acID},
    {semesterID: RadGrad.semester.get("Summer", 2015), opportunity: "qualcomm-research-center-vienna", verified: true, hrswk: 1, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), opportunity: "acm-manoa", verified: true, hrswk: 1, studentID: acID},

    {semesterID: RadGrad.semester.get("Fall", 2015), opportunity: "acm-manoa", verified: true, hrswk: 1, studentID: acID}
    ,
    {semesterID: RadGrad.semester.get("Spring", 2014), opportunity: "acm-manoa", verified: true, hrswk: 1, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), opportunity: "acm-manoa", verified: true, hrswk: 1, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), opportunity: "atthack16", verified: true, hrswk: 1, studentID: acID}

  ];

  let opportunityInstanceIDs = _.map(opportunityInstanceData, RadGrad.opportunityinstance.define);

  let degreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: courseInstanceIDs,
    opportunityInstanceIDs: opportunityInstanceIDs,
    workInstanceIDs: workInstanceIDs,
    studentID: acID
  });

  RadGrad.user.setDegreePlanID(acID, degreePlan);
  RadGrad.user.setDegreeGoalIDs(acID,
      [RadGrad.slug.getEntityID("data-mining", "DegreeGoal"), RadGrad.slug.getEntityID("data-scientist", "DegreeGoal")/*, RadGrad.slug.getEntityID("bs-ce", "DegreeGoal") */]);
  //RadGrad.slug.getEntityID("ba-cs-it", "DegreeGoal")
  //RadGrad.slug.getEntityID("bs-cs", "DegreeGoal")
  RadGrad.user.setInterestTagIDs(acID,
      [RadGrad.slug.getEntityID("marketing", "Tag"),
        RadGrad.slug.getEntityID("mathematics", "Tag"),
        RadGrad.slug.getEntityID("computer-ethics", "Tag"),
        RadGrad.slug.getEntityID("ruby", "Tag"),
        RadGrad.slug.getEntityID("rails", "Tag"),
        RadGrad.slug.getEntityID("algorithms", "Tag"),
        RadGrad.slug.getEntityID("database", "Tag"),
        RadGrad.slug.getEntityID("music", "Tag"),
        RadGrad.slug.getEntityID("elasticsearch", "Tag"),
        RadGrad.slug.getEntityID("economics", "Tag"),
        RadGrad.slug.getEntityID("data-science", "Tag"),
        RadGrad.slug.getEntityID("sql", "Tag"),
        RadGrad.slug.getEntityID("east-us", "Tag"),
        RadGrad.slug.getEntityID("mysql", "Tag"),
        RadGrad.slug.getEntityID("software-engineering", "Tag")]);

  RadGrad.user.setPicture(acID, "http://www.jandjphotography.net/sites/default/files/imagecache/blog_lb/blog/IMG_0664_pp.jpg");
  RadGrad.user.setAboutMe(acID, "This is my last year in the ICS program and I've been working especially hard since I'm currently the vice-president of one of the ICS clubs.  I am interested in developing smart algorithms for businesses to use to predict financial outcomes.");
  RadGrad.user.setSemesterID(acID, RadGrad.semester.get("Spring", 2016));
};
