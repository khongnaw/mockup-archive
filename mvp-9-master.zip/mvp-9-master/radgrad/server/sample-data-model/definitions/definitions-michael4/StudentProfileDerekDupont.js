/**
 * Created by mike on 1/27/2016.
 */

defineStudentProfileDerekDupont = function() {
  let acID = RadGrad.user.findBySlug("derekdupont")._id;

  let workInstanceData = [


  ];

  let workInstanceIDs = _.map(workInstanceData, RadGrad.workinstance.define);

  let courseInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: true, grade: "A", studentID: acID, credithrs : 4},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: true, grade: "A", studentID: acID},

    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee160", verified: true, grade: "B+",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: true, grade: "B",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: true, grade: "A",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: true, grade: "A",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: true,  grade: "A",studentID: acID},

    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee211", verified: true, grade: "B+",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee260", verified: true, grade: "A",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: true, grade: "A",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: true, grade: "A",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee296", verified: true,  grade: "A",studentID: acID}



  ];

  let courseInstanceIDs = _.map(courseInstanceData, RadGrad.courseinstance.define);

  let opportunityInstanceData = [



  ];

  let opportunityInstanceIDs = _.map(opportunityInstanceData, RadGrad.opportunityinstance.define);

  let degreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: courseInstanceIDs,
    opportunityInstanceIDs: opportunityInstanceIDs,
    workInstanceIDs: workInstanceIDs,
    studentID: acID
  });

  RadGrad.user.setDegreePlanID(acID, degreePlan);
  RadGrad.user.setDegreeGoalIDs(acID,
      [RadGrad.slug.getEntityID("robotics-engineer", "DegreeGoal"), RadGrad.slug.getEntityID("information-security-analyst", "DegreeGoal"),RadGrad.slug.getEntityID("operations-research-analyst", "DegreeGoal") ]);
  //RadGrad.slug.getEntityID("ba-cs-it", "DegreeGoal")
  //RadGrad.slug.getEntityID("bs-cs", "DegreeGoal")
  RadGrad.user.setInterestTagIDs(acID,
      [RadGrad.slug.getEntityID("aerospace", "Tag"),
        RadGrad.slug.getEntityID("wireless-networks", "Tag"),
        RadGrad.slug.getEntityID("microprocessor-design", "Tag"),
        RadGrad.slug.getEntityID("machine-learning", "Tag"),
        RadGrad.slug.getEntityID("computer-security", "Tag"),
        RadGrad.slug.getEntityID("matlab", "Tag"),
        RadGrad.slug.getEntityID("computer-architecture", "Tag"),
        RadGrad.slug.getEntityID("artificial-intelligence", "Tag"),
        RadGrad.slug.getEntityID("music", "Tag"),
        RadGrad.slug.getEntityID("android", "Tag"),
        RadGrad.slug.getEntityID("analytical-modeling", "Tag"),
        RadGrad.slug.getEntityID("calculus", "Tag")]);

  RadGrad.user.setPicture(acID, "http://sites.jmu.edu/seancassidy/files/2013/09/08162013_Schmachtenberg_Staff-Headshots-47.jpg");
  RadGrad.user.setAboutMe(acID, "Ever since I was a kid, I was into builing models and playing with electronics.  I have always loved science and my hero is Bill Nye the Science Guy.  This is my first semster as a computer engineering student and I can't wait to start building computers.");
  RadGrad.user.setSemesterID(acID, RadGrad.semester.get("Spring", 2018));
};
