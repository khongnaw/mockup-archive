/**
 * Created by mike on 1/27/2016.
 */

defineStudentProfileMichaelMiller = function() {
  let acID = RadGrad.user.findBySlug("michaelmiller")._id;

  let workInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2015), hrswk: 25, studentID: acID},    {semesterID: RadGrad.semester.get("Spring", 2016), hrswk: 30, studentID: acID}

  ];

  let workInstanceIDs = _.map(workInstanceData, RadGrad.workinstance.define);

  let courseInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics111", verified: true, grade: "B", studentID: acID, credithrs : 4},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics141", verified: true, grade: "C", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: true, grade: "B", studentID: acID},

    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics211", verified: true, grade: "B",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics241", verified: true, grade: "C",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: true, grade: "A",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: true,  grade: "A",studentID: acID},



  ];

  let courseInstanceIDs = _.map(courseInstanceData, RadGrad.courseinstance.define);

  let opportunityInstanceData = [



  ];

  let opportunityInstanceIDs = _.map(opportunityInstanceData, RadGrad.opportunityinstance.define);

  let degreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: courseInstanceIDs,
    opportunityInstanceIDs: opportunityInstanceIDs,
    workInstanceIDs: workInstanceIDs,
    studentID: acID
  });

  RadGrad.user.setDegreePlanID(acID, degreePlan);
  RadGrad.user.setDegreeGoalIDs(acID,
      [RadGrad.slug.getEntityID("game-designer", "DegreeGoal"), RadGrad.slug.getEntityID("animation-designer", "DegreeGoal") ]);
  //RadGrad.slug.getEntityID("ba-cs-it", "DegreeGoal")
  //RadGrad.slug.getEntityID("bs-cs", "DegreeGoal")
  RadGrad.user.setInterestTagIDs(acID,
      [RadGrad.slug.getEntityID("japan", "Tag"),
        RadGrad.slug.getEntityID("s3", "Tag"),
        RadGrad.slug.getEntityID("python", "Tag"),
        RadGrad.slug.getEntityID("web-design", "Tag"),
        RadGrad.slug.getEntityID("natural-resources", "Tag"),
        RadGrad.slug.getEntityID("bootstrap", "Tag"),
        RadGrad.slug.getEntityID("travel-industry", "Tag"),
        RadGrad.slug.getEntityID("silicon-valley", "Tag"),
        RadGrad.slug.getEntityID("journalism", "Tag"),
        RadGrad.slug.getEntityID("asia", "Tag"),
        RadGrad.slug.getEntityID("java", "Tag"),
        RadGrad.slug.getEntityID("art", "Tag"),
        RadGrad.slug.getEntityID("psychology", "Tag"),
        RadGrad.slug.getEntityID("mongo", "Tag"),
        RadGrad.slug.getEntityID("mobile-devices", "Tag"),
        RadGrad.slug.getEntityID("jquery", "Tag"),
        RadGrad.slug.getEntityID("data-visualization", "Tag"),
        RadGrad.slug.getEntityID("javascript", "Tag"),
        RadGrad.slug.getEntityID("computer-graphics", "Tag")]);

  RadGrad.user.setPicture(acID, "http://archive.voxmagazine.com/media/img/photos/2012/01/120811_VOX_headshots_BZ139b_WEB.jpg");
  RadGrad.user.setAboutMe(acID, "I am currently a sophmore and a level 99 wizard orc.  Video games are the most important thing in my life some obviously ICS was the only degree choice that made sense.  I am always busy; I have to work part-time to help pay for school and destroy noobs online so I don't want to spend lots of time doing homework as well.");
  RadGrad.user.setSemesterID(acID, RadGrad.semester.get("Spring", 2018));
};
