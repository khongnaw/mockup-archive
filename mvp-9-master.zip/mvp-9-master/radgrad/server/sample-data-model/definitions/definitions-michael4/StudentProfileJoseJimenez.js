/**
 * Created by mike on 1/27/2016.
 */

defineStudentProfileJoseJimenez = function() {
  let acID = RadGrad.user.findBySlug("josejimenez")._id;

  let workInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2014), hrswk: 20, studentID: acID},{semesterID: RadGrad.semester.get("Spring", 2015), hrswk: 20, studentID: acID},{semesterID: RadGrad.semester.get("Fall", 2015), hrswk: 20, studentID: acID}
  ];

  let workInstanceIDs = _.map(workInstanceData, RadGrad.workinstance.define);

  let courseInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics111", verified: true, grade: "A", studentID: acID, credithrs : 4},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics141", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: true, grade: "B", studentID: acID},

    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics211", verified: true, grade: "A",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics241", verified: true, grade: "B",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: true, grade: "A",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: true,  grade: "A",studentID: acID},

    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics212", verified: true, grade: "B",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics311", verified: true, grade: "B",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics314", verified: true, grade: "A",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: true, grade: "A",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: true, grade: "A",studentID: acID},


  ];

  let courseInstanceIDs = _.map(courseInstanceData, RadGrad.courseinstance.define);

  let opportunityInstanceData = [

    {semesterID: RadGrad.semester.get("Fall", 2015), opportunity: "bil-lab", verified: true, hrswk: 1, studentID: acID}


  ];

  let opportunityInstanceIDs = _.map(opportunityInstanceData, RadGrad.opportunityinstance.define);

  let degreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: courseInstanceIDs,
    opportunityInstanceIDs: opportunityInstanceIDs,
    workInstanceIDs: workInstanceIDs,
    studentID: acID
  });

  RadGrad.user.setDegreePlanID(acID, degreePlan);
  RadGrad.user.setDegreeGoalIDs(acID,
      [RadGrad.slug.getEntityID("bioinformatics-developer", "DegreeGoal") ]);
  //RadGrad.slug.getEntityID("ba-cs-it", "DegreeGoal")
  //RadGrad.slug.getEntityID("bs-cs", "DegreeGoal")
  RadGrad.user.setInterestTagIDs(acID,
      [RadGrad.slug.getEntityID("atom", "Tag"),
        RadGrad.slug.getEntityID("eclipse", "Tag"),
        RadGrad.slug.getEntityID("nursing", "Tag"),
        RadGrad.slug.getEntityID("oceanography", "Tag"),
        RadGrad.slug.getEntityID("natural-resources", "Tag"),
        RadGrad.slug.getEntityID("python", "Tag"),
        RadGrad.slug.getEntityID("medicine", "Tag"),
        RadGrad.slug.getEntityID("dynamic-programming", "Tag"),
        RadGrad.slug.getEntityID("hawaii", "Tag"),
        RadGrad.slug.getEntityID("asia", "Tag"),
        RadGrad.slug.getEntityID("hadoop", "Tag"),
        RadGrad.slug.getEntityID("mapreduce", "Tag"),
        RadGrad.slug.getEntityID("bioinformatics", "Tag"),
        RadGrad.slug.getEntityID("africa", "Tag"),
        RadGrad.slug.getEntityID("osx", "Tag"),
        RadGrad.slug.getEntityID("chemistry", "Tag"),
        RadGrad.slug.getEntityID("animal-sciences", "Tag"),
        RadGrad.slug.getEntityID("medical-informatics", "Tag"),
        RadGrad.slug.getEntityID("anthropology", "Tag"),
        RadGrad.slug.getEntityID("agriculture", "Tag"),
        RadGrad.slug.getEntityID("biology", "Tag"),
        RadGrad.slug.getEntityID("botany", "Tag")]);

  RadGrad.user.setPicture(acID, "https://eclastudentshowcase.files.wordpress.com/2010/03/evan-rhoda-headshot.jpg");
  RadGrad.user.setAboutMe(acID, "I've taken a few ICS courses already and find the computer science field to be extremley interesting.  I've always had a passion for Biology and the study of living things so I intend to pursue this as a minor while I follow the bioinformatics track.  Hopefully I will find a good job here in Hawaii once I graduate.");
  RadGrad.user.setSemesterID(acID, RadGrad.semester.get("Spring", 2018));
};
