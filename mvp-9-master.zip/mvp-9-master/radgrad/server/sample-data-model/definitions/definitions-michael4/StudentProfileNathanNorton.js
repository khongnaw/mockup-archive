/**
 * Created by mike on 1/27/2016.
 */

defineStudentProfileNathanNorton = function() {
  let acID = RadGrad.user.findBySlug("nathannorton")._id;

  let workInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2014), hrswk: 20, studentID: acID},
    {semesterID: RadGrad.semester.get("Summer", 2015), hrswk: 40, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), hrswk: 20, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), hrswk: 20, studentID: acID},
  ];

  let workInstanceIDs = _.map(workInstanceData, RadGrad.workinstance.define);

  let courseInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: true, grade: "A", studentID: acID, credithrs : 4},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: true, grade: "B", studentID: acID},

    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ee160", verified: true, grade: "A",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: true, grade: "A",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth1xx", verified: true, grade: "A",studentID: acID,credithrs : 4},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth1xx", verified: true, grade: "A",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth1xx", verified: true,  grade: "A",studentID: acID},

    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee211", verified: true, grade: "A",studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee260", verified: true, grade: "B",studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: true, grade: "A",studentID: acID,credithrs : 4},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: true, grade: "B",studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee296", verified: true,  grade: "A",studentID: acID},

    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee213", verified: true, grade: "A",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee205", verified: true, grade: "B",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth2xx", verified: true, grade: "A",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth2xx", verified: true, grade: "B",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth2xx", verified: true,  grade: "A",studentID: acID},

    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee324", verified: true, grade: "A",studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee371", verified: true, grade: "B",studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee361", verified: true, grade: "B",studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee396", verified: true, grade: "B",studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics141", verified: true,  grade: "B",studentID: acID}



  ];

  let courseInstanceIDs = _.map(courseInstanceData, RadGrad.courseinstance.define);

  let opportunityInstanceData = [

    {semesterID: RadGrad.semester.get("Fall", 2014), opportunity: "ieee-manoa", verified: true, hrswk: 1, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), opportunity: "ieee-manoa", verified: true, hrswk: 1, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), opportunity: "ieee-manoa", verified: true, hrswk: 1, studentID: acID}


  ];

  let opportunityInstanceIDs = _.map(opportunityInstanceData, RadGrad.opportunityinstance.define);

  let degreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: courseInstanceIDs,
    opportunityInstanceIDs: opportunityInstanceIDs,
    workInstanceIDs: workInstanceIDs,
    studentID: acID
  });

  RadGrad.user.setDegreePlanID(acID, degreePlan);
  RadGrad.user.setDegreeGoalIDs(acID,
      [RadGrad.slug.getEntityID("user-experience-designer", "DegreeGoal"), RadGrad.slug.getEntityID("computer-system-engineer", "DegreeGoal")/*, RadGrad.slug.getEntityID("bs-ce", "DegreeGoal") */]);
  //RadGrad.slug.getEntityID("ba-cs-it", "DegreeGoal")
  //RadGrad.slug.getEntityID("bs-cs", "DegreeGoal")
  RadGrad.user.setInterestTagIDs(acID,
      [RadGrad.slug.getEntityID("robotics", "Tag"),
        RadGrad.slug.getEntityID("theory-of-computation", "Tag"),
        RadGrad.slug.getEntityID("communications", "Tag"),
        RadGrad.slug.getEntityID("europe", "Tag"),
        RadGrad.slug.getEntityID("osx", "Tag"),
        RadGrad.slug.getEntityID("c", "Tag"),
        RadGrad.slug.getEntityID("computer-graphics", "Tag"),
        RadGrad.slug.getEntityID("ios", "Tag"),
        RadGrad.slug.getEntityID("canada", "Tag"),
        RadGrad.slug.getEntityID("git", "Tag"),
        RadGrad.slug.getEntityID("human-computer-interaction", "Tag"),
        RadGrad.slug.getEntityID("arduino", "Tag"),
        RadGrad.slug.getEntityID("engineering", "Tag"),
        RadGrad.slug.getEntityID("aerospace", "Tag"),
        RadGrad.slug.getEntityID("software-engineering", "Tag"),
        RadGrad.slug.getEntityID("artificial-intelligence", "Tag")]);

  RadGrad.user.setPicture(acID, "http://srkheadshotday.com/wp-content/uploads/Sam_Mercer_Q4108_Crop32.jpg");
  RadGrad.user.setAboutMe(acID, "This is my last semester at UH in the computer engineering program and I already plan to follow up on with a master's degree at a school in the mainland.  I'm fascinated working with virtual reality systems and hope to one day be a devloper in this field.");
  RadGrad.user.setSemesterID(acID, RadGrad.semester.get("Spring", 2016));
};
