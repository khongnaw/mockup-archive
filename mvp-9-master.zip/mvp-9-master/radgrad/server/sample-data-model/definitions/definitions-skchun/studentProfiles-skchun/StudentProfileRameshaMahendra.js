defineStudentProfileRameshaMahendra = function() {
  let acID = RadGrad.user.findBySlug("rameshamahendra")._id;

  let rameshaMahendraWorkInstanceData = [
    {semesterID: RadGrad.semester.get("Summer", 2017), hrswk: 40, studentID: acID},
  ];

  let rameshaMahendraWorkInstanceIDs = _.map(rameshaMahendraWorkInstanceData, RadGrad.workinstance.define);

  let rameshaMahendraCourseInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth2xx", verified: true, grade: "A", studentID: acID, note: ""},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth1xx", verified: true, grade: "A", studentID: acID, note: ""},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth1xx", verified: true, grade: "A", studentID: acID, note: ""},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth1xx", verified: true, grade: "A", studentID: acID, note: ""},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth1xx", verified: true, grade: "A", studentID: acID, note: ""},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee160", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Summer", 2016), course: "oth1xx", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Summer", 2016), course: "oth1xx", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2017), course: "ee211", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2017), course: "ee260", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2017), course: "ee296", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2017), course: "oth2xx", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2017), course: "oth2xx", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2017), course: "oth2xx", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2017), course: "ee213", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2017), course: "ee205", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2017), course: "oth2xx", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2017), course: "oth2xx", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2017), course: "oth2xx", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2018), course: "ee324", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2018), course: "ee371", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2018), course: "ee361", verified: false, studentID: acID},
    //{semesterID: RadGrad.semester.get("Fall", 2018), course: "ee361l", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2018), course: "ee396", verified: false, studentID: acID},
    //{semesterID: RadGrad.semester.get("Fall", 2018), course: "ee362", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2018), course: "ee315", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2018), course: "ee323", verified: false, studentID: acID},
    //{semesterID: RadGrad.semester.get("Spring", 2018), course: "ee323l", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2018), course: "ee367", verified: false, studentID: acID},
    //{semesterID: RadGrad.semester.get("Spring", 2018), course: "ee367l", verified: false, studentID: acID},
    //{semesterID: RadGrad.semester.get("Spring", 2018), course: "ee406", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Summer", 2018), course: "oth3xx", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Summer", 2018), course: "oth3xx", verified: false, studentID: acID},
    ];

  let rameshaMahendraCourseInstanceIDs = _.map(rameshaMahendraCourseInstanceData, RadGrad.courseinstance.define);

  let rameshaMahendraOpportunityInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2016), opportunity: "ieee-manoa", verified: true, hrswk: 10, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), opportunity: "ieee-manoa", verified: true, hrswk: 10, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2017), opportunity: "ieee-manoa", verified: false, hrswk: 10, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2017), opportunity: "ieee-manoa", verified: false, hrswk: 10, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2018), opportunity: "ieee-manoa", verified: false, hrswk: 10, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2018), opportunity: "ieee-manoa", verified: false, hrswk: 10, studentID: acID},
    //{semesterID: RadGrad.semester.get("Spring", 2018), opportunity: "mll", verified: false, hrswk: 10, studentID: acID},
    {semesterID: RadGrad.semester.get("Summer", 2017), opportunity: "summer-intern", verified: false, hrswk: 10, studentID: acID},
  ];

  let rameshaMahendraOpportunityInstanceIDs = _.map(rameshaMahendraOpportunityInstanceData, RadGrad.opportunityinstance.define);

  let rameshaMahendraDegreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: rameshaMahendraCourseInstanceIDs,
    opportunityInstanceIDs: rameshaMahendraOpportunityInstanceIDs,
    workInstanceIDs: rameshaMahendraWorkInstanceIDs,
    studentID: acID
  });

  RadGrad.user.setDegreePlanID(acID, rameshaMahendraDegreePlan);
  RadGrad.user.setDegreeGoalIDs(acID, [RadGrad.slug.getEntityID("computer-system-engineer", "DegreeGoal")]);
  RadGrad.user.setInterestTagIDs(acID, [RadGrad.slug.getEntityID("machine-learning", "Tag"), RadGrad.slug.getEntityID("python", "Tag"), RadGrad.slug.getEntityID("network-security", "Tag"), RadGrad.slug.getEntityID("cryptography", "Tag"), RadGrad.slug.getEntityID("medical-informatics", "Tag")]);
  RadGrad.user.setPicture(acID, "https://pbs.twimg.com/profile_images/2884445307/df2e85d6f7ebee84470c804e9da09444_400x400.jpeg");
  RadGrad.user.setAboutMe(acID, "I am a freshman in CEng and am interested in information systems, specifically machine learning.  I have planned out my next two years of studies.");
  RadGrad.user.setSemesterID(acID, RadGrad.semester.get("Spring", 2019));

};

