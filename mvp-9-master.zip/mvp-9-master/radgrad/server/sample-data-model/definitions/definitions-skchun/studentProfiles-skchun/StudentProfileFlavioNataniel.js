defineStudentProfileFlavioNataniel = function() {
  let acID = RadGrad.user.findBySlug("flavionataniel")._id;

  let flavioNatanielWorkInstanceData = [

  ];

  let flavioNatanielWorkInstanceIDs = _.map(flavioNatanielWorkInstanceData, RadGrad.workinstance.define);

  let flavioNatanielCourseInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth1xx", verified: true, grade: "A", studentID: acID, note: ""},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth1xx", verified: true, grade: "B", studentID: acID, note: ""},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth2xx", verified: true, grade: "C", studentID: acID, note: ""},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth1xx", verified: true, grade: "C", studentID: acID, note: ""},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth1xx", verified: true, grade: "B", studentID: acID, note: ""},
  ];

  let flavioNatanielCourseInstanceIDs = _.map(flavioNatanielCourseInstanceData, RadGrad.courseinstance.define);

  let flavioNatanielOpportunityInstanceData = [
  ];

  let flavioNatanielOpportunityInstanceIDs = _.map(flavioNatanielOpportunityInstanceData, RadGrad.opportunityinstance.define);

  let flavioNatanielDegreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: flavioNatanielCourseInstanceIDs,
    opportunityInstanceIDs: flavioNatanielOpportunityInstanceIDs,
    workInstanceIDs: flavioNatanielWorkInstanceIDs,
    studentID: acID
  });

  RadGrad.user.setDegreePlanID(acID, flavioNatanielDegreePlan);
  //RadGrad.user.setDegreeGoalIDs(acID, [RadGrad.slug.getEntityID("", "DegreeGoal")]);
  RadGrad.user.setInterestTagIDs(acID, [RadGrad.slug.getEntityID("web-design", "Tag"), RadGrad.slug.getEntityID("english", "Tag")], RadGrad.slug.getEntityID("dance", "Tag"));
  RadGrad.user.setPicture(acID, "http://www.stcharlessingers.com/xm_client/client_images/Nathaniel-Adams---Headshot-for-web.jpg");
  RadGrad.user.setAboutMe(acID, "I am a freshman and have just declared as an ICS major.  I might go into web development.");
  RadGrad.user.setSemesterID(acID, RadGrad.semester.get("Spring", 2019));
};

