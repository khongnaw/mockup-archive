defineStudentProfileMonicaLilly = function() {
  let acID = RadGrad.user.findBySlug("monicalilly")._id;

  let monicaLillyWorkInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2013), hrswk: 10, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2013), hrswk: 10, studentID: acID},
    {semesterID: RadGrad.semester.get("Summer", 2013), hrswk: 40, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), hrswk: 10, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), hrswk: 10, studentID: acID},
    {semesterID: RadGrad.semester.get("Summer", 2014), hrswk: 40, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), hrswk: 10, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), hrswk: 10, studentID: acID},
    {semesterID: RadGrad.semester.get("Summer", 2015), hrswk: 40, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2016), hrswk: 10, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), hrswk: 10, studentID: acID},
  ];

  let monicaLillyWorkInstanceIDs = _.map(monicaLillyWorkInstanceData, RadGrad.workinstance.define);

  let monicaLillyCourseInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "A", studentID: acID, note: ""},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: true, grade: "A", studentID: acID, note: ""},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: true, grade: "A", studentID: acID, note: ""},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: true, grade: "A", studentID: acID, note: ""},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: true, grade: "A", studentID: acID, note: ""},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "ee160", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth1xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth1xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth1xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth2xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee211", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee260", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee296", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ee213", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ee205", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee324", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee371", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee361", verified: true, grade: "A", studentID: acID},
    //{semesterID: RadGrad.semester.get("Fall", 2015), course: "ee361l", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee396", verified: true, grade: "A", studentID: acID},
    //{semesterID: RadGrad.semester.get("Fall", 2015), course: "ee362", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee315", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee323", verified: false, grade: "B", studentID: acID},
    //{semesterID: RadGrad.semester.get("Spring", 2015), course: "ee323l", verified: false, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee367", verified: true, grade: "B", studentID: acID},
    //{semesterID: RadGrad.semester.get("Spring", 2015), course: "ee367l", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee342", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ee468", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth3xx", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth2xx", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth2xx", verified: true, grade: "B", studentID: acID},
    //{semesterID: RadGrad.semester.get("Fall", 2016), course: "ee344", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee496", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee495", verified: false, studentID: acID},
    //{semesterID: RadGrad.semester.get("Spring", 2016), course: "ee449", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth3xx", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: acID},
  ];

  let monicaLillyCourseInstanceIDs = _.map(monicaLillyCourseInstanceData, RadGrad.courseinstance.define);

  let monicaLillyOpportunityInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2013), opportunity: "ieee-manoa", verified: true, hrswk: 10, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2013), opportunity: "ieee-manoa", verified: true, hrswk: 10, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), opportunity: "ieee-manoa", verified: true, hrswk: 10, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), opportunity: "ieee-manoa", verified: true, hrswk: 10, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), opportunity: "ieee-manoa", verified: true, hrswk: 10, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), opportunity: "ieee-manoa", verified: true, hrswk: 10, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2016), opportunity: "ieee-manoa", verified: true, hrswk: 10, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), opportunity: "ieee-manoa", verified: false, hrswk: 10, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2016), opportunity: "global-game-jam", verified: true, hrswk: 10, studentID: acID},
  ];

  let monicaLillyOpportunityInstanceIDs = _.map(monicaLillyOpportunityInstanceData, RadGrad.opportunityinstance.define);

  let monicaLillyDegreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: monicaLillyCourseInstanceIDs,
    opportunityInstanceIDs: monicaLillyOpportunityInstanceIDs,
    workInstanceIDs: monicaLillyWorkInstanceIDs,
    studentID: acID
  });

  RadGrad.user.setDegreePlanID(acID, monicaLillyDegreePlan);
  RadGrad.user.setDegreeGoalIDs(acID,[
      //RadGrad.slug.getEntityID("graduate-school", "DegreeGoal"),
      RadGrad.slug.getEntityID("data-scientist", "DegreeGoal"),
    //RadGrad.slug.getEntityID("honors-degree", "DegreeGoal")
  ]);
  RadGrad.user.setInterestTagIDs(acID, [RadGrad.slug.getEntityID("data-science", "Tag"), RadGrad.slug.getEntityID("hadoop", "Tag")], RadGrad.slug.getEntityID("mapreduce", "Tag"), RadGrad.slug.getEntityID("r", "Tag"), RadGrad.slug.getEntityID("matlab", "Tag"));
  RadGrad.user.setPicture(acID, "https://pbs.twimg.com/profile_images/671684679242661889/SdG3gv4P.jpg");
  RadGrad.user.setAboutMe(acID, "I am a senior in CEng interested in efficiently manipulating data. I plan to get my masters.");
  RadGrad.user.setSemesterID(acID, RadGrad.semester.get("Spring", 2016));

};

