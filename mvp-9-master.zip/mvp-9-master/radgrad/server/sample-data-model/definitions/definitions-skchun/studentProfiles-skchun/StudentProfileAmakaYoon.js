defineStudentProfileAmakaYoon = function() {
let acID = RadGrad.user.findBySlug("amakayoon")._id;

  let amakaYoonWorkInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2013), hrswk: 20, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2013), hrswk: 20, studentID: acID},
    {semesterID: RadGrad.semester.get("Summer", 2013), hrswk: 40, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), hrswk: 20, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), hrswk: 20, studentID: acID},
    {semesterID: RadGrad.semester.get("Summer", 2014), hrswk: 40, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), hrswk: 20, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), hrswk: 20, studentID: acID},
    {semesterID: RadGrad.semester.get("Summer", 2015), hrswk: 40, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2016), hrswk: 20, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), hrswk: 20, studentID: acID},
  ];

  let amakaYoonWorkInstanceIDs = _.map(amakaYoonWorkInstanceData, RadGrad.workinstance.define);

  let amakaYoonCourseInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "B", studentID: acID, note: ""},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: true, grade: "B", studentID: acID, note: ""},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: true, grade: "B", studentID: acID, note: ""},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: true, grade: "B", studentID: acID, note: ""},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: true, grade: "B", studentID: acID, note: ""},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "ee160", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth1xx", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth1xx", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth1xx", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth2xx", verified: true, grade: "C", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee211", verified: true, grade: "C", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee260", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee296", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ee213", verified: true, grade: "C", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ee205", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Summer", 2014), course: "oth1xx", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee324", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee371", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee361", verified: true, grade: "B", studentID: acID},
    //{semesterID: RadGrad.semester.get("Fall", 2015), course: "ee361l", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee396", verified: true, grade: "A", studentID: acID},
    //{semesterID: RadGrad.semester.get("Fall", 2015), course: "ee362", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee315", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee323", verified: true, grade: "C", studentID: acID},
    //{semesterID: RadGrad.semester.get("Spring", 2015), course: "ee323l", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee367", verified: true, grade: "B", studentID: acID},
    //{semesterID: RadGrad.semester.get("Spring", 2015), course: "ee367l", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee342", verified: true, grade: "C", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ee468", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth2xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth3xx", verified: true, grade: "C", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth2xx", verified: true, grade: "B", studentID: acID},
    //{semesterID: RadGrad.semester.get("Fall", 2016), course: "ee455", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee496", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee495", verified: false, studentID: acID},
    //{semesterID: RadGrad.semester.get("Spring", 2016), course: "ee449", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth3xx", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: false, studentID: acID},

  ];

  let amakaYoonCourseInstanceIDs = _.map(amakaYoonCourseInstanceData, RadGrad.courseinstance.define);

  let amakaYoonOpportunityInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2013), opportunity: "ieee-manoa", verified: true, hrswk: 10, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2013), opportunity: "ieee-manoa", verified: true, hrswk: 10, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), opportunity: "ieee-manoa", verified: true, hrswk: 10, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), opportunity: "ieee-manoa", verified: true, hrswk: 10, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), opportunity: "ieee-manoa", verified: true, hrswk: 10, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), opportunity: "ieee-manoa", verified: true, hrswk: 10, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2016), opportunity: "ieee-manoa", verified: true, hrswk: 10, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), opportunity: "ieee-manoa", verified: false, hrswk: 10, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2016), opportunity: "corg", verified: true, hrswk: 10, studentID: acID},

  ];

  let amakaYoonOpportunityInstanceIDs = _.map(amakaYoonOpportunityInstanceData, RadGrad.opportunityinstance.define);

  let amakaYoonDegreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: amakaYoonCourseInstanceIDs,
    opportunityInstanceIDs: amakaYoonOpportunityInstanceIDs,
    workInstanceIDs: amakaYoonWorkInstanceIDs,
    studentID: acID
  });

  RadGrad.user.setDegreePlanID(acID, amakaYoonDegreePlan);
  RadGrad.user.setDegreeGoalIDs(acID, [RadGrad.slug.getEntityID("database-administrator", "DegreeGoal")]);
  RadGrad.user.setInterestTagIDs(acID, [RadGrad.slug.getEntityID("high-performance-programming", "Tag"), RadGrad.slug.getEntityID("parallel-programming", "Tag")], RadGrad.slug.getEntityID("data-science", "Tag"), RadGrad.slug.getEntityID("database", "Tag"), RadGrad.slug.getEntityID("sql", "Tag"));
  RadGrad.user.setPicture(acID, "https://pbs.twimg.com/profile_images/1600366392/Yoon_Ah.jpg");
  RadGrad.user.setAboutMe(acID, "I'm a senior in CEng interested in high performance computing and data storage.");
  RadGrad.user.setSemesterID(acID, RadGrad.semester.get("Spring", 2016));
};

