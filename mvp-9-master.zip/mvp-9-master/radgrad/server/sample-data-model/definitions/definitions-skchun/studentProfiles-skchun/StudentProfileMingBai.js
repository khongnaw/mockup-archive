defineStudentProfileMingBai = function() {
  let acID = RadGrad.user.findBySlug("mingbai")._id;

  let mingBaiWorkInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2013), hrswk: 25, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2013), hrswk: 25, studentID: acID},
    {semesterID: RadGrad.semester.get("Summer", 2013), hrswk: 25, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), hrswk: 25, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), hrswk: 25, studentID: acID},
    {semesterID: RadGrad.semester.get("Summer", 2014), hrswk: 25, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), hrswk: 25, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), hrswk: 25, studentID: acID},
    {semesterID: RadGrad.semester.get("Summer", 2015), hrswk: 40, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2016), hrswk: 25, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), hrswk: 10, studentID: acID},
  ];

  let mingBaiWorkInstanceIDs = _.map(mingBaiWorkInstanceData, RadGrad.workinstance.define);

  let mingBaiCourseInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "A", studentID: acID, note: ""},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: true, grade: "A", studentID: acID, note: ""},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: true, grade: "A", studentID: acID, note: ""},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: true, grade: "A", studentID: acID, note: ""},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: true, grade: "A", studentID: acID, note: ""},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "ee160", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth1xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth1xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth1xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth2xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Summer", 2013), course: "oth2xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Summer", 2013), course: "oth2xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee211", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee260", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee296", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ee213", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ee205", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: true, grade: "C", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Summer", 2014), course: "oth2xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Summer", 2014), course: "oth2xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee324", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee371", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee361", verified: true, grade: "A", studentID: acID},
    //{semesterID: RadGrad.semester.get("Fall", 2015), course: "ee361l", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ee396", verified: true, grade: "A", studentID: acID},
    //{semesterID: RadGrad.semester.get("Fall", 2016), course: "ee362", verified: true, grade: "C", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee315", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee323", verified: false, grade: "B", studentID: acID},
    //{semesterID: RadGrad.semester.get("Spring", 2016), course: "ee323l", verified: false, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee367", verified: true, grade: "B", studentID: acID},
    //{semesterID: RadGrad.semester.get("Spring", 2015), course: "ee367l", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee342", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ee468", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ics314", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth2xx", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee496", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee495", verified: false, studentID: acID},

  ];

  let mingBaiCourseInstanceIDs = _.map(mingBaiCourseInstanceData, RadGrad.courseinstance.define);

  let mingBaiOpportunityInstanceData = [

  ];

  let mingBaiOpportunityInstanceIDs = _.map(mingBaiOpportunityInstanceData, RadGrad.opportunityinstance.define);

  let mingBaiDegreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: mingBaiCourseInstanceIDs,
    opportunityInstanceIDs: mingBaiOpportunityInstanceIDs,
    workInstanceIDs: mingBaiWorkInstanceIDs,
    studentID: acID
  });

  RadGrad.user.setDegreePlanID(acID, mingBaiDegreePlan);
  RadGrad.user.setDegreeGoalIDs(acID, [RadGrad.slug.getEntityID("bs-ce", "DegreeGoal"),RadGrad.slug.getEntityID("data-scientist", "DegreeGoal"),RadGrad.slug.getEntityID("information-security-analyst", "DegreeGoal"),RadGrad.slug.getEntityID("business-intelligence-analyst", "DegreeGoal")]);
  RadGrad.user.setInterestTagIDs(acID, [RadGrad.slug.getEntityID("python", "Tag"), RadGrad.slug.getEntityID("algorithms", "Tag")], RadGrad.slug.getEntityID("network-security", "Tag"), RadGrad.slug.getEntityID("data-science", "Tag"));
  RadGrad.user.setPicture(acID, "http://mvascientificconsultants.com/wp-content/uploads/2015/02/ming-zhou101915.jpg");
  RadGrad.user.setAboutMe(acID, "I am a senior in CEng and interested in applying algorithms to solve problems.");
  RadGrad.user.setSemesterID(acID, RadGrad.semester.get("Spring", 2016));

};

