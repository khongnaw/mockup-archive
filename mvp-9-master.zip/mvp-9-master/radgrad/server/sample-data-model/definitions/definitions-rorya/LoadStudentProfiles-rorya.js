defineStudentProfilesRorya = function () {
    defineStudentProfileJontyMilburn();
    defineStudentProfileRoyAnderson();
    defineStudentProfileFlanaganDanell();
    defineStudentProfileNormanTaylor();
    defineStudentProfileMiricaFitzroy();
    defineStudentProfileAnastaciaMorrison();
    defineStudentProfileMarkYukimura();
    defineStudentProfileTinaWong();
};
