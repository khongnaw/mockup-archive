/**
 * Created by Rory on 1/27/2016.
 */
defineStudentProfileMarkYukimura = function() {
  let acID = RadGrad.user.findBySlug("markyukimura")._id;

  let sampleWorkInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2015), hrswk: 20, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), hrswk: 15, studentID: acID}
  ];

  let sampleWorkInstanceIDs = _.map(sampleWorkInstanceData, RadGrad.workinstance.define);

  let sampleCourseInstanceData = [
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ics111", verified: false, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ics141", verified: false, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth1xx", verified: false, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth2xx", verified: false, grade: "B", studentID: acID, credithrs: 4},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth1xx", verified: false, grade: "B", studentID: acID},

    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics211", verified: false, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics241", verified: false, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: false, grade: "C", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: false, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: false, grade: "B", studentID: acID},

    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics314", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics332", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth3xx", verified: false, studentID: acID}
  ];

  let sampleCourseInstanceIDs = _.map(sampleCourseInstanceData, RadGrad.courseinstance.define);

  let sampleOpportunityInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2015), opportunity: "global-game-jam", verified: true, studentID: acID}
  ];

  let sampleOpportunityInstanceIDs = _.map(sampleOpportunityInstanceData, RadGrad.opportunityinstance.define);

  let sampleDegreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: sampleCourseInstanceIDs,
    opportunityInstanceIDs: sampleOpportunityInstanceIDs,
    workInstanceIDs: sampleWorkInstanceIDs,
    studentID: acID
  });

  RadGrad.user.setDegreePlanID(acID, sampleDegreePlan);
  RadGrad.user.setDegreeGoalIDs(acID,
    [
      RadGrad.slug.getEntityID("game-designer", "DegreeGoal"),
      RadGrad.slug.getEntityID("ba-ics", "DegreeGoal")
    ]);
  RadGrad.user.setInterestTagIDs(acID,
    [
      RadGrad.slug.getEntityID("game-design", "Tag"),
      RadGrad.slug.getEntityID("software-engineering", "Tag"),
      RadGrad.slug.getEntityID("west-us", "Tag"),
      RadGrad.slug.getEntityID("artificial-intelligence", "Tag"),
      RadGrad.slug.getEntityID("windows", "Tag"),
      RadGrad.slug.getEntityID("unity", "Tag"),
      RadGrad.slug.getEntityID("human-computer-interaction", "Tag"),
      RadGrad.slug.getEntityID("c", "Tag"),
      RadGrad.slug.getEntityID("cplusplus", "Tag"),
      RadGrad.slug.getEntityID("git", "Tag"),
      RadGrad.slug.getEntityID("computer-graphics", "Tag")
    ]);
  RadGrad.user.setPicture(acID, "https://pixabay.com/static/uploads/photo/2014/11/19/10/52/man-537136_960_720.jpg");
  RadGrad.user.setAboutMe(acID, "I have played games all my life and because of that I want to be a game-designer.");
  RadGrad.user.setSemesterID(acID, RadGrad.semester.get("Spring", 2018));
};

