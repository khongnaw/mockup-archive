/**
 * Created by Rory on 1/27/2016.
 */
defineStudentProfileFlanaganDanell = function() {
  let acID = RadGrad.user.findBySlug("flanagandanell")._id;

  let sampleWorkInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2014), hrswk: 20, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), hrswk: 20, studentID: acID}
  ];

  let sampleWorkInstanceIDs = _.map(sampleWorkInstanceData, RadGrad.workinstance.define);

  let sampleCourseInstanceData = [
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "ics111", verified: false, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "ics141", verified: false, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth1xx", verified: false, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth1xx", verified: false, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth1xx", verified: false, grade: "A", studentID: acID, credithrs: 1},

    {semesterID: RadGrad.semester.get("Fall", 2013), course: "ics211", verified: false, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "ics241", verified: false, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: false, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: false, grade: "A", studentID: acID, credithrs: 1},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: false, grade: "A", studentID: acID},

    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ics311", verified: false, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ics312", verified: false, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ics351", verified: false, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth1xx", verified: false, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth1xx", verified: false, grade: "A", studentID: acID, credithrs: 1},

    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ics313", verified: false, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ics314", verified: false, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ics355", verified: false, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: false, grade: "C", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: false, grade: "B", studentID: acID, credithrs: 1},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth1xx", verified: false, grade: "B", studentID: acID},

    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ics321", verified: false, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ics332", verified: false, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ics423", verified: false, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth1xx", verified: false, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth1xx", verified: false, grade: "B", studentID: acID},

    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics451", verified: false, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics425", verified: false, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics426", verified: false, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: false, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: false, grade: "A", studentID: acID},

    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics455", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics471", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: acID}
  ];

  let sampleCourseInstanceIDs = _.map(sampleCourseInstanceData, RadGrad.courseinstance.define);

  let sampleOpportunityInstanceData = [
    {semesterID: RadGrad.semester.get("Spring", 2015), opportunity: "acm-manoa", verified: true, hrswk: 10, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), opportunity: "hicapacity", verified: true, hrswk: 10, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), opportunity: "acm-manoa", verified: true, hrswk: 15, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), opportunity: "acm-manoa", verified: true, hrswk: 12, studentID: acID}
  ];

  let sampleOpportunityInstanceIDs = _.map(sampleOpportunityInstanceData, RadGrad.opportunityinstance.define);

  let sampleDegreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: sampleCourseInstanceIDs,
    opportunityInstanceIDs: sampleOpportunityInstanceIDs,
    workInstanceIDs: sampleWorkInstanceIDs,
    studentID: acID
  });

  RadGrad.user.setDegreePlanID(acID, sampleDegreePlan);
  RadGrad.user.setDegreeGoalIDs(acID,
    [
      RadGrad.slug.getEntityID("network-engineer", "DegreeGoal"),
      RadGrad.slug.getEntityID("bs-cs", "DegreeGoal")
    ]);
  RadGrad.user.setInterestTagIDs(acID,
    [
      RadGrad.slug.getEntityID("database", "Tag"),
      RadGrad.slug.getEntityID("cryptography", "Tag"),
      RadGrad.slug.getEntityID("west-us", "Tag"),
      RadGrad.slug.getEntityID("computer-security", "Tag"),
      RadGrad.slug.getEntityID("network-security", "Tag"),
      RadGrad.slug.getEntityID("network-design", "Tag"),
      RadGrad.slug.getEntityID("wireless-networks", "Tag"),
      RadGrad.slug.getEntityID("linux", "Tag")
    ]);
  RadGrad.user.setPicture(acID, "https://pixabay.com/static/uploads/photo/2014/11/21/12/13/man-540500_960_720.jpg");
  RadGrad.user.setAboutMe(acID, "I am a senior here at UH Manoa planning to graduate this semester. I'm mainly interested in networking but I also have an interest in general computer security and cryptography.");
  RadGrad.user.setSemesterID(acID, RadGrad.semester.get("Spring", 2016));
};

