/**
 * Created by Rory on 1/27/2016.
 */
defineStudentProfileJontyMilburn = function() {
  let acID = RadGrad.user.findBySlug("jontymilburn")._id;

  let sampleWorkInstanceData = [];

  let sampleWorkInstanceIDs = _.map(sampleWorkInstanceData, RadGrad.workinstance.define);

  let sampleCourseInstanceData = [];

  let sampleCourseInstanceIDs = _.map(sampleCourseInstanceData, RadGrad.courseinstance.define);

  let sampleOpportunityInstanceData = [];

  let sampleOpportunityInstanceIDs = _.map(sampleOpportunityInstanceData, RadGrad.opportunityinstance.define);

  let sampleDegreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: sampleCourseInstanceIDs,
    opportunityInstanceIDs: sampleOpportunityInstanceIDs,
    workInstanceIDs: sampleWorkInstanceIDs,
    studentID: acID
  });

  RadGrad.user.setDegreePlanID(acID, sampleDegreePlan);
  RadGrad.user.setInterestTagIDs(acID, [RadGrad.slug.getEntityID("web-design", "Tag")]);
  RadGrad.user.setPicture(acID, "https://pixabay.com/static/uploads/photo/2015/10/01/09/28/people-966755_960_720.jpg");
  RadGrad.user.setAboutMe(acID, "I am a freshman interested in majoring in ICS. I'm not sure exactly what I want to do yet so for now I'm going to take the core classes and see what I like.");
  RadGrad.user.setSemesterID(acID, RadGrad.semester.get("Fall", 2019));
};

