/**
 * Created by sora on 1/26/16.
 */
defineStudentProfileKelvinDawson = function() {
    let acID = RadGrad.user.findBySlug("kevindawson")._id;

    let sampleWorkInstanceData = [
        {semesterID: RadGrad.semester.get("Summer", 2014), hrswk: 35, studentID: acID},
        {semesterID: RadGrad.semester.get("Summer", 2015), hrswk: 25, studentID: acID}
    ];

    let sampleWorkInstanceIDs = _.map(sampleWorkInstanceData, RadGrad.workinstance.define);

    let sampleCourseInstanceData = [
        {semesterID: RadGrad.semester.get("Fall", 2013), course: "ics111", verified: true, grade: "A+", studentID: acID, credithrs : 4},
        {semesterID: RadGrad.semester.get("Fall", 2013), course: "ics141", verified: true, grade: "A+", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "A", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "B", studentID: acID},

        {semesterID: RadGrad.semester.get("Spring", 2014), course: "ics211", verified: true, grade: "A+", studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2014), course: "ics212", verified: true, grade: "B", studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2014), course: "ics241", verified: true, grade: "A", studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: true, grade: "A", studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: true, grade: "A", studentID: acID},


        {semesterID: RadGrad.semester.get("Fall", 2014), course: "ics314", verified: true, grade: "A+", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2014), course: "ics321", verified: true, grade: "B", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: true, grade: "A", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: true, grade: "A", studentID: acID},

        {semesterID: RadGrad.semester.get("Spring", 2015), course: "ics332", verified: true, grade: "A", studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2015), course: "ics355", verified: true, grade: "B+", studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth2xx", verified: true, grade: "A-", studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth2xx", verified: true, grade: "A-", studentID: acID},


        {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics315", verified: true, grade: "A", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics423", verified: true, grade: "B", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: true, grade: "A", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: true, grade: "A", studentID: acID},

        {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics455", verified: true, grade: "A+", studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics414", verified: true, grade: "A+", studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: true, grade: "A", studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: true, grade: "B", studentID: acID},

        {semesterID: RadGrad.semester.get("Fall", 2016), course: "ics425", verified: true, grade: "A+", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth2xx", verified: true, grade: "A", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth2xx", verified: true, grade: "A", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth2xx", verified: true, grade: "B", studentID: acID},

        {semesterID: RadGrad.semester.get("Spring", 2017), course: "oth2xx", verified: false, studentID: acID}, // need ics491
        {semesterID: RadGrad.semester.get("Spring", 2017), course: "ics426", verified: false, studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2017), course: "oth2xx", verified: false, studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2017), course: "oth2xx", verified: false, studentID: acID}
    ];

    let sampleCourseInstanceIDs = _.map(sampleCourseInstanceData, RadGrad.courseinstance.define);

    let sampleOpportunityInstanceData = [
        {semesterID: RadGrad.semester.get("Spring", 2015), opportunity: "acm-manoa", verified: true, hrswk: 1, studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2015), opportunity: "acm-manoa", verified: true, hrswk: 1, studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2016), opportunity: "acm-manoa", verified: true, hrswk: 1, studentID: acID},
        {semesterID: RadGrad.semester.get("Summer", 2015), opportunity: "hichi", verified: true, hrswk: 1, studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2015), opportunity: "atthack16", verified: true, hrswk: 2, studentID: acID}
    ];

    let sampleOpportunityInstanceIDs = _.map(sampleOpportunityInstanceData, RadGrad.opportunityinstance.define);

    let sampleDegreePlan = RadGrad.degreeplan.define({
        courseInstanceIDs: sampleCourseInstanceIDs,
        opportunityInstanceIDs: sampleOpportunityInstanceIDs,
        workInstanceIDs: sampleWorkInstanceIDs,
        studentID: acID
    });

    RadGrad.user.setDegreePlanID(acID, sampleDegreePlan);
    RadGrad.user.setDegreeGoalIDs(acID,
        [RadGrad.slug.getEntityID("network-engineer", "DegreeGoal"),
            RadGrad.slug.getEntityID("information-security-analyst", "DegreeGoal"),
            RadGrad.slug.getEntityID("bs-cs", "DegreeGoal") ]);  //RadGrad.slug.getEntityID("cs-se-sci,", "DegreeGoal")
    //RadGrad.slug.getEntityID("bs-cs", "DegreeGoal") //RadGrad.slug.getEntityID("graduate-school,", "DegreeGoal")
    RadGrad.user.setInterestTagIDs(acID,
        [RadGrad.slug.getEntityID("mobile-devices", "Tag"),
            RadGrad.slug.getEntityID("network-security", "Tag"),
            RadGrad.slug.getEntityID("c", "Tag"),
            RadGrad.slug.getEntityID("cplusplus", "Tag"),
            RadGrad.slug.getEntityID("operating-systems", "Tag"),
            RadGrad.slug.getEntityID("computer-security", "Tag"),
            RadGrad.slug.getEntityID("network-design", "Tag")]);

    RadGrad.user.setPicture(acID, "https://upload.wikimedia.org/wikipedia/commons/e/ef/MarkZuckerberg.jpg");
    RadGrad.user.setAboutMe(acID, "I'm a senior in CS. My career goal is to do research in computer security. Currently I'm interested in developing secure policy/framework for mobile devices.");
    RadGrad.user.setSemesterID(acID, RadGrad.semester.get("Spring", 2017));
};
