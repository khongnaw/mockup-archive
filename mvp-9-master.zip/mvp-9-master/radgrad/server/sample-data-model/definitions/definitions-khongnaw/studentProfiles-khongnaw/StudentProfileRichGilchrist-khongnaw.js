/**
 * Created by sora on 1/26/16.
 */

defineStudentProfileRichGilchrist = function() {
    let acID = RadGrad.user.findBySlug("richgilchrist")._id;

    let sampleWorkInstanceData = [
        {semesterID: RadGrad.semester.get("Summer", 2016), hrswk: 20, studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2016), hrswk: 5, studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2017), hrswk: 12, studentID: acID}
    ];

    let sampleWorkInstanceIDs = _.map(sampleWorkInstanceData, RadGrad.workinstance.define);

    let sampleCourseInstanceData = [
        {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "A-", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "A", studentID: acID, credithrs : 4},
        {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "B", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "A", studentID: acID ,credithrs : 1},
        {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "B", studentID: acID},


        {semesterID: RadGrad.semester.get("Spring", 2014), course: "ee160", verified: true, grade: "A", studentID: acID, credithrs: 4},
        {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: true, grade: "A", studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: true, grade: "B", studentID: acID, credithrs : 4},
        {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: true, grade: "A", studentID: acID, credithrs : 2},
        {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: true, grade: "A", studentID: acID},

        {semesterID: RadGrad.semester.get("Summer", 2014), course: "oth2xx", verified: true, grade: "A+", studentID: acID},
        {semesterID: RadGrad.semester.get("Summer", 2014), course: "oth2xx", verified: true, grade: "B", studentID: acID},



        {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee211", verified: true, grade: "B+", studentID: acID, credithrs: 4},
        {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee260", verified: true, grade: "A-", studentID: acID, credithrs: 4},
        {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee296", verified: true, grade: "A", studentID: acID, credithrs: 1},
        {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: true, grade: "A+", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: true, grade: "B", studentID: acID},

        {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee213", verified: true, grade: "B+", studentID: acID, credithrs : 4},
        {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee205", verified: true, grade: "A+", studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth2xx", verified: true, grade: "A+", studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee396", verified: true, grade: "A+", studentID: acID, credithrs : 2},

        {semesterID: RadGrad.semester.get("Summer", 2015), course: "oth2xx", verified: true, grade: "A+", studentID: acID},

        {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee324", verified: true, grade: "B", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee371", verified: true, grade: "B", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee361", verified: true, grade: "A", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee315", verified: true, grade: "A-", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee496", verified: true, grade: "A", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: true, grade: "A", studentID: acID, credithrs : 1}, // need ee361l slugs




        {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee323", verified: true, grade: "B", studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: true, grade: "A", studentID: acID, credithrs : 1}, // need ee323l
        {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee367", verified: true, grade: "A", studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: true, grade: "A", studentID: acID, credithrs : 1}, // need ee367l
        {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee406", verified: true, grade: "A", studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee342", verified: true, grade: "A-", studentID: acID},

        {semesterID: RadGrad.semester.get("Summer", 2016), course: "oth2xx", verified: true, grade: "A+", studentID: acID},



        {semesterID: RadGrad.semester.get("Fall", 2016), course: "ee468", verified: true, grade: "A", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth2xx", verified: true, grade: "A", studentID: acID}, // need ee362
        {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth2xx", verified: true, grade: "A", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2016), course: "ics314", verified: true, grade: "A", studentID: acID},

        {semesterID: RadGrad.semester.get("Spring", 2017), course: "ics414", verified: false, studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2017), course: "ics432", verified: false, studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2017), course: "ee495", verified: false, studentID: acID, credithrs : 1}  // need ee495

    ];

    let sampleCourseInstanceIDs = _.map(sampleCourseInstanceData, RadGrad.courseinstance.define);

    let sampleOpportunityInstanceData = [
        {semesterID: RadGrad.semester.get("Fall", 2014), opportunity: "ieee-manoa", verified: true, hrswk: 1, studentID: acID},         // missing slugs
        {semesterID: RadGrad.semester.get("Spring", 2015), opportunity: "ieee-manoa", verified: true, hrswk: 1, studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2015), opportunity: "ieee-manoa", verified: true, hrswk: 1, studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2016), opportunity: "ieee-manoa", verified: true, hrswk: 1, studentID: acID},

    ];

    let sampleOpportunityInstanceIDs = _.map(sampleOpportunityInstanceData, RadGrad.opportunityinstance.define);

    let sampleDegreePlan = RadGrad.degreeplan.define({
        courseInstanceIDs: sampleCourseInstanceIDs,
        opportunityInstanceIDs: sampleOpportunityInstanceIDs,
        workInstanceIDs: sampleWorkInstanceIDs,
        studentID: acID
    });

    RadGrad.user.setDegreePlanID(acID, sampleDegreePlan);
    RadGrad.user.setDegreeGoalIDs(acID,
        [RadGrad.slug.getEntityID("data-scientist", "DegreeGoal"),RadGrad.slug.getEntityID("bs-ce", "DegreeGoal")]);
    RadGrad.user.setInterestTagIDs(acID,
        [RadGrad.slug.getEntityID("dynamic-programming", "Tag"),            // need more slugs...
            RadGrad.slug.getEntityID("analytical-modeling", "Tag"),
            RadGrad.slug.getEntityID("microprocessor-design", "Tag"),
            RadGrad.slug.getEntityID("python", "Tag"),
            RadGrad.slug.getEntityID("algorithms", "Tag"),
            RadGrad.slug.getEntityID("android", "Tag"),
            RadGrad.slug.getEntityID("microprocessor-design", "Tag"),
            RadGrad.slug.getEntityID("computer-architecture", "Tag"),
            RadGrad.slug.getEntityID("parallel-programming", "Tag"),
            RadGrad.slug.getEntityID("computer-security", "Tag"),
            RadGrad.slug.getEntityID("game-design", "Tag"),
            RadGrad.slug.getEntityID("java", "Tag"),
            RadGrad.slug.getEntityID("electrical-engineering", "Tag"),
            RadGrad.slug.getEntityID("artificial-intelligence", "Tag") ]);

    RadGrad.user.setPicture(acID, "http://artcreationforever.com/images/brad-pitt/brad-pitt-04.jpg");
    RadGrad.user.setAboutMe(acID, "I am a senior in CENG. I have diverse interests in computer science and computer engineering. My primary interests, however, include software development and A.I. research.");
    RadGrad.user.setSemesterID(acID, RadGrad.semester.get("Spring", 2017));
};
