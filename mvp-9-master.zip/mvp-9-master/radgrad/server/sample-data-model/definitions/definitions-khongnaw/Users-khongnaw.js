defineUsers_khongnaw = function() {
    let Users = [
        {
            firstName: "Rory",
            middleName: "",
            lastName: "Blue",
            slug: "roryblue",
            password: "foo",
            uhEmail: "blue@hawaii.edu",
            role: RadGrad.role.student
        },
        {
            firstName: "Kelsie",
            middleName: "",
            lastName: "Pink",
            slug: "kelsiepink",
            password: "foo",
            uhEmail: "pink@hawaii.edu",
            role: RadGrad.role.student
        },
        {
            firstName: "Carl",
            middleName: "",
            lastName: "Ramirez",
            slug: "carlramirez",
            password: "foo",
            uhEmail: "ramirez@hawaii.edu",
            role: RadGrad.role.student
        },
        {
            firstName: "Alexander",
            middleName: "",
            lastName: "Hawkins",
            slug: "alexanderhawkins",
            password: "foo",
            uhEmail: "hawkins@hawaii.edu",
            role: RadGrad.role.student
        },
        {
            firstName: "Kevin",
            middleName: "",
            lastName: "Dawson",
            slug: "kevindawson",
            password: "foo",
            uhEmail: "dawson@hawaii.edu",
            role: RadGrad.role.student
        },
        {
            firstName: "Derrick",
            middleName: "",
            lastName: "Mcdaniel",
            slug: "derrickmcdaniel",
            password: "foo",
            uhEmail: "mcdaniel@hawaii.edu",
            role: RadGrad.role.student
        },
        {
            firstName: "Moore",
            middleName: "",
            lastName: "King",
            slug: "mooreking",
            password: "foo",
            uhEmail: "king@hawaii.edu",
            role: RadGrad.role.student
        },
        {
            firstName: "Rich",
            middleName: "",
            lastName: "Gilchrist",
            slug: "richgilchrist",
            password: "foo",
            uhEmail: "gilchrist@hawaii.edu",
            role: RadGrad.role.student
        }

    ];

    _.each(Users, RadGrad.user.define);
}