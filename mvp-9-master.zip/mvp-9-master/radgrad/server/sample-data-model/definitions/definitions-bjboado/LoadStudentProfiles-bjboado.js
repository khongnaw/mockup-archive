defineStudentProfilesbjboado = function () {

  defineStudentProfileVashValentino();
  defineStudentProfileRyoRambert();
  defineStudentProfileNathanielNay();
  defineStudentProfileLazarethLinkle();
  defineStudentProfileJaroJentle();
  defineStudentProfileCecilleCayne();
  defineStudentProfileCatherineCuzon();
  defineStudentProfileBeatriceBasilia();
}
