defineStudentProfileVashValentino = function() {

  let vv = RadGrad.user.findBySlug("vashvalentino")._id;

  let sampleWorkInstanceData = [
  ];

  let sampleWorkInstanceIDs = _.map(sampleWorkInstanceData, RadGrad.workinstance.define);

  let sampleCourseInstanceData = [
    /* 2012 */
    {semesterID: RadGrad.semester.get("Fall", 2012), course: "ics111", verified: true, grade: "A", studentID: vv},
    {semesterID: RadGrad.semester.get("Fall", 2012), course: "ics141", verified: true, grade: "B", studentID: vv},
    {semesterID: RadGrad.semester.get("Fall", 2012), course: "oth1xx", verified: true, grade: "C", studentID: vv, credithrs: 4 },
    {semesterID: RadGrad.semester.get("Fall", 2012), course: "oth1xx", verified: true, grade: "B", studentID: vv},
    {semesterID: RadGrad.semester.get("Fall", 2012), course: "oth1xx", verified: true, grade: "C", studentID: vv},

    {semesterID: RadGrad.semester.get("Spring", 2012), course: "ics241", verified: true, grade: "C", studentID: vv},
    {semesterID: RadGrad.semester.get("Spring", 2012), course: "ics211", verified: true, grade: "B", studentID: vv},
    {semesterID: RadGrad.semester.get("Spring", 2012), course: "oth1xx", verified: true, grade: "A", studentID: vv, credithrs: 4},
    {semesterID: RadGrad.semester.get("Spring", 2012), course: "oth1xx", verified: true, grade: "A", studentID: vv},
    {semesterID: RadGrad.semester.get("Spring", 2012), course: "oth2xx", verified: true, grade: "A", studentID: vv},

    /* 2013 */
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "ics212", verified: true, grade: "A", studentID: vv},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "ics311", verified: true, grade: "C", studentID: vv},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "C", studentID: vv, credithrs: 4},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "C", studentID: vv},

    {semesterID: RadGrad.semester.get("Spring", 2013), course: "ics321", verified: true, grade: "A", studentID: vv},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "ics331", verified: true, grade: "B", studentID: vv},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth2xx", verified: true, grade: "A", studentID: vv, credithrs: 4},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth2xx", verified: true, grade: "A", studentID: vv},

    /* 2014 */
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "ics212", verified: true, grade: "A", studentID: vv},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "ics311", verified: true, grade: "C", studentID: vv},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "A", studentID: vv, credithrs: 4},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "B", studentID: vv},

    {semesterID: RadGrad.semester.get("Spring", 2013), course: "ics321", verified: true, grade: "C", studentID: vv},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "ics331", verified: true, grade: "B", studentID: vv},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth2xx", verified: true, grade: "A", studentID: vv, credithrs: 4},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth2xx", verified: true, grade: "A", studentID: vv},

    /* 2015 */
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "ics314", verified: true, grade: "A", studentID: vv},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "ics361", verified: true, grade: "C", studentID: vv},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "C", studentID: vv},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "C", studentID: vv},

    {semesterID: RadGrad.semester.get("Spring", 2013), course: "ics390", verified: true, grade: "C", studentID: vv},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "ics355", verified: true, grade: "B", studentID: vv},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth2xx", verified: true, grade: "A", studentID: vv},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth2xx", verified: true, grade: "A", studentID: vv},

    /* 2016 */

    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth3xx", verified: false, studentID: vv},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics351", verified: false, studentID: vv},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics332", verified: false, studentID: vv},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics414", verified: false, studentID: vv},

    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ics466", verified: false, studentID: vv},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth4xx", verified: false, studentID: vv},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth4xx", verified: false, studentID: vv, credithrs: 4},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth4xx", verified: false, studentID: vv}
  ];

  let sampleCourseInstanceIDs = _.map(sampleCourseInstanceData, RadGrad.courseinstance.define);

  let sampleOpportunityInstanceData = [
  ];

  let sampleOpportunityInstanceIDs = _.map(sampleOpportunityInstanceData, RadGrad.opportunityinstance.define);

  let sampleDegreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: sampleCourseInstanceIDs,
    opportunityInstanceIDs: sampleOpportunityInstanceIDs,
    workInstanceIDs: sampleWorkInstanceIDs,
    studentID: vv
  });

  RadGrad.user.setDegreePlanID(vv, sampleDegreePlan);
  RadGrad.user.setDegreeGoalIDs(vv, [RadGrad.slug.getEntityID("ba-ics", "DegreeGoal")]);

  RadGrad.user.setInterestTagIDs(vv,
      [RadGrad.slug.getEntityID("ilokano", "Tag"),
        RadGrad.slug.getEntityID("music", "Tag"),
        RadGrad.slug.getEntityID("foreign-languages", "Tag"),
        RadGrad.slug.getEntityID("web-design", "Tag"),
      ]);

  RadGrad.user.setPicture(vv, "https://s-media-cache-ak0.pinimg.com/236x/3f/c0/cc/3fc0ccd303bfcd6468258d2fae8e722a.jpg");
  RadGrad.user.setAboutMe(vv, "I've taken a majority of the ICS courses and I want to double major in a foreign language. I had also worked full time as I was trying to complete my bachelors.");
  RadGrad.user.setSemesterID(vv, RadGrad.semester.get("Fall", 2016));

};