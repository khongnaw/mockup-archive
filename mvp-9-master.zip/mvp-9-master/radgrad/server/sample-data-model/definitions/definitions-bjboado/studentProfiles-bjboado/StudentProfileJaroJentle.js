defineStudentProfileJaroJentle = function() {
  let jID = RadGrad.user.findBySlug("jarojentle")._id;

  let sampleWorkInstanceData = [
  ];

  let sampleWorkInstanceIDs = _.map(sampleWorkInstanceData, RadGrad.workinstance.define);

  let sampleCourseInstanceData = [

     /* 2013 */
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "B", studentID: jID},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "B", studentID: jID, credithrs: 4},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "A", studentID: jID},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "A", studentID: jID ,credithrs: 1},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "C", studentID: jID},

    /* 2014 */
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ee160", verified: true, grade: "A", studentID: jID, credithrs: 4},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: true, grade: "A", studentID: jID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: true, grade: "B", studentID: jID, credithrs: 4},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: true, grade: "A", studentID: jID, credithrs: 2},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: true, grade: "A", studentID: jID},

    {semesterID: RadGrad.semester.get("Summer", 2014), course: "oth2xx", verified: true, grade: "A+", studentID: jID},
    {semesterID: RadGrad.semester.get("Summer", 2014), course: "oth2xx", verified: true, grade: "B", studentID: jID},

    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee211", verified: true, grade: "B", studentID: jID, credithrs: 4},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee260", verified: true, grade: "A", studentID: jID, credithrs: 4},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee296", verified: true, grade: "A", studentID: jID, credithrs: 1},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: true, grade: "A", studentID: jID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: true, grade: "B", studentID: jID},

    /* 2015 */
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee213", verified: true, grade: "B", studentID: jID, credithrs: 4},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee205", verified: true, grade: "A", studentID: jID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth2xx", verified: true, grade: "A", studentID: jID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee396", verified: true, grade: "A", studentID: jID, credithrs: 2},

    {semesterID: RadGrad.semester.get("Summer", 2015), course: "oth2xx", verified: true, grade: "A+", studentID: jID},

    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee324", verified: true, grade: "B", studentID: jID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee371", verified: true, grade: "B", studentID: jID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee361", verified: true, grade: "A", studentID: jID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee315", verified: true, grade: "A-", studentID: jID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee496", verified: true, grade: "A", studentID: jID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: true, grade: "A", studentID: jID, credithrs: 1},

    /* 2016 */
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee323", verified: true, grade: "B", studentID: jID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: true, grade: "A-", studentID: jID, credithrs: 1},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee367", verified: true, grade: "A", studentID: jID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: true, grade: "A", studentID: jID, credithrs: 1},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee406", verified: true, grade: "A", studentID: jID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee342", verified: true, grade: "A", studentID: jID},

    {semesterID: RadGrad.semester.get("Summer", 2016), course: "oth2xx", verified: true, grade: "A-", studentID: jID},

    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ee468", verified: true, grade: "A", studentID: jID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth2xx", verified: true, grade: "A", studentID: jID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth2xx", verified: true, grade: "A", studentID: jID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ics314", verified: true, grade: "A", studentID: jID},

    /* 2017 */
    {semesterID: RadGrad.semester.get("Spring", 2017), course: "ics414", verified: false, studentID: jID},
    {semesterID: RadGrad.semester.get("Spring", 2017), course: "ics432", verified: false, studentID: jID},
    {semesterID: RadGrad.semester.get("Spring", 2017), course: "ee495", verified: false, studentID: jID, credithrs: 1}
  ];

  let sampleCourseInstanceIDs = _.map(sampleCourseInstanceData, RadGrad.courseinstance.define);

  let sampleOpportunityInstanceData = [
  ];

  let sampleOpportunityInstanceIDs = _.map(sampleOpportunityInstanceData, RadGrad.opportunityinstance.define);

  let sampleDegreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: sampleCourseInstanceIDs,
    opportunityInstanceIDs: sampleOpportunityInstanceIDs,
    workInstanceIDs: sampleWorkInstanceIDs,
    studentID: jID
  });

  RadGrad.user.setDegreePlanID(jID, sampleDegreePlan);
  RadGrad.user.setDegreeGoalIDs(jID, [RadGrad.slug.getEntityID("bs-ce", "DegreeGoal")]);

  RadGrad.user.setInterestTagIDs(jID,
      [
        RadGrad.slug.getEntityID("music", "Tag"),
        RadGrad.slug.getEntityID("foreign-languages", "Tag"),
        RadGrad.slug.getEntityID("microprocessor-design", "Tag"),
        RadGrad.slug.getEntityID("python", "Tag"),
        RadGrad.slug.getEntityID("algorithms", "Tag"),
        RadGrad.slug.getEntityID("android", "Tag"),
        RadGrad.slug.getEntityID("microprocessor-design", "Tag"),
        RadGrad.slug.getEntityID("web-design", "Tag"),
      ]);

  RadGrad.user.setPicture(jID, "http://www.a2z-matrimonial.com/images/profile_photos/6d/Gaurav1981_1_thumb.jpeg");
  RadGrad.user.setAboutMe(jID, "I've participated in numerous Robotic competitions in high school. I want to build on that and earn a CE degree so that I can design drones.");
  RadGrad.user.setSemesterID(jID, RadGrad.semester.get("Spring", 2017));
};
