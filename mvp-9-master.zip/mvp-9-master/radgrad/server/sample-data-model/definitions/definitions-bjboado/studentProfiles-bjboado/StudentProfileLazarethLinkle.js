defineStudentProfileLazarethLinkle = function() {
  let lID = RadGrad.user.findBySlug("lazarethlinkle")._id;

  let sampleWorkInstanceData = [
  ];

  let sampleWorkInstanceIDs = _.map(sampleWorkInstanceData, RadGrad.workinstance.define);

  let sampleCourseInstanceData = [
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth3xx", verified: false, studentID: lID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics351", verified: false, studentID: lID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics332", verified: false, studentID: lID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics414", verified: false, studentID: lID},

    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ics466", verified: false, studentID: lID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth4xx", verified: false, studentID: lID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth4xx", verified: false, studentID: lID, credithrs: 4},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth4xx", verified: false, studentID: lID}
  ];

  let sampleCourseInstanceIDs = _.map(sampleCourseInstanceData, RadGrad.courseinstance.define);

  let sampleOpportunityInstanceData = [
  ];

  let sampleOpportunityInstanceIDs = _.map(sampleOpportunityInstanceData, RadGrad.opportunityinstance.define);

  let sampleDegreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: sampleCourseInstanceIDs,
    opportunityInstanceIDs: sampleOpportunityInstanceIDs,
    workInstanceIDs: sampleWorkInstanceIDs,
    studentID: lID
  });

  RadGrad.user.setDegreePlanID(lID, sampleDegreePlan);
  RadGrad.user.setDegreeGoalIDs(lID, [RadGrad.slug.getEntityID("ba-ics", "DegreeGoal")]);

  RadGrad.user.setInterestTagIDs(lID,
      [RadGrad.slug.getEntityID("ilokano", "Tag"),
        RadGrad.slug.getEntityID("music", "Tag"),
        RadGrad.slug.getEntityID("foreign-languages", "Tag"),
      ]);

  RadGrad.user.setPicture(lID, "https://media.licdn.com/mpr/mpr/shrinknp_200_200/p/2/005/009/3c0/3915e1c.jpg");
  RadGrad.user.setAboutMe(lID, "I've taken a majority of the ICS courses and I want to double major in a foreign language.");
  RadGrad.user.setSemesterID(lID, RadGrad.semester.get("Fall", 2016));
};