defineStudentProfileNathanielNay = function() {
  let nID = RadGrad.user.findBySlug("nathanielnay")._id;

  let sampleWorkInstanceData = [
  ];

  let sampleWorkInstanceIDs = _.map(sampleWorkInstanceData, RadGrad.workinstance.define);

  let sampleCourseInstanceData = [
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth3xx", verified: false, studentID: nID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics351", verified: false, studentID: nID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics332", verified: false, studentID: nID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics414", verified: false, studentID: nID},

    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ics466", verified: false, studentID: nID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth4xx", verified: false, studentID: nID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth4xx", verified: false, studentID: nID, credithrs: 4},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth4xx", verified: false, studentID: nID}
  ];

  let sampleCourseInstanceIDs = _.map(sampleCourseInstanceData, RadGrad.courseinstance.define);

  let sampleOpportunityInstanceData = [
  ];

  let sampleOpportunityInstanceIDs = _.map(sampleOpportunityInstanceData, RadGrad.opportunityinstance.define);

  let sampleDegreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: sampleCourseInstanceIDs,
    opportunityInstanceIDs: sampleOpportunityInstanceIDs,
    workInstanceIDs: sampleWorkInstanceIDs,
    studentID: nID
  });

  RadGrad.user.setDegreePlanID(nID, sampleDegreePlan);
  RadGrad.user.setDegreeGoalIDs(nID, [RadGrad.slug.getEntityID("ba-ics", "DegreeGoal")]);

  RadGrad.user.setInterestTagIDs(nID,
      [RadGrad.slug.getEntityID("ilokano", "Tag"),
        RadGrad.slug.getEntityID("music", "Tag"),
        RadGrad.slug.getEntityID("foreign-languages", "Tag"),
      ]);

  RadGrad.user.setPicture(nID, "https://media.licdn.com/mpr/mpr/shrinknp_200_200/p/3/005/015/1f1/0da85f3.jpg");
  RadGrad.user.setAboutMe(nID, "I've taken a majority of the ICS courses and I want to double major in a foreign language.");
  RadGrad.user.setSemesterID(nID, RadGrad.semester.get("Fall", 2016));
};