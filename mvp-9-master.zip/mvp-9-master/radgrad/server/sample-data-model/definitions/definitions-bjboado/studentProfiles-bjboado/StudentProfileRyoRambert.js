defineStudentProfileRyoRambert = function() {
  let rrID = RadGrad.user.findBySlug("ryorambert")._id;

  let sampleWorkInstanceData = [
  ];

  let sampleWorkInstanceIDs = _.map(sampleWorkInstanceData, RadGrad.workinstance.define);

  let sampleCourseInstanceData = [
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth3xx", verified: false, studentID: rrID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics351", verified: false, studentID: rrID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics332", verified: false, studentID: rrID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics414", verified: false, studentID: rrID},

    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ics466", verified: false, studentID: rrID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth4xx", verified: false, studentID: rrID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth4xx", verified: false, studentID: rrID, credithrs: 4},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth4xx", verified: false, studentID: rrID}
  ];

  let sampleCourseInstanceIDs = _.map(sampleCourseInstanceData, RadGrad.courseinstance.define);

  let sampleOpportunityInstanceData = [
  ];

  let sampleOpportunityInstanceIDs = _.map(sampleOpportunityInstanceData, RadGrad.opportunityinstance.define);

  let sampleDegreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: sampleCourseInstanceIDs,
    opportunityInstanceIDs: sampleOpportunityInstanceIDs,
    workInstanceIDs: sampleWorkInstanceIDs,
    studentID: rrID
  });

  RadGrad.user.setDegreePlanID(rrID, sampleDegreePlan);
  RadGrad.user.setDegreeGoalIDs(rrID, [RadGrad.slug.getEntityID("ba-ics", "DegreeGoal")]);

  RadGrad.user.setInterestTagIDs(rrID,
      [RadGrad.slug.getEntityID("ilokano", "Tag"),
        RadGrad.slug.getEntityID("music", "Tag"),
        RadGrad.slug.getEntityID("foreign-languages", "Tag"),
      ]);

  RadGrad.user.setPicture(rrID, "http://www.herworldplus.com/sites/default/files/Gdragon%20fashion%20week%20200.jpg");
  RadGrad.user.setAboutMe(rrID, "I've taken a majority of the ICS courses and I want to double major in a foreign language.");
  RadGrad.user.setSemesterID(rrID, RadGrad.semester.get("Fall", 2016));
};