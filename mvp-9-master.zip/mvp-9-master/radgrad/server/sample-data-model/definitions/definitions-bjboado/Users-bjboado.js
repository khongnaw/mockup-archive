defineUsersbjboado = function() {
  let Users = [
    {
      firstName: "Vash",
      middleName: "",
      lastName: "Valentino",
      slug: "vashvalentino",
      password: "foo",
      uhEmail: "vavalentino@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Ryo",
      middleName: "",
      lastName: "Rambert",
      slug: "ryorambert",
      password: "foo",
      uhEmail: "ryrambert@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Nathaniel",
      middleName: "",
      lastName: "Nay",
      slug: "nathanielnay",
      password: "foo",
      uhEmail: "nanay@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Lazareth",
      middleName: "",
      lastName: "Linkle",
      slug: "lazarethlinkle",
      password: "foo",
      uhEmail: "lalinkle@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Jaro",
      middleName: "",
      lastName: "Jentle",
      slug: "jarojentle",
      password: "foo",
      uhEmail: "jajentle@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Cecille",
      middleName: "",
      lastName: "Cayne",
      slug: "cecillecayne",
      password: "foo",
      uhEmail: "cecayne@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Catherine",
      middleName: "",
      lastName: "Cuzon",
      slug: "catherinecuzon",
      password: "foo",
      uhEmail: "cacuzon@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Beatrice",
      middleName: "",
      lastName: "Basilia",
      slug: "beatricebasilia",
      password: "foo",
      uhEmail: "bebasilia@hawaii.edu",
      role: RadGrad.role.student
    }
  ];

  _.each(Users, RadGrad.user.define);
}
