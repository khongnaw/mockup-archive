defineUsers_mkshimod = function() {
  let Users = [
    {
      firstName: "Justin",
      middleName: "",
      lastName: "Choe",
      slug: "justinchoe",
      password: "foo",
      uhEmail: "jchoe@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Nicholas",
      middleName: "",
      lastName: "Haynes",
      slug: "nicholashaynes",
      password: "foo",
      uhEmail: "nhaynes@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Joyce",
      middleName: "",
      lastName: "Blue",
      slug: "joyceblue",
      password: "foo",
      uhEmail: "jblue@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Jared",
      middleName: "",
      lastName: "Nakahara",
      slug: "jarednakahara",
      password: "foo",
      uhEmail: "jnakahara@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Carine",
      middleName: "",
      lastName: "Kim",
      slug: "carinekim",
      password: "foo",
      uhEmail: "ckim@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Nathan",
      middleName: "",
      lastName: "Rose",
      slug: "nathanrose",
      password: "foo",
      uhEmail: "nrose@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Edie",
      middleName: "",
      lastName: "Jerald",
      slug: "ediejerald",
      password: "foo",
      uhEmail: "ejerald@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Danielle",
      middleName: "",
      lastName: "Thomas",
      slug: "daniellethomas",
      password: "foo",
      uhEmail: "dthomas@hawaii.edu",
      role: RadGrad.role.student
    },

  ];

  _.each(Users, RadGrad.user.define);
}
