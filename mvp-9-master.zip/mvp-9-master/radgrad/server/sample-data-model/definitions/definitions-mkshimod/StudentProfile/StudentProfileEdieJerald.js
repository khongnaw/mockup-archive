
defineStudentProfileEdieJerald = function() {
  let ejID = RadGrad.user.findBySlug("ediejerald")._id;

  let EdieJeraldWorkInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2013), hrswk: 10, studentID: ejID},
    {semesterID: RadGrad.semester.get("Spring", 2013), hrswk: 10, studentID: ejID},
    {semesterID: RadGrad.semester.get("Fall", 2014), hrswk: 10, studentID: ejID},
    {semesterID: RadGrad.semester.get("Spring", 2014), hrswk: 10, studentID: ejID},
    {semesterID: RadGrad.semester.get("Fall", 2015), hrswk: 10, studentID: ejID},
    {semesterID: RadGrad.semester.get("Spring", 2015), hrswk: 10, studentID: ejID},
    {semesterID: RadGrad.semester.get("Fall", 2016), hrswk: 10, studentID: ejID},
    {semesterID: RadGrad.semester.get("Spring", 2016), hrswk: 16, studentID: ejID}
  ];

  let EdieJeraldWorkInstanceIDs = _.map(EdieJeraldWorkInstanceData, RadGrad.workinstance.define);

  let EdieJeraldCourseInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: false, grade: "B", studentID: ejID},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: false, grade: "B", credithrs: 1, studentID: ejID},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: false, grade: "A", studentID: ejID},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: false, grade: "A-", credithrs: 4, studentID: ejID},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: false, grade: "B-", credithrs: 1, studentID: ejID},

    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth1xx", verified: false, grade: "B", studentID: ejID},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "ee160", verified: false, grade: "A-", credithrs: 4, studentID: ejID},
    {semesterID: RadGrad.semester .get("Spring", 2013), course: "oth2xx", verified: false, grade: "B+", credithrs: 4, studentID: ejID},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth2xx", verified: false, grade: "B+", credithrs: 1, studentID: ejID},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth1xx", verified: false, grade: "A", credithrs: 1, studentID: ejID},

    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee211", verified: false, grade: "B", studentID: ejID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee260", verified: false, grade: "A-", credithrs: 4, studentID: ejID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: false, grade: "B", studentID: ejID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: false, grade: "B-", studentID: ejID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: false, grade: "A", credithrs: 1, studentID: ejID},

    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ee205", verified: false, grade: "A", studentID: ejID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ee213", verified: false, grade: "A", credithrs: 4, studentID: ejID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ee296", verified: false, grade: "B", credithrs: 2, studentID: ejID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: false, grade: "A", studentID: ejID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: false, grade: "A", studentID: ejID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ics141", verified: false, grade: "B", studentID: ejID},


    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: false, grade: "A", studentID: ejID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee324", verified: false, grade: "B-", credithrs: 4, studentID: ejID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee361", verified: false, grade: "A", studentID: ejID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee361", verified: false, grade: "A", credithrs: 1, studentID: ejID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee371", verified: false, grade: "A", credithrs: 1, studentID: ejID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee396", verified: false, grade: "A", studentID: ejID},

    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee315", verified: false, grade: "A-", studentID: ejID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee323", verified: false, grade: "B", studentID: ejID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee323", verified: false, grade: "A", credithrs: 1, studentID: ejID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee367", verified: false, grade: "A-", studentID: ejID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee367", verified: false, grade: "A", credithrs: 1, studentID: ejID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth1xx", verified: false, grade: "A", studentID: ejID},

    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ee342", verified: false, grade: "B", studentID: ejID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ee468", verified: false, grade: "B", credithrs: 4, studentID: ejID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth1xx", verified: false, grade: "A", studentID: ejID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ics314", verified: false, grade: "A", studentID: ejID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ics415", verified: false, grade: "A", studentID: ejID},


    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: ejID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee406", verified: false, studentID: ejID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee495", verified: false, studentID: ejID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee496", verified: false, studentID: ejID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: ejID}
  ];

  let EdieJeraldCourseInstanceIDs = _.map(EdieJeraldCourseInstanceData, RadGrad.courseinstance.define);

  let EdieJeraldOpportunityInstanceData = [
    {
      semesterID: RadGrad.semester.get("Spring", 2014),
      opportunity: "ieee-manoa",
      verified: false,
      hrswk: 5,
      studentID: ejID
    },
    {
      semesterID: RadGrad.semester.get("Fall", 2015),
      opportunity: "ieee-manoa",
      verified: false,
      hrswk: 15,
      studentID: ejID
    },
    {
      semesterID: RadGrad.semester.get("Spring", 2015),
      opportunity: "ieee-manoa",
      verified: false,
      hrswk: 20,
      studentID: ejID
    },
    {
      semesterID: RadGrad.semester.get("Fall", 2016),
      opportunity: "ieee-manoa",
      verified: false,
      hrswk: 20,
      studentID: ejID
    },

    {
      semesterID: RadGrad.semester.get("Spring", 2016),
      opportunity: "ieee-manoa",
      verified: false,
      hrswk: 20,
      studentID: ejID
    },
    {
      semesterID: RadGrad.semester.get("Spring", 2016),
      opportunity: "liveaction-internship",
      verified: false,
      hrswk: 16,
      studentID: ejID
    }
  ];
  let EdieJeraldOpportunityIDs = _.map(EdieJeraldOpportunityInstanceData, RadGrad.opportunityinstance.define);

  let EdieJeraldDegreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: EdieJeraldCourseInstanceIDs,
    opportunityInstanceIDs: EdieJeraldOpportunityIDs,
    workInstanceIDs: EdieJeraldWorkInstanceIDs,
    studentID: ejID
  });

  RadGrad.user.setDegreePlanID(ejID, EdieJeraldDegreePlan);
  RadGrad.user.setDegreeGoalIDs(ejID, [
    RadGrad.slug.getEntityID("web-developer", "DegreeGoal"),
    RadGrad.slug.getEntityID("bs-ce", "DegreeGoal")
  ]);
  RadGrad.user.setInterestTagIDs(ejID, [
    RadGrad.slug.getEntityID("web-design", "Tag"),
    RadGrad.slug.getEntityID("angular", "Tag"),
    RadGrad.slug.getEntityID("javascript", "Tag"),
    RadGrad.slug.getEntityID("node", "Tag"),
    RadGrad.slug.getEntityID("software-engineering", "Tag"),
    RadGrad.slug.getEntityID("bootstrap", "Tag")
  ]);
  RadGrad.user.setPicture(ejID, "http://ia.media-imdb.com/images/M/MV5BMTQ5NjI2MjUyNV5BMl5BanBnXkFtZTgwMDU3MzgwNjE@._V1_UY1200_CR165,0,630,1200_AL_.jpg");

  RadGrad.user.setAboutMe(ejID, "I am a senior in my last semester majoring in computer engineering, with interests in web development and project management.");
  RadGrad.user.setSemesterID(ejID, RadGrad.semester.get("Spring", 2019));
}

