// TODO change degree goals
defineStudentProfileNathanRose = function() {
  let nrID = RadGrad.user.findBySlug("nathanrose")._id;

  let NathanRoseWorkInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2013), hrswk: 15, studentID: nrID},
    {semesterID: RadGrad.semester.get("Spring", 2013), hrswk: 15, studentID: nrID},
    {semesterID: RadGrad.semester.get("Summer", 2013), hrswk: 40, studentID: nrID},
    {semesterID: RadGrad.semester.get("Fall", 2014), hrswk: 15, studentID: nrID},
    {semesterID: RadGrad.semester.get("Spring", 2014), hrswk: 15, studentID: nrID},
    {semesterID: RadGrad.semester.get("Summer", 2014), hrswk: 40, studentID: nrID},
    {semesterID: RadGrad.semester.get("Fall", 2015), hrswk: 15, studentID: nrID},
    {semesterID: RadGrad.semester.get("Spring", 2015), hrswk: 15, studentID: nrID},
    {semesterID: RadGrad.semester.get("Summer", 2015), hrswk: 40, studentID: nrID},
    {semesterID: RadGrad.semester.get("Fall", 2016), hrswk: 15, studentID: nrID},
    {semesterID: RadGrad.semester.get("Spring", 2016), hrswk: 15, studentID: nrID}
  ];

  let NathanRoseWorkInstanceIDs = _.map(NathanRoseWorkInstanceData, RadGrad.workinstance.define);

  let NathanRoseCourseInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: false, grade: "A", studentID: nrID},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: false, grade: "B+", credithrs: 4, studentID: nrID},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: false, grade: "A", studentID: nrID},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: false, grade: "A", credithrs: 1, studentID: nrID},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: false, grade: "A", studentID: nrID},

    {semesterID: RadGrad.semester.get("Spring", 2013), course: "ee160", verified: false, grade: "B+", credithrs: 4, studentID: nrID},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "ee260", verified: false, grade: "A-", credithrs: 4, studentID: nrID},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth2xx", verified: false, grade: "B", credithrs: 4, studentID: nrID},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth2xx", verified: false, grade: "B-", credithrs: 1, studentID: nrID},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth2xx", verified: false, grade: "B", studentID: nrID},

    {semesterID: RadGrad.semester.get("Summer", 2013), course: "oth1xx", verified: false, grade: "A", studentID: nrID},

    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee211", verified: false, grade: "A", studentID: nrID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee260", verified: false, grade: "A", credithrs: 4, studentID: nrID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: false, grade: "B", studentID: nrID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: false, grade: "B+", studentID: nrID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: false, grade: "B", studentID: nrID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: false, grade: "A", credithrs: 1, studentID: nrID},

    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ee213", verified: false, credithrs: 4, studentID: nrID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ee205", verified: false, studentID: nrID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: false, studentID: nrID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: false, studentID: nrID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth1xx", verified: false, studentID: nrID},
  ];

  let NathanRoseCourseInstanceIDs = _.map(NathanRoseCourseInstanceData, RadGrad.courseinstance.define);

  let NathanRoseOpportunityInstanceData = [];
  let NathanRoseOpportunityIDs = _.map(NathanRoseOpportunityInstanceData, RadGrad.opportunityinstance.define);

  let NathanRoseDegreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: NathanRoseCourseInstanceIDs,
    opportunityInstanceIDs: NathanRoseOpportunityIDs,
    workInstanceIDs: NathanRoseWorkInstanceIDs,
    studentID: nrID
  });

  RadGrad.user.setDegreePlanID(nrID, NathanRoseDegreePlan);
  RadGrad.user.setDegreeGoalIDs(nrID, [
    RadGrad.slug.getEntityID("robotics-engineer", "DegreeGoal"),
    RadGrad.slug.getEntityID("bs-ce", "DegreeGoal"),
    /*RadGrad.slug.getEntityID("masters-degree", "DegreeGoal")*/
  ]);
  RadGrad.user.setInterestTagIDs(nrID, [
    RadGrad.slug.getEntityID("artificial-intelligence", "Tag"),
    RadGrad.slug.getEntityID("algorithms", "Tag"),
    RadGrad.slug.getEntityID("silicon-valley", "Tag"),
    RadGrad.slug.getEntityID("machine-learning", "Tag")/*,
     RadGrad.slug.getEntityID("high-performance-computing", "Tag")*/
  ]);
  RadGrad.user.setPicture(nrID, "https://media.licdn.com/mpr/mpr/shrinknp_200_200/p/7/005/068/2b7/00c5b1a.jpg");

  RadGrad.user.setAboutMe(nrID, "I have a huge interest in AI, and one day hope to work as an engineer that creates intelligent robots to help solve everyday problems for handicapped people.");
  RadGrad.user.setSemesterID(nrID, RadGrad.semester.get("Spring", 2016));
}


