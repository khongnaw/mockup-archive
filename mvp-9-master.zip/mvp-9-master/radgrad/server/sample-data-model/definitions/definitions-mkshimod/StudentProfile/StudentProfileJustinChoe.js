/**
 * Created by Michele on 1/25/16.
 */
defineStudentProfileJustinChoe = function() {
  let jcID = RadGrad.user.findBySlug("justinchoe")._id;

  let JustinChoeWorkInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2015), hrswk: 20, studentID: jcID},
    {semesterID: RadGrad.semester.get("Spring", 2015), hrswk: 20, studentID: jcID},
    {semesterID: RadGrad.semester.get("Fall", 2016), hrswk: 20, studentID: jcID},
    {semesterID: RadGrad.semester.get("Spring", 2016), hrswk: 20, studentID: jcID}
  ];

  let JustinChoeWorkInstanceIDs = _.map(JustinChoeWorkInstanceData, RadGrad.workinstance.define);

  let JustinChoeCourseInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: false, grade: "B", studentID: jcID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: false, grade: "B+", studentID: jcID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: false, grade: "B-", studentID: jcID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: false, grade: "C+", studentID: jcID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: false, grade: "A", credithrs: 1, studentID: jcID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: false, grade: "C", studentID: jcID},

    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth1xx", verified: false, grade: "B", studentID: jcID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth1xx", verified: false, grade: "B", studentID: jcID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth2xx", verified: false, grade: "B+", studentID: jcID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth2xx", verified: false, grade: "B", studentID: jcID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth1xx", verified: false, grade: "B", credithrs: 1, studentID: jcID},

    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth2xx", verified: false, grade: "B-", studentID: jcID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth2xx", verified: false, grade: "B", studentID: jcID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth2xx", verified: false, grade: "B", studentID: jcID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth2xx", verified: false, grade: "C-", studentID: jcID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth1xx", verified: false, grade: "A", credithrs: 1, studentID: jcID},

    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics111", verified: false, studentID: jcID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: jcID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: false, credithrs: 1, studentID: jcID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics141", verified: false, studentID: jcID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: jcID},
  ];

  let JustinChoeCourseInstanceIDs = _.map(JustinChoeCourseInstanceData, RadGrad.courseinstance.define);

  let JustinChoeOpportunityInstanceData = [];
  let JustinChoeOpportunityIDs = _.map(JustinChoeOpportunityInstanceData, RadGrad.opportunityinstance.define);

  let JustinChoeDegreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: JustinChoeCourseInstanceIDs,
    opportunityInstanceIDs: JustinChoeOpportunityIDs,
    workInstanceIDs: JustinChoeWorkInstanceIDs,
    studentID: jcID
  });

  RadGrad.user.setDegreePlanID(jcID, JustinChoeDegreePlan);
  RadGrad.user.setDegreeGoalIDs(jcID, [RadGrad.slug.getEntityID("web-developer", "DegreeGoal")]);
  RadGrad.user.setInterestTagIDs(jcID, [
    RadGrad.slug.getEntityID("music", "Tag"),
    RadGrad.slug.getEntityID("business-administration", "Tag"),
    RadGrad.slug.getEntityID("business", "Tag")
  ]);
  RadGrad.user.setPicture(jcID, "https://media.licdn.com/mpr/mpr/shrinknp_200_200/p/7/005/090/1dd/3002378.jpg");

  RadGrad.user.setAboutMe(jcID, "I am a sophomore in college, who recently decided to change majors to ICS.  Previously, I was majoring in Business Administration, but had only taken gen eds.  In my free time, I enjoy playing music. I work part-time at a restaurant bussing tables.");
  RadGrad.user.setSemesterID(jcID, RadGrad.semester.get("Fall", 2018));
}