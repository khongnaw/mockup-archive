/**
 * Created by Michele on 1/27/16.
 */
defineStudentProfilesmkshimod = function () {
  defineStudentProfileJustinChoe();
  defineStudentProfileNicholasHaynes();
  defineStudentProfileJoyceBlue();
  defineStudentProfileJaredNakahara();
  defineStudentProfileCarineKim();
  defineStudentProfileNathanRose();
  defineStudentProfileEdieJerald();
  defineStudentProfileDanielleThomas();
}