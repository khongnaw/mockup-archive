
defineStudentProfileJaredNakahara = function() {
  let jnID = RadGrad.user.findBySlug("jarednakahara")._id;

  let JaredNakaharaWorkInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2015), hrswk: 0, studentID: jnID},
    {semesterID: RadGrad.semester.get("Spring", 2015), hrswk: 0, studentID: jnID},
    {semesterID: RadGrad.semester.get("Summer", 2015), hrswk: 35, studentID: jnID},
    {semesterID: RadGrad.semester.get("Fall", 2016), hrswk: 15, studentID: jnID},
    {semesterID: RadGrad.semester.get("Spring", 2016), hrswk: 15, studentID: jnID}
  ];

  let JaredNakaharaWorkInstanceIDs = _.map(JaredNakaharaWorkInstanceData, RadGrad.workinstance.define);

  let JaredNakaharaCourseInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: false, grade: "A", studentID: jnID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: false, grade: "A", credithrs: 4, studentID: jnID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: false, grade: "A", studentID: jnID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: false, grade: "A-", studentID: jnID},

    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ics141", verified: false, grade: "B+", studentID: jnID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ics111", verified: false, grade: "A", credithrs: 4, studentID: jnID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth1xx", verified: false, grade: "B", credithrs: 4, studentID: jnID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth2xx", verified: false, grade: "A", credithrs: 1, studentID: jnID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth1xx", verified: false, grade: "A", credithrs: 1, studentID: jnID},

    {semesterID: RadGrad.semester.get("Summer", 2015), course: "oth1xx", verified: false, grade: "A", studentID: jnID},

    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth2xx", verified: false, grade: "A", studentID: jnID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ics211", verified: false, grade: "A-", credithrs: 4, studentID: jnID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ics241", verified: false, grade: "A-", studentID: jnID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth1xx", verified: false, grade: "A-", credithrs: 1, studentID: jnID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth1xx", verified: false, grade: "A", studentID: jnID},

    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics314", verified: false, studentID: jnID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics311", verified: false, studentID: jnID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: false, studentID: jnID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: false, studentID: jnID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: jnID}
  ];

  let JaredNakaharaCourseInstanceIDs = _.map(JaredNakaharaCourseInstanceData, RadGrad.courseinstance.define);

  let JaredNakaharaOpportunityInstanceData = [];
  let JaredNakaharaOpportunityIDs = _.map(JaredNakaharaOpportunityInstanceData, RadGrad.opportunityinstance.define);

  let JaredNakaharaDegreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: JaredNakaharaCourseInstanceIDs,
    opportunityInstanceIDs: JaredNakaharaOpportunityIDs,
    workInstanceIDs: JaredNakaharaWorkInstanceIDs,
    studentID: jnID
  });

  RadGrad.user.setDegreePlanID(jnID, JaredNakaharaDegreePlan);
  RadGrad.user.setDegreeGoalIDs(jnID, [
    RadGrad.slug.getEntityID("information-security-analyst", "DegreeGoal"),
    RadGrad.slug.getEntityID("bs-cs", "DegreeGoal")
  ]);
  RadGrad.user.setInterestTagIDs(jnID, [
    RadGrad.slug.getEntityID("network-security", "Tag"),
    RadGrad.slug.getEntityID("python", "Tag"),
    RadGrad.slug.getEntityID("system-programming", "Tag"),
    RadGrad.slug.getEntityID("network-design", "Tag"),
    RadGrad.slug.getEntityID("cryptography", "Tag")
  ]);
  RadGrad.user.setPicture(jnID, "https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcT3NUWrFik4CBCd6VKwoujq1vbXuZBGchpi0XylFtXGf-fNW7cJDQ");

  RadGrad.user.setAboutMe(jnID, "I am a sophomore majoring in ICS.  I have an interest in network security and hope to one day work on creating security software. Currently, I work in ITS writing scripts to test the network.");
  RadGrad.user.setSemesterID(jnID, RadGrad.semester.get("Spring", 2019));
}

