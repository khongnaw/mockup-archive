google.charts.load('current', {'packages':['line', 'corechart']});
google.charts.setOnLoadCallback(drawChart);

function drawChart(current){
    /*
    if(current === 1){
        drawChart2();
        return 2;
    }
    else{
        drawChart1();
        return 1;
    }
    */
   drawChart1();
 // drawChart3();

}


function drawChart1() {

    var data = new google.visualization.DataTable();
    data.addColumn('number', 'Semester');
    data.addColumn('number', 'BS ICS');
    data.addColumn('number', 'BA ICS');
    data.addColumn('number', 'BS CompE');

    data.addRows([
        [1,  310, 300, 324],
        [2,  309, 300, 324],
        [3,  254,   150, 257],
        [4,  117, 188, 105],
        [5,  119, 176, 104],
        [6,   120, 136,  115],
        [7,   125, 123,  120],
        [8,  123, 292, 106],
        [9,  169, 250, 148],
        [10, 128, 284, 116],
        [11,  130,  200,  116],
        [12,  115,  220,  107],
        [13,  130,  190,  109],
        [14,  135,  200,  150],
        [15,  150, 210, 185],
        [16,  175, 200, 200],
        [17,  254,   250, 230],
        [18,  260, 325, 220]
    ]);

    var options = {
        backgroundColor: 'white'
    };

    // Convert the old style options to material options
    options = google.charts.Line.convertOptions(options);

    var chart = new google.charts.Line(document.getElementById('linechart_material'));
    chart.draw(data, options)
}

function drawChart2() {
      var data = google.visualization.arrayToDataTable([
        ['City', '2010 Population',],
        ['New York City, NY', 8175000],
        ['Los Angeles, CA', 3792000],
        ['Chicago, IL', 2695000],
        ['Houston, TX', 2099000],
        ['Philadelphia, PA', 1526000]
      ]);

      var options = {
        title: 'Population of Largest U.S. Cities',
        backgroundColor: '#c5e1a5',
        hAxis: {
          title: 'Total Population',
          minValue: 0
        },
        vAxis: {
          title: 'City'
        }
      };

      var chart = new google.visualization.BarChart(document.getElementById('linechart_material'));
      chart.draw(data, options);
}
function drawChart3() {

  var data = google.visualization.arrayToDataTable([
    ['City', '2010 Population'],
    ['New York City, NY', 8175000]
  ]);

  var options = {
    pieHole: 0.5,
    pieSliceTextStyle: {
      color: 'black'
    },
    legend: 'none'
  };

  var chart = new google.visualization.PieChart(document.getElementById('donut_single'));
  chart.draw(data, options);
}

$(document).ready(function(){

    //drawChart3();
    var current = 1;
    // create trigger to resizeEnd event
    $(window).resize(function() {
        if(this.resizeTO) clearTimeout(this.resizeTO);
        this.resizeTO = setTimeout(function() {
            $(this).trigger('resizeEnd');
        }, 120);
    });

    // redraw graph when window resize is completed
    $(window).on('resizeEnd', function() {
        current = drawChart(current);
    });

    /*
    setInterval(function(){
      $('#main-graph').animate({ opacity: 0 }, 500, function(){
          current = drawChart(current);
          $('#main-graph').animate({ opacity: 1 }, 500);
      });
    }, 5000);
    */
});
