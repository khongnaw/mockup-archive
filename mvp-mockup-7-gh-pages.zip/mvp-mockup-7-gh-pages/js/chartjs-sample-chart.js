Chart.types.Line.extend({
  name: "LineAlt",
  draw: function () {
    Chart.types.Line.prototype.draw.apply(this, arguments);

    var ctx = this.chart.ctx;
    ctx.save();
    // text alignment and color
    ctx.textAlign = "center";
    ctx.textBaseline = "bottom";
    ctx.fillStyle = this.options.scaleFontColor;
    // position
    var x = this.scale.xScalePaddingLeft * 0.4;
    var y = this.chart.height / 2;
    // change origin
    ctx.translate(x, y);
    // rotate text
    ctx.rotate(-90 * Math.PI / 180);
    ctx.fillText(this.datasets[0].label, 0, 0);
    ctx.restore();
  }
});
var DegreeStudentData = {
  labels: ["2011", "2012", "2013", "2014", "2015", "2016"],
  datasets: [{
    label: "Number of Students",
    fillColor: "rgba(139,195,74,0.2)",
    strokeColor: "rgba(139,195,74,1)",
    pointColor: "rgba(139,195,74,1)",
    pointStrokeColor: "#fff",
    pointHighlightFill: "#fff",
    pointHighlightStroke: "rgba(139,195,74,1)",
    data: [59, 80, 81, 56, 55, 40]
  }, {
    label: "Number of Students",
    fillColor: "rgba(76,175,80,0.2)",
    strokeColor: "rgba(76,175,80,1)",
    pointColor: "rgba(76,175,80,1)",
    pointStrokeColor: "#fff",
    pointHighlightFill: "#fff",
    pointHighlightStroke: "rgba(76,175,80,1)",
    data: [48, 40, 19, 86, 27, 90]
  }, {
    label: "Number of Students",
    fillColor: "rgba(56,142,60,0.2)",
    strokeColor: "rgba(56,142,60,1)",
    pointColor: "rgba(56,142,60,1)",
    pointStrokeColor: "#fff",
    pointHighlightFill: "#fff",
    pointHighlightStroke: "rgba(56,142,60,1)",
    data: [40, 60, 50, 40, 70, 80]
  }]
};
window.onload = function () {
  window.myLineChart = new Chart(
      document.getElementById("myChart").getContext("2d")).LineAlt(DegreeStudentData, {
        responsive: true,
        scaleFontColor: "#444",
        scaleLabel: "          <%=value%>"
      });
};