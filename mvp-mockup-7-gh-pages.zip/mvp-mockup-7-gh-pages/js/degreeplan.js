$(document).ready(function () {
  // On edge hit
  $('.your-class').on('beforeChange', function(event, slick, currentSlide, nextSlide){

  });

  $('.your-class').slick({
    prevArrow: "\<a class=\"left-arrow btn-floating btn-small waves-effect waves-light green left\"><i class=\"material-icons\">keyboard_arrow_left</i></a>",
    nextArrow: "\<a class=\"right-arrow btn-floating btn-small waves-effect waves-light green right\"><i class=\"material-icons\">keyboard_arrow_right</i></a>",
    appendArrows: ".arrow-holder",
    initialSlide: 3,
    infinite: false
  });
  $(document).ready(function(){
    $("button").click(function(){
      $("p").remove();
    });
  });

  dragula([document.querySelector('#cs16'),document.querySelector('#os16')],{
   
  })
});