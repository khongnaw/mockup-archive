$(document).ready(function(){
    /*
    setTimeout(function(){
        console.log("Sending toast");
        Materialize.toast('I see this is your first time visiting radgrad!', 3000) // 4000 is the duration of the toast
        setTimeout(function(){
            Materialize.toast('Feel free to scroll down to learn more about the system.', 4000) // 4000 is the duration of the toast
        }, 2000);
    }, 2000);
    */
};
