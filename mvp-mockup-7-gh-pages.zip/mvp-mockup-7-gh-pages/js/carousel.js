
$(document).ready(function(){
  $('.slider').slider({full_width: true});
  $(".dropdown-button").dropdown();

});

$(document).ready(function(){
  $('ul.tabs').tabs();
});