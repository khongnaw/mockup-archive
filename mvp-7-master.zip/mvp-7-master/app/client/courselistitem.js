//import { MyCourses } from '../lib/collections/MyCourses.js';

Template.courseListItem.rendered = function(){
  this.$('.ui.dropdown').dropdown();
};


Template.courseListItem.helpers({
  courseTypeIs  : function(courseType) {
    return this.number.includes(courseType);
  },
  courseIs  : function(courseNumber) {
    return this.number.valueOf() === courseNumber.valueOf();
  },

  myCourses : function() {
    return MyCourses.find({});
  }

});

Template.courseListItem.events ({
  'click .addcoursefall': function(){
   var selectedCourse =
   {
     course: this.number,
     credits: this.credithrs,
     semester: "Fall 2016"
   };
   // console.log(selectedCourse);

   MyCourses.insert(selectedCourse);

   // MyCourses.insert(selectedCourse);
  },
  'click .addcoursespr': function(){
    var selectedCourse =
    {
      course: this.number,
      credits: this.credithrs,
      semester: "Spring 2017"
    };
    // console.log(selectedCourse);

    MyCourses.insert(selectedCourse);

    // MyCourses.insert(selectedCourse);
  },
  'click .addcoursesum': function(){
    var selectedCourse =
    {
      course: this.number,
      credits: this.credithrs,
      semester: "Summer 2017"
    };
    // console.log(selectedCourse);

    MyCourses.insert(selectedCourse);

    // MyCourses.insert(selectedCourse);
  }


});