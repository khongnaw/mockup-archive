Template.admin.rendered = function(){
    console.log("Admin view");
    var courseDocs = RadGrad.course.find().fetch();
    console.log("Fetched all courses");
    console.log(courseDocs);

    var users = RadGrad.user.find().fetch();
    console.log("Fetched all users");
    console.log(users);
}

Template.admin.helpers({
    courses: RadGrad.course.find().fetch()
});
