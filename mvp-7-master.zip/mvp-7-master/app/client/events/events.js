function drawTable(data) {
    for (var i = 0; i < data.length; i++) {
        drawRow(data[i]);
    }
}

function drawRow(rowData) {
    var row = $("<tr />")
    $("#event_table").append(row); //this will append tr element to table... keep its reference for a while since we will add cels into it
    row.append($("<td>" +
                "<a href='" + rowData.link + "'>" +
                rowData.title + "</a></td>"));
}

Template.events.rendered = function(){
    this.autorun(function(){
        $.get("https://api.hnl.io/events/feed.rss", function (data) {
            var events = [];
            $(data).find("item").each(function () { // or "item" or whatever suits your feed
                var el = $(this);
                let event = {
                    title: el.find("title").text(),
                    description: el.find("description").text(),
                    link: el.find("link").text()
                }
                events.push(event);
            });
            console.log(events);
            drawTable(events);
        });

    });

}
