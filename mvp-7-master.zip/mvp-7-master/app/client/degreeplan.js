Template.degree.rendered = function(){
  this.$('.ui.dropdown').dropdown();
  this.$('.ui.accordion').accordion();
  $('.degree-course-list li').each(function(){
    $(this).attr('data-search-term', $(this).text().toLowerCase());
  });

  $('.degree-course-filter').on('keyup', function(){

    var searchTerm = $(this).val().toLowerCase();

    $('.degree-course-list li').each(function(){

      if ($(this).filter('[data-search-term *= ' + searchTerm + ']').length > 0 || searchTerm.length < 1) {
        $(this).show();
      } else {
        $(this).hide();
      }

    });

  });
  $('.degree-opportunity-list li').each(function(){
    $(this).attr('data-search-term', $(this).text().toLowerCase());
  });

  $('.degree-opportunity-filter').on('keyup', function(){

    var searchTerm = $(this).val().toLowerCase();

    $('.degree-opportunity-list li').each(function(){

      if ($(this).filter('[data-search-term *= ' + searchTerm + ']').length > 0 || searchTerm.length < 1) {
        $(this).show();
      } else {
        $(this).hide();
      }

    });

  });
  $('#innovation').progress({
    percent: 75
  });
  $('#competency').progress({
    percent: 75
  });
  $('#experience').progress({
    percent: 75
  });

};

Template.degree.helpers({
  courseList: function() {
    return _.map(RadGrad.course.find({}, {sort: {number: 1}}).fetch(), function(course) {
      let name = `${course.name}`;
      let number = `${course.number}`;
      let tagNames = `${RadGrad.tag.getTagIDs(course.slugNames)}`;
      let description = `${course.description}`;
      let credithrs = `${course.credithrs}`;
      return {name: name, number: number, tagNames: tagNames, description: description, credithrs: credithrs}
    })
  },
  opportunityList: function () {
    return _.map(RadGrad.opportunity.find({}, {sort: {name: 1}}).fetch(), function(opportunity) {
      let name = `${opportunity.name}`;
      let opportunityType = `${RadGrad.opportunitytype.findOne(opportunity.opportunityTypeID).name}`;
      let description = `${opportunity.description}`;
      let start = moment(opportunity.startActive).format('MM/DD/YYYY');
      let end = moment(opportunity.endActive).format('MM/DD/YYYY');
      let activeInterval = `${start} - ${end}`;

      return { iconURL: opportunity.iconURL, name: name, opportunityType: opportunityType, description: description, start: start, end: end, activeInterval: activeInterval};
    })
  },

  myCourses: function() {
    return MyCourses.find();
  },

  myOpp: function() {
    return MyOpp.find();
  },

  isFall: function(sem) {
    if(sem === "Fall 2016") return true;
    else return false;
  },
  isSpr: function(sem) {
    if(sem === "Spring 2017") return true;
    else return false;
  },
  isSum: function(sem) {
    if(sem === "Summer 2017") return true;
    else return false;
  },

  total: function() {
    var x = MyCourses.find().fetch();
    var totCred = _.reduce((_.map(x, function(course) {
      return course.credits;
    })), function (memo, num) {
      return memo + num;
    });
    console.log(totCred);
    return totCred;
  },

  totFallCredits: function() {
    var x = MyCourses.find().fetch();
    var fallCourses = _.map((_.where(x, {semester: "Fall 2016"})), function(course) {
      return course.credits;
    });
   return _.reduce(fallCourses, function (memo, num) {
      return memo + num;
    });

  },
  totSprCredits: function() {
    var x = MyCourses.find().fetch();
    var sprCourses = _.map((_.where(x, {semester: "Spring 2017"})), function(course) {
      return course.credits;
    });
    return _.reduce(sprCourses, function (memo, num) {
      return memo + num;
    });

  },
  totSumCredits: function() {
    var x = MyCourses.find().fetch();
    var sumCourses = _.map((_.where(x, {semester: "Summer 2017"})), function(course) {
      return course.credits;
    });
    return _.reduce(sumCourses, function (memo, num) {
      return memo + num;
    });

  },




  

});

Template.degree.events({
  'click .removecourse': function() {
    console.log(this);
    MyCourses.remove(this._id);
  },
  'click .totalcredits': function () {
   var x = MyCourses.find().fetch();
    var totCred = _.reduce((_.map(x, function(course) {
      return course.credits;
    })), function (memo, num) {
      return memo + num;
    });
    console.log(totCred);


  },

  'click .removeopp': function() {
    MyOpp.remove(this._id);
  },
});

