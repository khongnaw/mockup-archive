Template.opportunityListItem.rendered = function(){
  this.$('.ui.dropdown').dropdown();
};

Template.opportunityListItem.helpers({
  opportunityTypeIs: function(opportunityType) {
    return this.opportunityType.includes(opportunityType);
  },
  myOpp : function() {
    return MyOpp.find({});
  }
});

Template.opportunityListItem.events ({
  'click .addoppfall': function() {
    var selectedOpp =
    {
      name: this.name,
      semester: "Fall 2016"
    };
    console.log(selectedOpp);
    console.log(this);
    MyOpp.insert(selectedOpp);
  },
  'click .addoppspr': function() {
    var selectedOpp =
    {
      name: this.name,
      semester: "Spring 2017"
    };
    console.log(selectedOpp);
    console.log(this);
    MyOpp.insert(selectedOpp);
  },
  'click .addoppsum': function() {
    var selectedOpp =
    {
      name: this.name,
      semester: "Summer 2017"
    };
    console.log(selectedOpp);
    console.log(this);
    MyOpp.insert(selectedOpp);
  },
});