import {getGPA} from '/imports/gpa';

Template.user_settings.helpers({
    userGPA: function(){
        return getGPA();
    },
    picture: function(){
        return Meteor.user().picture;
    }
});

Template.user_settings.events({
    'click #save_picture': function (event,template) {
        event.preventDefault();
        var self = this;
        var text = $('#user_picture').val();
        RadGrad.user.setPicture(Meteor.user()._id, text);
    }
});
