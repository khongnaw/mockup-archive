Template.edit_interests.rendered = function(){
  this.autorun(function () {
    var tags = RadGrad.tag.find().fetch();
    var tagNames = tags.map(function(t){
      return {
                title: t.name,
                description: t.description.substring(0,50) + "..."
             };
    });

    $('#interest_searchbar')
    .search({
      source: tagNames
    });
  });
}

Template.edit_interests.helpers({
  initSearch: function(){
  },
  interestNames: function(){
      return RadGrad.tag.getTagNames(Meteor.user().interestTagIDs);
  }
});

Template.edit_interests.events({
    'click #close_edit_interests': function(event){
        $('#edit_interests_field').hide();
    },
    'click #remove_interest': function(event, template){
      var self = this;
      var value = $(event.target).closest('td').siblings().find('.interest_field').text();
      var tagID = RadGrad.tag.find({name: value}).fetch()[0]._id;

      let currentTags = Meteor.user().interestTagIDs;
      let newTags = _.without(currentTags, tagID);

      console.log(newTags);
      RadGrad.user.setInterestTagIDs(Meteor.user()._id, newTags)

    },
    'click #add_interest': function(event){
        var val = $('#interest_searchbar').search('get value');
        console.log(val);
        $('#interest_searchbar').search('set value', "");
        var tag = RadGrad.tag.find({name: val}).fetch()[0];

        var tagIDs = Meteor.user().interestTagIDs;

        if(tagIDs.includes(tag._id)) return false;
        if(!RadGrad.tag.findOne(tag._id)) return false;

        tagIDs.push(tag._id);
        RadGrad.user.setInterestTagIDs(Meteor.user()._id, tagIDs)
    }
});
