import {getGPA} from '/imports/gpa';
import {findMajor} from '/imports/degree';
import {findRemainingCourses} from '/imports/degree';

Template.user_home.rendered = function(){
    let sample_opportunities = [
        "ACM Manoa",
        "IEEE Student Branch",
        "LiveAction"
    ];
}

Template.user_home.helpers({
    interestNames: function(){
        var interests =  RadGrad.tag.getTagNames(Meteor.user().interestTagIDs);
        interests = interests.slice(0, 8);
        return interests;
    },
    degreeGoalNames: function(){
      return _.map(Meteor.user().degreeGoalIDs, function(degreeGoalID) {
        return RadGrad.degreegoal.findOne(degreeGoalID).name;
      });
    },
    major: function(){
        return findMajor(Meteor.user().degreeGoalIDs);
    },
    gradSemester: function(){
      return RadGrad.semester.toString(Meteor.user().semesterID)
    },
    remainingCourses: function(){
      // TODO: Finish implementing this
      return findRemainingCourses();
    },
    userGPA: function(){
        return getGPA();
    },
    tags: function(){
      return RagGrad.tags.fetch().find();

    }
});

Template.user_home.events({
    'click #openModal': function (event,template) {
      var self = this;
      $('#bio-modal').modal({
            onDeny    : function(){
              return false;
            }}).modal('show');
    },
    'click #openFeedModal': function (event,template) {
      var self = this;
      $('#feed-modal').modal({
            onDeny    : function(){
              return false;
            }}).modal('show');
    },
    'click #open-notify': function (event,template) {
      console.log("Open Notifications");
    },
    'click #edit_interests': function(event, template){
      console.log("Editing interests");
      $('#edit_interests_field').show();
    },
    'click #edit_goals': function(event, template){
      console.log("Editing goals");
      $('#edit_goals_section').show();
    },
});
