
Template.edit_goals.rendered = function(){
  this.autorun(function () {
    var tags = RadGrad.degreegoal.find().fetch();
    var tagNames = tags.map(function(t){
      return {
                title: t.name,
                description: t.description.substring(0,50) + "..."
             };
    });

    $('#goal_searchbar')
    .search({
      source: tagNames
    });
  });
}

Template.edit_goals.helpers({
  initSearch: function(){
  },
  goalNames: function(){
      return _.map(Meteor.user().degreeGoalIDs, function(degreeGoalID) {
        return RadGrad.degreegoal.findOne(degreeGoalID).name;
      });
  }
});

Template.edit_goals.events({
    'click #close_edit_goals': function(event){
        $('#edit_goals_section').hide();
    },
    'click #remove_goal': function(event, template){
      var self = this;
      var value = $(event.target).closest('td').siblings().find('.goal_field').text();
      var tagID = RadGrad.degreegoal.find({name: value}).fetch()[0]._id;

      let currentTags = Meteor.user().degreeGoalIDs;
      let newTags = _.without(currentTags, tagID);

      console.log(newTags);
      RadGrad.user.setDegreeGoalIDs(Meteor.user()._id, newTags)

    },
    'click #add_goal': function(event){
        var val = $('#goal_searchbar').search('get value');
        console.log(val);
        $('#goal_searchbar').search('set value', "");
        var tag = RadGrad.degreegoal.find({name: val}).fetch()[0];

        var tagIDs = Meteor.user().degreeGoalIDs;

        if( tagIDs ){
            if(tagIDs.includes(tag._id)) return false;
        }
        else{
            tagIDs = [];
        }
        if(!RadGrad.degreegoal.findOne(tag._id)) return false;

        tagIDs.push(tag._id);
        RadGrad.user.setDegreeGoalIDs(Meteor.user()._id, tagIDs)
    }
});
