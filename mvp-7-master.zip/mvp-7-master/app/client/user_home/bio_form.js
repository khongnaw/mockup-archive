Template.bio_form.events({
    'click #edit-bio': function(event, template){
      console.log("Editing bio");
      var text = $('#userBio').val();

      RadGrad.user.setAboutMe(Meteor.user()._id, text);
      console.log("Done saving bio.");
    }
});
