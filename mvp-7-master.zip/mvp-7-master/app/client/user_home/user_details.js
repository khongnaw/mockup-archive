Template.user_details.helpers({
    courses: function(){
        return RadGrad.course.collection.find().fetch();
    },
    courseInstances: function(){
        let courseInstances = RadGrad.courseinstance.collection.find().fetch();
        return courseInstances.map(function(ci){
          ci.courseName = RadGrad.courseinstance.findCourseName(ci._id);
          ci.semesterName = RadGrad.semester.toString(ci.semesterID);
          return ci;
        });
    }
});
