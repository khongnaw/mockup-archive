Template.opportunity.helpers({
    opportunity: function(){
        var id = FlowRouter.getParam('opportunityId');
        opportunity = RadGrad.opportunity.findOne(id);
        return opportunity;
    }
});
