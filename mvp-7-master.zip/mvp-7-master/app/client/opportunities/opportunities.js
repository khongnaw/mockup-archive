Template.opportunities.helpers({
    opportunities: function(){
        return RadGrad.opportunity.find().fetch();
    }
});
