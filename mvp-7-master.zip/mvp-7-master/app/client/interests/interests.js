Template.interests.helpers({
    interests: function(){
        return RadGrad.tag.find().fetch();
    }
});
