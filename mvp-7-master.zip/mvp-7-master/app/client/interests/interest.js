Template.interest.helpers({
    interest: function(){
        var id = FlowRouter.getParam('interestId');
        var interest = RadGrad.tag.findOne(id);
        return interest;
    }
});

