Accounts.onLogin(function() {
    var path = FlowRouter.current().path;
    // we only do it if the user is in the login page
    if(path === "/"){
        FlowRouter.go("/user");
    }
    else{
        BlazeLayout.reset();
        FlowRouter.reload();
    }
    Meteor.subscribe('MyCourses');
    Meteor.subscribe('MyOpp');
});

FlowRouter.route('/user', {
    action: function(params, queryParams) {
        console.log("Yeah! We are on the default user page.");
        BlazeLayout.render('default', {main: 'user_home'});
    }
});

FlowRouter.route('/user/settings', {
    action: function(params, queryParams) {
        console.log("Yeah! We are on the user settings page.");
        BlazeLayout.render('default_column', {main: 'user_settings'});
    }
});

FlowRouter.route('/user/details', {
    action: function(params, queryParams) {
        console.log("Yeah! We are on the user settings page.");
        BlazeLayout.render('default_column', {main: 'user_details'});
    }
});

FlowRouter.route('/user/:userId', {
    action: function(params, queryParams) {
        console.log("Yeah! We are on the user page of a specific user. ", params.userId);
        BlazeLayout.render('user_home');
    }
});

FlowRouter.route('/degree', {
    action: function(params, queryParams) {
        BlazeLayout.render('degree');
        console.log("Yeah! We are on the degree page.");
    }
});

FlowRouter.route('/', {
    action: function(params, queryParams) {
        BlazeLayout.render('landing');
        console.log("Yeah! We are on the landing page.");
    }
});

FlowRouter.route('/testdegree', {
    action: function(params, queryParams) {
        BlazeLayout.render('testdegree');
        console.log("Testing degree plan redo");
    }
});

FlowRouter.route('/admin', {
    action: function(params, queryParams) {
        console.log("Yeah! We are on the user page.");
        BlazeLayout.render('default', {main: 'admin'});
    }
});

FlowRouter.route('/opportunities/', {
    action: function(params, queryParams) {
        console.log("Yeah! We're listing opportunities.");
        BlazeLayout.render('info', {main: 'opportunities'});
    }
});


FlowRouter.route('/opportunities/:opportunityId', {
    action: function(params, queryParams) {
        console.log("Yeah! We're one opportunities.");
        BlazeLayout.render('info', {main: 'opportunity'}, {params:params});
    }
});

FlowRouter.route('/events/', {
    action: function(params, queryParams) {
        console.log("Yeah! We're multiple events.");
        BlazeLayout.render('info', {main: 'events'});
    }
});

FlowRouter.route('/events/:eventId', {
    action: function(params, queryParams) {
        console.log("Yeah! We're listing events.");
        BlazeLayout.render('info', {main: 'event'}, {params: params}); }
});

FlowRouter.route('/interests/', {
    action: function(params, queryParams) {
        console.log("Yeah! We're listing multiple interests.");
        BlazeLayout.render('info', {main: 'interests'});
    }
});

FlowRouter.route('/interests/:interestId', {
    action: function(params, queryParams) {
        console.log("Yeah! We're one interest.");
        BlazeLayout.render('info', {main: 'interest'});
    }
});
