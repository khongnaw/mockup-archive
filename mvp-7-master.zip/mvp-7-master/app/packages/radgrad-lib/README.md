radgrad:lib implements the third party dependencies for [RadGrad](http://radgrad.org).

See the [data-model-example](https://github.com/radgrad/data-model-example) repository for an example application built using this package. 