export function findMajor(degreeGoalIDs){
    var degreeGoalNames = degreeGoalIDs.map(function(dgID){
        return RadGrad.degreegoal.findOne(dgID).name;
    });

    if( inArray(degreeGoalNames, "Computer Science") ){
        return "Computer Science";
    }
    else if( inArray(degreeGoalNames, "Computer Engineering") ){
        return "Computer Engineering";
    }
    else{
        return "Unknown Degree";
    }

}

// Checks to see if a string is contained in any of the elements
// of a specific array

function inArray(array, string){
    var found = false;
    array.forEach(function(x){
        if(x.includes(string)){
            found = true;
        }
    });

    return found;
}


// Attempts to estimate how many remaining courses a user has to take
export function findRemainingCourses(degreePlanID){
    // TODO: Finish implementing this
    return 20;
}

