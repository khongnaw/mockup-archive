/**
 * This function defines an array of users.
 * To be invoked in LoadDataModel.js.
 *
 * Created by Josephine Garces
 */

defineUsersJgarces = function() {
  let sampleUsers = [
    {
      firstName: "Ale",
      middleName: "",
      lastName: "Alex",
      slug: "alealex",
      password: "foo",
      uhEmail: "aalex@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Danny",
      middleName: "",
      lastName: "Lewis",
      slug: "dannylewis",
      password: "foo",
      uhEmail: "dlewis@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Eun",
      middleName: "",
      lastName: "Kyung",
      slug: "eunkyung",
      password: "foo",
      uhEmail: "ekyung@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Florence",
      middleName: "",
      lastName: "Morgan",
      slug: "florencemorgan",
      password: "foo",
      uhEmail: "fmorgan@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Garnett",
      middleName: "",
      lastName: "Jaylin",
      slug: "garnettjaylin",
      password: "foo",
      uhEmail: "gjaylin@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Jordan",
      middleName: "",
      lastName: "Merrow",
      slug: "jordanmerrow",
      password: "foo",
      uhEmail: "jmerrow@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Michi",
      middleName: "",
      lastName: "Yoshi",
      slug: "michiyoshi",
      password: "foo",
      uhEmail: "myoshi@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Somi",
      middleName: "",
      lastName: "Jewel",
      slug: "somijewel",
      password: "foo",
      uhEmail: "sjewel@hawaii.edu",
      role: RadGrad.role.student
    }
  ];

  _.each(sampleUsers, RadGrad.user.define);
};

