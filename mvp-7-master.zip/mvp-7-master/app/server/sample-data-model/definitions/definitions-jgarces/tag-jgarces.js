/**
 * This function defines an array of tags.
 * To be invoked in LoadDataModel.js.
 *
 * Created by Josephine Garces | February 2, 2016
 */
defineTagJgarces = function() {
  let jgarcesTags = [

      /* Opportunities */


  ];

  _.each(jgarcesTags, RadGrad.tag.define);
};