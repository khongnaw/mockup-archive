/**
 * Created by mike on 1/27/2016.
 */

defineStudentProfileJenniferJones = function() {
  let acID = RadGrad.user.findBySlug("jenniferjones")._id;

  let workInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2015), hrswk: 20, studentID: acID},
  ];

  let workInstanceIDs = _.map(workInstanceData, RadGrad.workinstance.define);

  let courseInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics111", verified: true, grade: "A", studentID: acID, credithrs : 4},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics141", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: true, grade: "B", studentID: acID},

    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics211", verified: true, grade: "A",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics212", verified: true, grade: "B",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics241", verified: true, grade: "B",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: true, grade: "A",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: true,  grade: "A",studentID: acID},



  ];

  let courseInstanceIDs = _.map(courseInstanceData, RadGrad.courseinstance.define);

  let opportunityInstanceData = [

    {semesterID: RadGrad.semester.get("Fall", 2015), opportunity: "acm-manoa", verified: true, hrswk: 1, studentID: acID}


  ];

  let opportunityInstanceIDs = _.map(opportunityInstanceData, RadGrad.opportunityinstance.define);

  let degreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: courseInstanceIDs,
    opportunityInstanceIDs: opportunityInstanceIDs,
    workInstanceIDs: workInstanceIDs,
    studentID: acID
  });

  RadGrad.user.setDegreePlanID(acID, degreePlan);
  RadGrad.user.setDegreeGoalIDs(acID,
      [RadGrad.slug.getEntityID("network-engineer", "DegreeGoal"), RadGrad.slug.getEntityID("database-administrator", "DegreeGoal") ]);
  //RadGrad.slug.getEntityID("ba-cs-it", "DegreeGoal")
  //RadGrad.slug.getEntityID("bs-cs", "DegreeGoal")
  RadGrad.user.setInterestTagIDs(acID,
      [RadGrad.slug.getEntityID("business", "Tag"),
        RadGrad.slug.getEntityID("dotnet", "Tag"),
        RadGrad.slug.getEntityID("mobile-devices", "Tag"),
        RadGrad.slug.getEntityID("php", "Tag"),
        RadGrad.slug.getEntityID("education", "Tag"),
        RadGrad.slug.getEntityID("linux", "Tag"),
        RadGrad.slug.getEntityID("accounting", "Tag"),
        RadGrad.slug.getEntityID("india", "Tag"),
        RadGrad.slug.getEntityID("finance", "Tag"),
        RadGrad.slug.getEntityID("windows", "Tag"),
        RadGrad.slug.getEntityID("system-programming", "Tag"),
        RadGrad.slug.getEntityID("ruby", "Tag"),
        RadGrad.slug.getEntityID("php", "Tag")]);

  RadGrad.user.setPicture(acID, "https://www.nyu.edu/about/news-publications/news/2012/04/09/nyus-department-of-photography-imaging-and-tisch-student-affairs-to-host-headshots-for-the-philippines-/jcr:content/image.img.jpg/1333978098598.jpg");
  RadGrad.user.setAboutMe(acID, "I am a freshman at UH and new to the computer science program.  I want to find a job in IT because that is what my older brother does and he has a pretty good job.  I don't know too much about computers or programming but I'm excited to start learning.");
  RadGrad.user.setSemesterID(acID, RadGrad.semester.get("Spring", 2016));
};
