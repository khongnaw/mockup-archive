/**
 * Created by mike on 1/27/2016.
 */
defineUsersmichael4 = function() {
  let Users = [
    {
      firstName: "Jennifer",
      middleName: "",
      lastName: "Jones",
      slug: "jenniferjones",
      password: "foo",
      uhEmail: "jenniferjones@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Michael",
      middleName: "",
      lastName: "Miller",
      slug: "michaelmiller",
      password: "foo",
      uhEmail: "michaelmiller@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Derek",
      middleName: "",
      lastName: "Dupont",
      slug: "derekdupont",
      password: "foo",
      uhEmail: "derekdupont@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Jose",
      middleName: "",
      lastName: "Jimenez",
      slug: "josejimenez",
      password: "foo",
      uhEmail: "josejimenez@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Nathan",
      middleName: "",
      lastName: "Norton",
      slug: "nathannorton",
      password: "foo",
      uhEmail: "nathannorton@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Lilly",
      middleName: "",
      lastName: "Li",
      slug: "lillyli",
      password: "foo",
      uhEmail: "lillyli@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Alexander",
      middleName: "",
      lastName: "Anderson",
      slug: "alexanderanderson",
      password: "foo",
      uhEmail: "alexanderanderson@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Bobby",
      middleName: "",
      lastName: "Boomhower",
      slug: "bobbyboomhower",
      password: "foo",
      uhEmail: "bobbyboomhower@hawaii.edu",
      role: RadGrad.role.student
    }
  ];

  _.each(Users, RadGrad.user.define);
}