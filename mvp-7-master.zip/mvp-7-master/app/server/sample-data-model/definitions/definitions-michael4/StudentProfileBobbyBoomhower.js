/**
 * Created by mike on 1/27/2016.
 */


defineStudentProfileBobbyBoomhower = function() {
  let acID = RadGrad.user.findBySlug("bobbyboomhower")._id;

  let workInstanceData = [


  ];

  let workInstanceIDs = _.map(workInstanceData, RadGrad.workinstance.define);

  let courseInstanceData = [
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth2xx", verified: true, grade: "A", studentID: acID, credithrs : 4},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth2xx", verified: true, grade: "A", studentID: acID},

    {semesterID: RadGrad.semester.get("Fall", 2013), course: "ics212", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "ics311", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth3xx", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: true, grade: "A", studentID: acID},


    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth1xx", verified: true, grade: "A",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth3xx", verified: true, grade: "A",studentID: acID,credithrs : 4},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: true, grade: "A",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth1xx", verified: true, grade: "A",studentID: acID},


    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: true,  grade: "A",studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee211", verified: true, grade: "B+",studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: true, grade: "A",studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: true, grade: "B",studentID: acID},


    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee260", verified: true, grade: "A",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee213", verified: true, grade: "B",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee396", verified: true, grade: "A",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee406", verified: true, grade: "B",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth2xx", verified: true, grade: "A",studentID: acID},

    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee315", verified: true, grade: "B",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee468", verified: true, grade: "A",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee361", verified: true, grade: "B",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ics314", verified: true, grade: "A",studentID: acID},

    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ee296", verified: true,  grade: "A",studentID: acID}


  ];

  let courseInstanceIDs = _.map(courseInstanceData, RadGrad.courseinstance.define);

  let opportunityInstanceData = [



  ];

  let opportunityInstanceIDs = _.map(opportunityInstanceData, RadGrad.opportunityinstance.define);

  let degreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: courseInstanceIDs,
    opportunityInstanceIDs: opportunityInstanceIDs,
    workInstanceIDs: workInstanceIDs,
    studentID: acID
  });

  RadGrad.user.setDegreePlanID(acID, degreePlan);
  RadGrad.user.setDegreeGoalIDs(acID,
      [RadGrad.slug.getEntityID("computer-system-engineer", "DegreeGoal"), RadGrad.slug.getEntityID("information-security-analyst", "DegreeGoal")]);
  //RadGrad.slug.getEntityID("ba-cs-it", "DegreeGoal")
  //RadGrad.slug.getEntityID("bs-cs", "DegreeGoal")
  RadGrad.user.setInterestTagIDs(acID,
      [RadGrad.slug.getEntityID("electrical-engineering", "Tag"),
        RadGrad.slug.getEntityID("computer-engineering", "Tag"),
        RadGrad.slug.getEntityID("computer-security", "Tag"),
        RadGrad.slug.getEntityID("cryptography", "Tag"),
        RadGrad.slug.getEntityID("linguistics", "Tag"),
        RadGrad.slug.getEntityID("communications", "Tag"),
        RadGrad.slug.getEntityID("software-engineering", "Tag"),
        RadGrad.slug.getEntityID("telecommunications", "Tag"),
        RadGrad.slug.getEntityID("c", "Tag"),
        RadGrad.slug.getEntityID("dod", "Tag"),
        RadGrad.slug.getEntityID("wireless-networks", "Tag"),
        RadGrad.slug.getEntityID("network-security", "Tag")]);

  RadGrad.user.setPicture(acID, "http://cdn.c.photoshelter.com/img-get2/I0000n1fPbeoPjd8/fit=1000x750/College-Student.jpg");
  RadGrad.user.setAboutMe(acID, "I was a longtime employee working for the DOD but now I've decided to go back to school to get my engineering degree and switch to the private sector.  I want to build a strong academic foundation to augment my job experiences in the CS field and make lots and lots of money.");
  RadGrad.user.setSemesterID(acID, RadGrad.semester.get("Fall", 2016));
};
