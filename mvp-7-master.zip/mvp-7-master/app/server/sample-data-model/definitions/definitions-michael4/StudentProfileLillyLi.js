/**
 * Created by mike on 1/27/2016.
 */

defineStudentProfileLillyLi = function() {
  let acID = RadGrad.user.findBySlug("lillyli")._id;

  let workInstanceData = [
  ];

  let workInstanceIDs = _.map(workInstanceData, RadGrad.workinstance.define);

  let courseInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "ics111", verified: true, grade: "B", studentID: acID, credithrs : 4},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "ics141", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: true, grade: "B", studentID: acID},

    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ics211", verified: true, grade: "B",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ics241", verified: true, grade: "B",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: true, grade: "A",studentID: acID,credithrs : 4},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: true, grade: "A",studentID: acID},

    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ics331", verified: true, grade: "B",studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ics212", verified: true, grade: "B",studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ics314", verified: true, grade: "A",studentID: acID,credithrs : 4},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: true, grade: "B",studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: true,  grade: "A",studentID: acID},

    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ics311", verified: true, grade: "C",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ics361", verified: true, grade: "B",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth2xx", verified: true, grade: "A",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth2xx", verified: true, grade: "B",studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth2xx", verified: true,  grade: "A",studentID: acID},

    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics332", verified: true, grade: "A",studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth3xx", verified: true, grade: "B",studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth3xx", verified: true, grade: "B",studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics421", verified: true, grade: "A",studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth3xx", verified: true,  grade: "B",studentID: acID},



  ];

  let courseInstanceIDs = _.map(courseInstanceData, RadGrad.courseinstance.define);

  let opportunityInstanceData = [

    {semesterID: RadGrad.semester.get("Fall", 2014), opportunity: "itma-manoa", verified: true, hrswk: 1, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), opportunity: "itma-manoa", verified: true, hrswk: 1, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), opportunity: "itma-manoa", verified: true, hrswk: 1, studentID: acID}


  ];

  let opportunityInstanceIDs = _.map(opportunityInstanceData, RadGrad.opportunityinstance.define);

  let degreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: courseInstanceIDs,
    opportunityInstanceIDs: opportunityInstanceIDs,
    workInstanceIDs: workInstanceIDs,
    studentID: acID
  });

  RadGrad.user.setDegreePlanID(acID, degreePlan);
  RadGrad.user.setDegreeGoalIDs(acID,
      [RadGrad.slug.getEntityID("business-intelligence-analyst", "DegreeGoal"), RadGrad.slug.getEntityID("web-developer", "DegreeGoal"), RadGrad.slug.getEntityID("operations-research-analyst", "DegreeGoal")/*, RadGrad.slug.getEntityID("bs-ce", "DegreeGoal") */]);
  //RadGrad.slug.getEntityID("ba-cs-it", "DegreeGoal")
  //RadGrad.slug.getEntityID("bs-cs", "DegreeGoal")
  RadGrad.user.setInterestTagIDs(acID,
      [RadGrad.slug.getEntityID("west-us", "Tag"),
        RadGrad.slug.getEntityID("azure", "Tag"),
        RadGrad.slug.getEntityID("finance", "Tag"),
        RadGrad.slug.getEntityID("journalism", "Tag"),
        RadGrad.slug.getEntityID("java", "Tag"),
        RadGrad.slug.getEntityID("political-science", "Tag"),
        RadGrad.slug.getEntityID("react", "Tag"),
        RadGrad.slug.getEntityID("ios", "Tag"),
        RadGrad.slug.getEntityID("jquery", "Tag"),
        RadGrad.slug.getEntityID("git", "Tag"),
        RadGrad.slug.getEntityID("mobile-devices", "Tag"),
        RadGrad.slug.getEntityID("oop", "Tag"),
        RadGrad.slug.getEntityID("data-visualization", "Tag"),
        RadGrad.slug.getEntityID("communications", "Tag"),
        RadGrad.slug.getEntityID("software-engineering", "Tag"),
        RadGrad.slug.getEntityID("artificial-intelligence", "Tag")]);

  RadGrad.user.setPicture(acID, "http://www.terry.uga.edu/media/images/students/undergrad-photos.jpg");
  RadGrad.user.setAboutMe(acID, "I'm currently a junior in the ICS program and I'm also taking classes at Schidler to get my minor in business.  Since last summer, I've been working at an internship for a company downtown and I can't wait to graduate at start working full time.  ");
  RadGrad.user.setSemesterID(acID, RadGrad.semester.get("Spring", 2017));
};
