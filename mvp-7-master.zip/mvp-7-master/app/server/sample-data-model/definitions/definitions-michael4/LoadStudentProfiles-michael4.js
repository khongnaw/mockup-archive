/**
 * Created by mike on 1/27/2016.
 */
defineStudentProfilesmichael4 = function () {
  defineStudentProfileJenniferJones();
  defineStudentProfileMichaelMiller();
  defineStudentProfileDerekDupont();
  defineStudentProfileJoseJimenez();
  defineStudentProfileNathanNorton();
  defineStudentProfileLillyLi();
  defineStudentProfileAlexanderAnderson();
  defineStudentProfileBobbyBoomhower();

}
