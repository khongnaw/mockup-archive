defineStudentProfileBoraKim = function() {
    let acID = RadGrad.user.findBySlug("borakim")._id;

    let sampleWorkInstanceData = [
        {semesterID: RadGrad.semester.get("Fall", 2013), hrswk: 14, studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2014), hrswk: 14, studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2015), hrswk: 14, studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2014), hrswk: 14, studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2015), hrswk: 14, studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2016), hrswk: 14, studentID: acID},
        {semesterID: RadGrad.semester.get("Summer", 2013), hrswk: 25, studentID: acID},
        {semesterID: RadGrad.semester.get("Summer", 2014), hrswk: 25, studentID: acID},
        {semesterID: RadGrad.semester.get("Summer", 2015), hrswk: 25, studentID: acID}
    ];

    let sampleWorkInstanceIDs = _.map(sampleWorkInstanceData, RadGrad.workinstance.define);

    let sampleCourseInstanceData = [
        {semesterID: RadGrad.semester.get("Fall", 2013), course: "ics111", verified: true, grade: "B", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2013), course: "ics141", verified: true, grade: "B", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: true, grade: "B", studentID: acID, credithrs: 1},
        {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: true, grade: "B", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: true, grade: "B", studentID: acID, credithrs: 4},
        {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "B", studentID: acID, credithrs: 4},

        {semesterID: RadGrad.semester.get("Spring", 2014), course: "ics211", verified: true, grade: "B", studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2014), course: "ics241", verified: true, grade: "B", studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth1xx", verified: true, grade: "B", studentID: acID, credithrs: 1},
        {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth1xx", verified: true, grade: "B", studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth1xx", verified: true, grade: "B", studentID: acID, credithrs: 4},
        {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: true, grade: "B", studentID: acID, credithrs: 4},

        {semesterID: RadGrad.semester.get("Fall", 2014), course: "ics212", verified: true, grade: "B", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2014), course: "ics311", verified: true, grade: "B", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: true, grade: "B", studentID: acID, credithrs: 4},
        {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: true, grade: "B", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: true, grade: "B", studentID: acID, credithrs: 1},

        {semesterID: RadGrad.semester.get("Spring", 2015), course: "ics313", verified: true, grade: "B", studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2015), course: "ics321", verified: true, grade: "B", studentID: acID, credithrs: 4},
        {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth2xx", verified: true, grade: "B", studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth2xx", verified: true, grade: "B", studentID: acID, credithrs: 4},
        {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth3xx", verified: true, grade: "B", studentID: acID},

        {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics331", verified: true, grade: "B", studentID: acID, credithrs: 4},
        {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics215", verified: true, grade: "B", studentID: acID, credithrs: 4},
        {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: true, grade: "B", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: true, grade: "B", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: true, grade: "B", studentID: acID},

        {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics462", verified: false, studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics314", verified: false, studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: false, studentID: acID},

        {semesterID: RadGrad.semester.get("Fall", 2016), course: "ics332", verified: false, studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2016), course: "ics415", verified: false, studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth1xx", verified: false, studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth1xx", verified: false, studentID: acID},

        {semesterID: RadGrad.semester.get("Spring", 2017), course: "ics414", verified: false, studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2017), course: "ics466", verified: false, studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2017), course: "oth1xx", verified: false, studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2017), course: "oth1xx", verified: false, studentID: acID}
    ];

    let sampleCourseInstanceIDs = _.map(sampleCourseInstanceData, RadGrad.courseinstance.define);

    let sampleOpportunityInstanceData = [

        {semesterID: RadGrad.semester.get("Fall", 2013), opportunity: "acm-manoa", verified: true, hrswk: 1, studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2014), opportunity: "acm-manoa", verified: true, hrswk: 1, studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2015), opportunity: "acm-manoa", verified: true, hrswk: 1, studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2014), opportunity: "acm-manoa", verified: true, hrswk: 1, studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2015), opportunity: "acm-manoa", verified: true, hrswk: 1, studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2016), opportunity: "acm-manoa", verified: true, hrswk: 1, studentID: acID}
    ];

    let sampleOpportunityInstanceIDs = _.map(sampleOpportunityInstanceData, RadGrad.opportunityinstance.define);

    let sampleDegreePlan = RadGrad.degreeplan.define({
        courseInstanceIDs: sampleCourseInstanceIDs,
        opportunityInstanceIDs: sampleOpportunityInstanceIDs,
        workInstanceIDs: sampleWorkInstanceIDs,
        studentID: acID
    });

    RadGrad.user.setDegreePlanID(acID, sampleDegreePlan);
    RadGrad.user.setDegreeGoalIDs(acID, [RadGrad.slug.getEntityID("bs-cs", "DegreeGoal"),RadGrad.slug.getEntityID("web-developer", "DegreeGoal")]);
    RadGrad.user.setInterestTagIDs(acID, [RadGrad.slug.getEntityID("web-design", "Tag"),
        RadGrad.slug.getEntityID("database", "Tag"),
        RadGrad.slug.getEntityID("mobile-devices", "Tag")]);
    RadGrad.user.setPicture(acID, "http://caamedia.org/wp-content/uploads/2015/07/DSC8059-Edit.jpg?16cb17");
    RadGrad.user.setAboutMe(acID, "I am a junior in ICS.  I am interested in web design and mobile devices.  I want to pursue a career as a web developer.");
    RadGrad.user.setSemesterID(acID, RadGrad.semester.get("Spring", 2017));
};


