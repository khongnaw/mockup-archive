defineStudentProfileEmmyEmily = function() {
    let acID = RadGrad.user.findBySlug("emmyemily")._id;

    let sampleWorkInstanceData = [
        {semesterID: RadGrad.semester.get("Fall", 2015), hrswk: 20, studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2016), hrswk: 20, studentID: acID}
    ];

    let sampleWorkInstanceIDs = _.map(sampleWorkInstanceData, RadGrad.workinstance.define);

    let sampleCourseInstanceData = [
        {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: true, grade: "A", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: true, grade: "A", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: true, grade: "A", studentID: acID, credithrs: 1},
        {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: true, grade: "A", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: true, grade: "A", studentID: acID, credithrs: 4},
        {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: true, grade: "A", studentID: acID, credithrs: 4},

        {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: acID, credithrs: 4},
        {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: acID, credithrs: 1},
        {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: false, studentID: acID, credithrs: 4}
    ];

    let sampleCourseInstanceIDs = _.map(sampleCourseInstanceData, RadGrad.courseinstance.define);

    let sampleOpportunityInstanceData = [
    ];

    let sampleOpportunityInstanceIDs = _.map(sampleOpportunityInstanceData, RadGrad.opportunityinstance.define);

    let sampleDegreePlan = RadGrad.degreeplan.define({
        courseInstanceIDs: sampleCourseInstanceIDs,
        opportunityInstanceIDs: sampleOpportunityInstanceIDs,
        workInstanceIDs: sampleWorkInstanceIDs,
        studentID: acID
    });

    RadGrad.user.setDegreePlanID(acID, sampleDegreePlan);
    RadGrad.user.setDegreeGoalIDs(acID, [RadGrad.slug.getEntityID("bs-cs", "DegreeGoal")]);
    RadGrad.user.setInterestTagIDs(acID, [RadGrad.slug.getEntityID("software-engineering", "Tag"),
        RadGrad.slug.getEntityID("wireless-networks", "Tag"),
        RadGrad.slug.getEntityID("computer-architecture", "Tag")]);
    RadGrad.user.setPicture(acID, "http://i495.photobucket.com/albums/rr314/mandiemcmurdie/IMG_0426_edited-1.jpg");
    RadGrad.user.setAboutMe(acID, "I am a freshman in ICS.  I am interested in computer architecture.");
    RadGrad.user.setSemesterID(acID, RadGrad.semester.get("Spring", 2019));
};
