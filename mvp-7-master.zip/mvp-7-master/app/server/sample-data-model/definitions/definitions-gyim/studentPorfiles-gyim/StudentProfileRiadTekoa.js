defineStudentProfileRiadTekoa = function() {
    let acID = RadGrad.user.findBySlug("riadtekoa")._id;

    let sampleWorkInstanceData = [
        {semesterID: RadGrad.semester.get("Summer", 2013), hrswk: 25, studentID: acID},
        {semesterID: RadGrad.semester.get("Summer", 2014), hrswk: 25, studentID: acID}
    ];

    let sampleWorkInstanceIDs = _.map(sampleWorkInstanceData, RadGrad.workinstance.define);

    let sampleCourseInstanceData = [
        {semesterID: RadGrad.semester.get("Fall", 2012), course: "oth2xx", verified: true, grade: "A-", studentID: acID, credithrs: 4},
        {semesterID: RadGrad.semester.get("Fall", 2012), course: "oth1xx", verified: true, grade: "A-", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2012), course: "oth1xx", verified: true, grade: "A-", studentID: acID, credithrs: 1},
        {semesterID: RadGrad.semester.get("Fall", 2012), course: "oth1xx", verified: true, grade: "A-", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2012), course: "oth1xx", verified: true, grade: "A-", studentID: acID},

        {semesterID: RadGrad.semester.get("Spring", 2013), course: "ee160", verified: true, grade: "A+", studentID: acID, credithrs: 4},
        {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth1xx", verified: true, grade: "A-", studentID: acID, credithrs: 4},
        {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth1xx", verified: true, grade: "A-", studentID: acID, credithrs: 1},
        {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth1xx", verified: true, grade: "A-", studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth2xx", verified: true, grade: "A-", studentID: acID, credithrs: 4},

        {semesterID: RadGrad.semester.get("Summer", 2013), course: "oth2xx", verified: true, grade: "A", studentID: acID},

        {semesterID: RadGrad.semester.get("Fall", 2013), course: "ee211", verified: true, grade: "A-", studentID: acID, credithrs: 4},
        {semesterID: RadGrad.semester.get("Fall", 2013), course: "ee260", verified: true, grade: "A-", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: true, grade: "A-", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "A-", studentID: acID, credithrs: 4},
        {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "A-", studentID: acID},

        {semesterID: RadGrad.semester.get("Spring", 2014), course: "ee205", verified: true, grade: "A", studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2014), course: "ee296", verified: true, grade: "A", studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: true, grade: "A", studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: true, grade: "A", studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: true, grade: "A", studentID: acID, credithrs: 1},
        {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth3xx", verified: true, grade: "A", studentID: acID},
        
        {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee213", verified: true, grade: "A", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee324", verified: true, grade: "B", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee361", verified: true, grade: "A", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth1xx", verified: true, grade: "A", studentID: acID},

        {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee315", verified: true, grade: "A", studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee323", verified: true, grade: "A", studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee367", verified: true, grade: "A", studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee396", verified: true, grade: "A", studentID: acID, credithrs: 2},
        {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee406", verified: true, grade: "A", studentID: acID},

        {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee342", verified: true, grade: "A", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics141", verified: true, grade: "A", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee371", verified: true, grade: "A", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee468", verified: true, grade: "A", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics314", verified: true, grade: "A", studentID: acID},

        {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: false, studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee496", verified: false, studentID: acID}
    ];

    let sampleCourseInstanceIDs = _.map(sampleCourseInstanceData, RadGrad.courseinstance.define);

    let sampleOpportunityInstanceData = [
        {semesterID: RadGrad.semester.get("Fall", 2013), opportunity: "ieee-manoa", verified: true, hrswk: 1, studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2014), opportunity: "ieee-manoa", verified: true, hrswk: 1, studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2014), opportunity: "ieee-manoa", verified: true, hrswk: 1, studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2015), opportunity: "ieee-manoa", verified: true, hrswk: 1, studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2015), opportunity: "ieee-manoa", verified: true, hrswk: 1, studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2016), opportunity: "ieee-manoa", verified: true, hrswk: 1, studentID: acID}
    ];

    let sampleOpportunityInstanceIDs = _.map(sampleOpportunityInstanceData, RadGrad.opportunityinstance.define);

    let sampleDegreePlan = RadGrad.degreeplan.define({
        courseInstanceIDs: sampleCourseInstanceIDs,
        opportunityInstanceIDs: sampleOpportunityInstanceIDs,
        workInstanceIDs: sampleWorkInstanceIDs,
        studentID: acID
    });

    RadGrad.user.setDegreePlanID(acID, sampleDegreePlan);
    RadGrad.user.setDegreeGoalIDs(acID, [RadGrad.slug.getEntityID("computer-system-engineer", "DegreeGoal"), RadGrad.slug.getEntityID("robotics-engineer", "DegreeGoal")]);
    RadGrad.user.setInterestTagIDs(acID, [RadGrad.slug.getEntityID("software-engineering", "Tag"),
            RadGrad.slug.getEntityID("robotics", "Tag"),
            RadGrad.slug.getEntityID("computer-graphics", "Tag"),
            RadGrad.slug.getEntityID("circuit-design", "Tag"),
            RadGrad.slug.getEntityID("computer-engineering", "Tag")]);
    RadGrad.user.setPicture(acID, "http://us.123rf.com/450wm/ferli/ferli1203/ferli120300195/12809785-portrait-of-happy-asian-male-smiling-against-green-backgrounds.jpg?ver=6");
    RadGrad.user.setAboutMe(acID, "I am a senior in Computer Engineering.  I am interested in game design and robotics.  I want to pursue a career as a game designer or a robotics engineer.");
    RadGrad.user.setSemesterID(acID, RadGrad.semester.get("Spring", 2016));
};
