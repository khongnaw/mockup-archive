defineStudentProfileShiroMichi = function() {
    let acID = RadGrad.user.findBySlug("shiromichi")._id;

    let sampleWorkInstanceData = [
        {semesterID: RadGrad.semester.get("Fall", 2015), hrswk: 8, studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2016), hrswk: 8, studentID: acID}
    ];

    let sampleWorkInstanceIDs = _.map(sampleWorkInstanceData, RadGrad.workinstance.define);

    let sampleCourseInstanceData = [
        {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: true, grade: "A", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: true, grade: "A", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: true, grade: "A", studentID: acID, credithrs: 1},
        {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: true, grade: "A", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: true, grade: "A", studentID: acID, credithrs: 4},

        {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee160", verified: false, studentID: acID, credithrs: 4},
        {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: acID, credithrs: 1},
        {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: false, studentID: acID, credithrs: 4},

        {semesterID: RadGrad.semester.get("Fall", 2016), course: "ee211", verified: false, studentID: acID, credithrs: 4},
        {semesterID: RadGrad.semester.get("Fall", 2016), course: "ee260", verified: false, studentID: acID, credithrs: 4},
        {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth2xx", verified: false, studentID: acID, credithrs: 1},
        {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth2xx", verified: false, studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth2xx", verified: false, studentID: acID},

        {semesterID: RadGrad.semester.get("Spring", 2017), course: "ee213", verified: false, studentID: acID, credithrs: 4},
        {semesterID: RadGrad.semester.get("Spring", 2017), course: "ee205", verified: false, studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2017), course: "ee296", verified: false, studentID: acID, credithrs: 1},
        {semesterID: RadGrad.semester.get("Spring", 2017), course: "oth1xx", verified: false, studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2017), course: "oth2xx", verified: false, studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2017), course: "oth2xx", verified: false, studentID: acID, credithrs: 4}
    ];

    let sampleCourseInstanceIDs = _.map(sampleCourseInstanceData, RadGrad.courseinstance.define);

    let sampleOpportunityInstanceData = [
        {semesterID: RadGrad.semester.get("Fall", 2015), opportunity: "ieee-manoa", verified: true, hrswk: 1, studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2016), opportunity: "ieee-manoa", verified: true, hrswk: 1, studentID: acID}

    ];

    let sampleOpportunityInstanceIDs = _.map(sampleOpportunityInstanceData, RadGrad.opportunityinstance.define);

    let sampleDegreePlan = RadGrad.degreeplan.define({
        courseInstanceIDs: sampleCourseInstanceIDs,
        opportunityInstanceIDs: sampleOpportunityInstanceIDs,
        workInstanceIDs: sampleWorkInstanceIDs,
        studentID: acID
    });

    RadGrad.user.setDegreePlanID(acID, sampleDegreePlan);
    RadGrad.user.setDegreeGoalIDs(acID, [RadGrad.slug.getEntityID("robotics-engineer", "DegreeGoal")]);
    RadGrad.user.setInterestTagIDs(acID, [RadGrad.slug.getEntityID("artificial-intelligence", "Tag"),
        RadGrad.slug.getEntityID("robotics", "Tag"),
        RadGrad.slug.getEntityID("network-security", "Tag")]);
    RadGrad.user.setPicture(acID, "https://ocanational.site-ym.com/resource/resmgr/2014_Interns/OCA_Headshot_-_Kevin_Bautist.JPG");
    RadGrad.user.setAboutMe(acID, "I am a freshman in Computer Engineering.  I am interested in robotics.  I want to pursue a career as a drone designer and in robotics.");
    RadGrad.user.setSemesterID(acID, RadGrad.semester.get("Spring", 2019));
};

