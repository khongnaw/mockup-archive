defineUsers_gyim = function() {
    let Users = [
        {
            firstName: "Emmy",
            middleName: "",
            lastName: "Emily",
            slug: "emmyemily",
            password: "foo",
            uhEmail: "eemily@hawaii.edu",
            role: RadGrad.role.student
        },
        {
            firstName: "Vladimir",
            middleName: "",
            lastName: "Leilani",
            slug: "vladimirleilani",
            password: "foo",
            uhEmail: "vleilani@hawaii.edu",
            role: RadGrad.role.student
        },
        {
            firstName: "Shiro",
            middleName: "",
            lastName: "Michi",
            slug: "shiromichi",
            password: "foo",
            uhEmail: "smichi@hawaii.edu",
            role: RadGrad.role.student
        },
        {
            firstName: "Dinis",
            middleName: "",
            lastName: "Nuno",
            slug: "dinisnuno",
            password: "foo",
            uhEmail: "dnuno@hawaii.edu",
            role: RadGrad.role.student
        },
        {
            firstName: "Bora",
            middleName: "",
            lastName: "Kim",
            slug: "borakim",
            password: "foo",
            uhEmail: "bkim@hawaii.edu",
            role: RadGrad.role.student
        },
        {
            firstName: "Ruslan",
            middleName: "",
            lastName: "Orel",
            slug: "ruslanorel",
            password: "foo",
            uhEmail: "rorel@hawaii.edu",
            role: RadGrad.role.student
        },
        {
            firstName: "Brion",
            middleName: "",
            lastName: "Stevan",
            slug: "brionstevan",
            password: "foo",
            uhEmail: "bstevan@hawaii.edu",
            role: RadGrad.role.student
        },
        {
            firstName: "Riad",
            middleName: "",
            lastName: "Tekoa",
            slug: "riadtekoa",
            password: "foo",
            uhEmail: "rtekoa@hawaii.edu",
            role: RadGrad.role.student
        }
    ];

    _.each(Users, RadGrad.user.define);
}