defineStudentProfilesgyim = function () {
    defineStudentProfileEmmyEmily();
    defineStudentProfileVladamirLeilani();
    defineStudentProfileShiroMichi();
    defineStudentProfileDinisNuno();
    defineStudentProfileBoraKim();
    defineStudentProfileBrionStevan();
    defineStudentProfileRuslanOrel();
    defineStudentProfileRiadTekoa();

}

