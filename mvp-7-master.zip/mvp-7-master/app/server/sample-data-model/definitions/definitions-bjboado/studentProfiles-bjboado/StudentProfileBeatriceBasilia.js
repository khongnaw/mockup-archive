defineStudentProfileBeatriceBasilia = function() {
  let bID = RadGrad.user.findBySlug("beatricebasilia")._id;

  let sampleWorkInstanceData = [
    {semesterID: RadGrad.semester.get("Summer", 2016), hrswk: 15, studentID: bID},
    {semesterID: RadGrad.semester.get("Summer", 2016), hrswk: 15, studentID: bID},
    {semesterID: RadGrad.semester.get("Summer", 2016), hrswk: 15, studentID: bID}
  ];

  let sampleWorkInstanceIDs = _.map(sampleWorkInstanceData, RadGrad.workinstance.define);

  let sampleCourseInstanceData = [
    /* 2012 */
    {semesterID: RadGrad.semester.get("Fall", 2012), course: "ics111", verified: true, grade: "A", studentID: bID},
    {semesterID: RadGrad.semester.get("Fall", 2012), course: "ics141", verified: true, grade: "C", studentID: bID},
    {semesterID: RadGrad.semester.get("Fall", 2012), course: "oth1xx", verified: true, grade: "C", studentID: bID, credithrs: 4 },
    {semesterID: RadGrad.semester.get("Fall", 2012), course: "oth1xx", verified: true, grade: "C", studentID: bID},
    {semesterID: RadGrad.semester.get("Fall", 2012), course: "oth1xx", verified: true, grade: "C", studentID: bID},

    {semesterID: RadGrad.semester.get("Spring", 2012), course: "ics241", verified: true, grade: "C", studentID: bID},
    {semesterID: RadGrad.semester.get("Spring", 2012), course: "ics211", verified: true, grade: "B", studentID: bID},
    {semesterID: RadGrad.semester.get("Spring", 2012), course: "oth1xx", verified: true, grade: "A", studentID: bID, credithrs: 4},
    {semesterID: RadGrad.semester.get("Spring", 2012), course: "oth1xx", verified: true, grade: "A", studentID: bID},
    {semesterID: RadGrad.semester.get("Spring", 2012), course: "oth2xx", verified: true, grade: "A", studentID: bID},

    /* 2013 */
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "ics212", verified: true, grade: "A", studentID: bID},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "ics311", verified: true, grade: "C", studentID: bID},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "C", studentID: bID, credithrs: 4},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "C", studentID: bID},

    {semesterID: RadGrad.semester.get("Spring", 2013), course: "ics321", verified: true, grade: "C", studentID: bID},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "ics331", verified: true, grade: "B", studentID: bID},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth2xx", verified: true, grade: "A", studentID: bID, credithrs: 4},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth2xx", verified: true, grade: "A", studentID: bID},

    /* 2014 */
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ics212", verified: true, grade: "A", studentID: bID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ics311", verified: true, grade: "C", studentID: bID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: true, grade: "C", studentID: bID, credithrs: 4},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: true, grade: "C", studentID: bID},

    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ics321", verified: true, grade: "C", studentID: bID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ics331", verified: true, grade: "B", studentID: bID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: true, grade: "A", studentID: bID, credithrs: 4},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: true, grade: "A", studentID: bID},

    /* 2015 */
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics314", verified: true, grade: "A", studentID: bID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics361", verified: true, grade: "C", studentID: bID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: true, grade: "C", studentID: bID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: true, grade: "C", studentID: bID},

    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ics390", verified: true, grade: "C", studentID: bID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ics355", verified: true, grade: "B", studentID: bID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth2xx", verified: true, grade: "A", studentID: bID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth2xx", verified: true, grade: "A", studentID: bID},

    /* 2016 */

    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth3xx", verified: false, studentID: bID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics351", verified: false, studentID: bID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics332", verified: false, studentID: bID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics414", verified: false, studentID: bID},

    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ics466", verified: false, studentID: bID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth4xx", verified: false, studentID: bID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth4xx", verified: false, studentID: bID, credithrs: 4},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth4xx", verified: false, studentID: bID}
  ];

  let sampleCourseInstanceIDs = _.map(sampleCourseInstanceData, RadGrad.courseinstance.define);

  let sampleOpportunityInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2015), opportunity: "hicapacity", verified: true, hrswk: 5, studentID: bID},
    {semesterID: RadGrad.semester.get("Spring", 2015), opportunity: "hicapacity", verified: true, hrswk: 5, studentID: bID},
    {semesterID: RadGrad.semester.get("Spring", 2015), opportunity: "global-game-jam", verified: true, hrswk: 20, studentID: bID}
  ];

  let sampleOpportunityInstanceIDs = _.map(sampleOpportunityInstanceData, RadGrad.opportunityinstance.define);

  let sampleDegreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: sampleCourseInstanceIDs,
    opportunityInstanceIDs: sampleOpportunityInstanceIDs,
    workInstanceIDs: sampleWorkInstanceIDs,
    studentID: bID
  });

  RadGrad.user.setDegreePlanID(bID, sampleDegreePlan);
  RadGrad.user.setDegreeGoalIDs(bID, [RadGrad.slug.getEntityID("ba-ics", "DegreeGoal")]);

  RadGrad.user.setInterestTagIDs(bID,
      [RadGrad.slug.getEntityID("ilokano", "Tag"),
        RadGrad.slug.getEntityID("music", "Tag"),
        RadGrad.slug.getEntityID("foreign-languages", "Tag"),
        RadGrad.slug.getEntityID("web-design", "Tag")
      ]);

  RadGrad.user.setPicture(bID, "http://cdn.images.express.co.uk/img/dynamic/1/285x214/295416_1.jpg");
  RadGrad.user.setAboutMe(bID, "I've taken a majority of the ICS courses and I want to double major in a foreign language.");
  RadGrad.user.setSemesterID(bID, RadGrad.semester.get("Fall", 2016));
};
