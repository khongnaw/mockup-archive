defineStudentProfileCecilleCayne = function() {
  let cID = RadGrad.user.findBySlug("cecillecayne")._id;

  let sampleWorkInstanceData = [
  ];

  let sampleWorkInstanceIDs = _.map(sampleWorkInstanceData, RadGrad.workinstance.define);

  let sampleCourseInstanceData = [
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth3xx", verified: false, studentID: cID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics351", verified: false, studentID: cID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics332", verified: false, studentID: cID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics414", verified: false, studentID: cID},

    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ics466", verified: false, studentID: cID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth4xx", verified: false, studentID: cID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth4xx", verified: false, studentID: cID, credithrs: 4},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth4xx", verified: false, studentID: cID}
  ];

  let sampleCourseInstanceIDs = _.map(sampleCourseInstanceData, RadGrad.courseinstance.define);

  let sampleOpportunityInstanceData = [
  ];

  let sampleOpportunityInstanceIDs = _.map(sampleOpportunityInstanceData, RadGrad.opportunityinstance.define);

  let sampleDegreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: sampleCourseInstanceIDs,
    opportunityInstanceIDs: sampleOpportunityInstanceIDs,
    workInstanceIDs: sampleWorkInstanceIDs,
    studentID: cID
  });

  RadGrad.user.setDegreePlanID(cID, sampleDegreePlan);
  RadGrad.user.setDegreeGoalIDs(cID, [RadGrad.slug.getEntityID("ba-ics", "DegreeGoal")]);

  RadGrad.user.setInterestTagIDs(cID,
      [RadGrad.slug.getEntityID("ilokano", "Tag"),
        RadGrad.slug.getEntityID("music", "Tag"),
        RadGrad.slug.getEntityID("foreign-languages", "Tag"),
      ]);

  RadGrad.user.setPicture(cID, "http://images6.fanpop.com/image/photos/36100000/Wonder-Girls-image-wonder-girls-36160513-200-200.png");
  RadGrad.user.setAboutMe(cID, "I've taken a majority of the ICS courses and I want to double major in a foreign language.");
  RadGrad.user.setSemesterID(cID, RadGrad.semester.get("Fall", 2016));
};
