defineStudentProfileCatherineCuzon = function() {
  let ccID = RadGrad.user.findBySlug("catherinecuzon")._id;

  let sampleWorkInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2016), hrswk: 13, studentID: ccID},
    {semesterID: RadGrad.semester.get("Spring", 2016), hrswk: 13, studentID: ccID}
  ];

  let sampleWorkInstanceIDs = _.map(sampleWorkInstanceData, RadGrad.workinstance.define);

  let sampleCourseInstanceData = [
    /* 2016 */
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics111", verified: false, studentID: ccID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics141", verified: false, studentID: ccID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: ccID, credithrs: 4},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: ccID},

    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ics211", verified: false, studentID: ccID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ics241", verified: false, studentID: ccID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth1xx", verified: false, studentID: ccID, credithrs: 4},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth2xx", verified: false, studentID: ccID}
  ];

  let sampleCourseInstanceIDs = _.map(sampleCourseInstanceData, RadGrad.courseinstance.define);

  let sampleOpportunityInstanceData = [
  ];

  let sampleOpportunityInstanceIDs = _.map(sampleOpportunityInstanceData, RadGrad.opportunityinstance.define);

  let sampleDegreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: sampleCourseInstanceIDs,
    opportunityInstanceIDs: sampleOpportunityInstanceIDs,
    workInstanceIDs: sampleWorkInstanceIDs,
    studentID: ccID
  });

  RadGrad.user.setDegreePlanID(ccID, sampleDegreePlan);
  RadGrad.user.setDegreeGoalIDs(ccID, [RadGrad.slug.getEntityID("ba-ics", "DegreeGoal")]);

  RadGrad.user.setInterestTagIDs(ccID,
      [RadGrad.slug.getEntityID("dynamic-programming", "Tag"),
        RadGrad.slug.getEntityID("c", "Tag"),
        RadGrad.slug.getEntityID("cplusplus", "Tag"),
        RadGrad.slug.getEntityID("web-design", "Tag"),
        RadGrad.slug.getEntityID("software-engineering", "Tag"),

      ]);

  RadGrad.user.setPicture(ccID, "http://media.discovernikkei.org/articles/authors/Leah_square209.jpg");
  RadGrad.user.setAboutMe(ccID, "I am a freshman still undecided on what I want to focus on for ICS. So far I have taken the first 2 levels while working part time.");
  RadGrad.user.setSemesterID(ccID, RadGrad.semester.get("Fall", 2020));
};
