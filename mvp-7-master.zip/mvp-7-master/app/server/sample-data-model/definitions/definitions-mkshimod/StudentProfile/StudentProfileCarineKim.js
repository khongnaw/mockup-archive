defineStudentProfileCarineKim = function() {
  let ckID = RadGrad.user.findBySlug("carinekim")._id;

  let CarineKimWorkInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2014), hrswk: 15, studentID: ckID},
    {semesterID: RadGrad.semester.get("Spring", 2014), hrswk: 15, studentID: ckID},
    {semesterID: RadGrad.semester.get("Summer", 2014), hrswk: 40, studentID: ckID},
    {semesterID: RadGrad.semester.get("Fall", 2015), hrswk: 15, studentID: ckID},
    {semesterID: RadGrad.semester.get("Spring", 2015), hrswk: 15, studentID: ckID},
    {semesterID: RadGrad.semester.get("Summer", 2015), hrswk: 40, studentID: ckID},
    {semesterID: RadGrad.semester.get("Fall", 2015), hrswk: 15, studentID: ckID},
    {semesterID: RadGrad.semester.get("Spring", 2015), hrswk: 15, studentID: ckID}
  ];

  let CarineKimWorkInstanceIDs = _.map(CarineKimWorkInstanceData, RadGrad.workinstance.define);

  let CarineKimCourseInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth1xx", verified: false, grade: "A", studentID: ckID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: false, grade: "B", credithrs: 4, studentID: ckID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth1xx", verified: false, grade: "B", studentID: ckID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth1xx", verified: false, grade: "B", credithrs: 1, studentID: ckID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth1xx", verified: false, grade: "B+", studentID: ckID},

    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ee160", verified: false, grade: "B+", credithrs: 4, studentID: ckID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: false, grade: "A-", credithrs: 4, studentID: ckID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth1xx", verified: false, grade: "B+", credithrs: 4, studentID: ckID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: false, grade: "A", credithrs: 1, studentID: ckID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth1xx", verified: false, grade: "B", studentID: ckID},

    {semesterID: RadGrad.semester.get("Summer", 2014), course: "oth1xx", verified: false, grade: "A", studentID: ckID},

    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee211", verified: false, grade: "B+", studentID: ckID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee260", verified: false, grade: "B+", credithrs: 4, studentID: ckID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: false, grade: "B-", studentID: ckID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: false, grade: "B", credithrs: 1, studentID: ckID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: false, grade: "A", credithrs: 1, studentID: ckID},

    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ics314", verified: false, grade: "A", studentID: ckID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ics311", verified: false, grade: "A", studentID: ckID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth2xx", verified: false, grade: "A", studentID: ckID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth2xx", verified: false, grade: "B", studentID: ckID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth1xx", verified: false, grade: "A", studentID: ckID},

    {semesterID: RadGrad.semester.get("Summer", 2015), course: "oth2xx", verified: false, grade: "B", studentID: ckID},

    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ee324", verified: false, grade: "B", studentID: ckID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ee371", verified: false, grade: "B+", credithrs: 4, studentID: ckID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ee361", verified: false, grade: "A", studentID: ckID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ee361", verified: false, grade: "A", credithrs: 1, studentID: ckID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ee396", verified: false, grade: "B+", credithrs: 2, studentID: ckID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ics141", verified: false, grade: "A", studentID: ckID},

    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee315", verified: false, studentID: ckID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee323", verified: false, studentID: ckID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee323", verified: false, credithrs: 1, studentID: ckID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee367", verified: false, studentID: ckID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee367", verified: false, credithrs: 1, studentID: ckID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics311", verified: false, studentID: ckID}
  ];

  let CarineKimCourseInstanceIDs = _.map(CarineKimCourseInstanceData, RadGrad.courseinstance.define);

  let CarineKimOpportunityInstanceData = [];
  let CarineKimOpportunityIDs = _.map(CarineKimOpportunityInstanceData, RadGrad.opportunityinstance.define);

  let CarineKimDegreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: CarineKimCourseInstanceIDs,
    opportunityInstanceIDs: CarineKimOpportunityIDs,
    workInstanceIDs: CarineKimWorkInstanceIDs,
    studentID: ckID
  });

  RadGrad.user.setDegreePlanID(ckID, CarineKimDegreePlan);
  RadGrad.user.setDegreeGoalIDs(ckID, [
    RadGrad.slug.getEntityID("robotics-engineer", "DegreeGoal"),
    RadGrad.slug.getEntityID("bs-ce", "DegreeGoal"),
      /*RadGrad.slug.getEntityID("masters-degree", "DegreeGoal")*/
  ]);
  RadGrad.user.setInterestTagIDs(ckID, [
    RadGrad.slug.getEntityID("artificial-intelligence", "Tag"),
    RadGrad.slug.getEntityID("algorithms", "Tag"),
    RadGrad.slug.getEntityID("silicon-valley", "Tag"),
    RadGrad.slug.getEntityID("machine-learning", "Tag")/*,
    RadGrad.slug.getEntityID("high-performance-computing", "Tag")*/
  ]);
  RadGrad.user.setPicture(ckID, "https://toronto.dressforsuccess.org/wp-content/uploads/sites/123/2015/01/carine2.jpg");

  RadGrad.user.setAboutMe(ckID, "I have a huge interest in AI, and one day hope to work as an engineer that creates intelligent robots to help solve everyday problems for handicapped people.");
  RadGrad.user.setSemesterID(ckID, RadGrad.semester.get("Spring", 2017));
}

