
defineStudentProfileNicholasHaynes = function() {
  let nhID = RadGrad.user.findBySlug("nicholashaynes")._id;

  let NicholasHaynesWorkInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2016), hrswk: 0, studentID: nhID},
    {semesterID: RadGrad.semester.get("Spring", 2016), hrswk: 0, studentID: nhID}
  ];

  let NicholasHaynesWorkInstanceIDs = _.map(NicholasHaynesWorkInstanceData, RadGrad.workinstance.define);

  let NicholasHaynesCourseInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth1xx", verified: false, grade: "A", studentID: nhID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth1xx", verified: false, grade: "B+", studentID: nhID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth1xx", verified: false, grade: "B", studentID: nhID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth1xx", verified: false, grade: "A", studentID: nhID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth1xx", verified: false, grade: "A", studentID: nhID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth1xx", verified: false, grade: "B", credithrs: 1, studentID: nhID},

    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics111", verified: false, studentID: nhID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics141", verified: false, studentID: nhID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, credithrs: 1, studentID: nhID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: false, studentID: nhID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: nhID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, credithrs: 1, studentID: nhID}
  ];

  let NicholasHaynesCourseInstanceIDs = _.map(NicholasHaynesCourseInstanceData, RadGrad.courseinstance.define);

  let NicholasHaynesOpportunityInstanceData = [];
  let NicholasHaynesOpportunityIDs = _.map(NicholasHaynesOpportunityInstanceData, RadGrad.opportunityinstance.define);

  let NicholasHaynesDegreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: NicholasHaynesCourseInstanceIDs,
    opportunityInstanceIDs: NicholasHaynesOpportunityIDs,
    workInstanceIDs: NicholasHaynesWorkInstanceIDs,
    studentID: nhID
  });

  RadGrad.user.setDegreePlanID(nhID, NicholasHaynesDegreePlan);
  RadGrad.user.setDegreeGoalIDs(nhID, [
    RadGrad.slug.getEntityID("game-designer", "DegreeGoal"),
    RadGrad.slug.getEntityID("animation-designer", "DegreeGoal"),
    RadGrad.slug.getEntityID("bs-cs", "DegreeGoal")
  ]);
  RadGrad.user.setInterestTagIDs(nhID, [
    RadGrad.slug.getEntityID("game-design", "Tag"),
    RadGrad.slug.getEntityID("physics", "Tag"),
    RadGrad.slug.getEntityID("computer-graphics", "Tag")]);

  RadGrad.user.setPicture(nhID, "https://media.licdn.com/mpr/mpr/shrinknp_200_200/p/4/005/035/2db/21b3a12.jpg");

  RadGrad.user.setAboutMe(nhID, "I am a freshman in my second semester majoring in ICS.  I really enjoy playing video games and aspire to one day become a game programmer.");
  RadGrad.user.setSemesterID(nhID, RadGrad.semester.get("Fall", 2018));
}