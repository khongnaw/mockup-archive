
defineStudentProfileJoyceBlue = function() {
  let jbID = RadGrad.user.findBySlug("joyceblue")._id;

  let JoyceBlueWorkInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2016), hrswk: 0, studentID: jbID},
    {semesterID: RadGrad.semester.get("Spring", 2016), hrswk: 0, studentID: jbID}
  ];

  let JoyceBlueWorkInstanceIDs = _.map(JoyceBlueWorkInstanceData, RadGrad.workinstance.define);

  let JoyceBlueCourseInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth1xx", verified: false, grade: "A", studentID: jbID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth2xx", verified: false, grade: "A", credithrs: 4, studentID: jbID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth1xx", verified: false, grade: "A", studentID: jbID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth1xx", verified: false, grade: "A+", studentID: jbID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth1xx", verified: false, grade: "A-", studentID: jbID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth1xx", verified: false, grade: "A", studentID: jbID},

    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee160", verified: false, credithrs: 4, studentID: jbID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: false, studentID: jbID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, credithrs: 4, studentID: jbID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: false, credithrs: 1, studentID: jbID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: jbID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: jbID}
  ];

  let JoyceBlueCourseInstanceIDs = _.map(JoyceBlueCourseInstanceData, RadGrad.courseinstance.define);

  let JoyceBlueOpportunityInstanceData = [];
  let JoyceBlueOpportunityIDs = _.map(JoyceBlueOpportunityInstanceData, RadGrad.opportunityinstance.define);

  let JoyceBlueDegreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: JoyceBlueCourseInstanceIDs,
    opportunityInstanceIDs: JoyceBlueOpportunityIDs,
    workInstanceIDs: JoyceBlueWorkInstanceIDs,
    studentID: jbID
  });

  RadGrad.user.setDegreePlanID(jbID, JoyceBlueDegreePlan);
  RadGrad.user.setDegreeGoalIDs(jbID, [
    RadGrad.slug.getEntityID("game-designer", "DegreeGoal"),
    RadGrad.slug.getEntityID("animation-designer", "DegreeGoal"),
    RadGrad.slug.getEntityID("bs-cs", "DegreeGoal")
  ]);
  RadGrad.user.setInterestTagIDs(jbID, [
    RadGrad.slug.getEntityID("game-design", "Tag"),
    RadGrad.slug.getEntityID("physics", "Tag"),
    RadGrad.slug.getEntityID("computer-graphics", "Tag")]);

  RadGrad.user.setPicture(jbID, "https://engineering.nd.edu/profiles/bjoyce/@@images/2187a90c-694c-41fb-a042-28b0daf0af42.jpeg");

  RadGrad.user.setAboutMe(jbID, "I am in my second semester of my freshman year of college.  I'm extremely interested in robotics and engineering.  I aspire to design drones after I graduate from college, with a BS in Computer Engineering.");
  RadGrad.user.setSemesterID(jbID, RadGrad.semester.get("Spring", 2019));
}
