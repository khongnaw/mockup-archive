defineStudentProfileDanielleThomas = function() {
  let dtID = RadGrad.user.findBySlug("daniellethomas")._id;

  let DanielleThomasWorkInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2014), hrswk: 15, studentID: dtID},
    {semesterID: RadGrad.semester.get("Spring", 2014), hrswk: 15, studentID: dtID},
    {semesterID: RadGrad.semester.get("Summer", 2014), hrswk: 40, studentID: dtID},
    {semesterID: RadGrad.semester.get("Fall", 2015), hrswk: 15, studentID: dtID},
    {semesterID: RadGrad.semester.get("Spring", 2015), hrswk: 15, studentID: dtID},
    {semesterID: RadGrad.semester.get("Summer", 2015), hrswk: 40, studentID: dtID},
    {semesterID: RadGrad.semester.get("Fall", 2015), hrswk: 15, studentID: dtID},
    {semesterID: RadGrad.semester.get("Spring", 2015), hrswk: 15, studentID: dtID}
  ];

  let DanielleThomasWorkInstanceIDs = _.map(DanielleThomasWorkInstanceData, RadGrad.workinstance.define);

  let DanielleThomasCourseInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: false, grade: "B", studentID: dtID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: false, grade: "B", studentID: dtID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: false, grade: "B-", studentID: dtID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: false, grade: "B-", studentID: dtID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: false, grade: "B", credithrs: 4, studentID: dtID},

    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth1xx", verified: false, grade: "B+", studentID: dtID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth1xx", verified: false, grade: "A", credithrs:1, studentID: dtID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth1xx", verified: false, grade: "B+", studentID: dtID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth1xx", verified: false, grade: "A", credithrs: 1, studentID: dtID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth2xx", verified: false, grade: "B-", credithrs: 4, studentID: dtID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth1xx", verified: false, grade: "B+", studentID: dtID},

    {semesterID: RadGrad.semester.get("Summer", 2015), course: "oth2xx", verified: false, grade: "A", studentID: dtID},

    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ics111", verified: false, grade: "B", studentID: dtID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ics141", verified: false, grade: "B-", studentID: dtID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth1xx", verified: false, grade: "B-", credithrs: 4, studentID: dtID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth1xx", verified: false, grade: "B", credithrs: 1, studentID: dtID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth1xx", verified: false, grade: "B-", credithrs: 2, studentID: dtID},

    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics211", verified: false, studentID: dtID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics241", verified: false, studentID: dtID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, credithrs: 1, studentID: dtID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: dtID}
  ];

  let DanielleThomasCourseInstanceIDs = _.map(DanielleThomasCourseInstanceData, RadGrad.courseinstance.define);

  let DanielleThomasOpportunityInstanceData = [];
  let DanielleThomasOpportunityIDs = _.map(DanielleThomasOpportunityInstanceData, RadGrad.opportunityinstance.define);

  let DanielleThomasDegreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: DanielleThomasCourseInstanceIDs,
    opportunityInstanceIDs: DanielleThomasOpportunityIDs,
    workInstanceIDs: DanielleThomasWorkInstanceIDs,
    studentID: dtID
  });

  RadGrad.user.setDegreePlanID(dtID, DanielleThomasDegreePlan);
  RadGrad.user.setDegreeGoalIDs(dtID, [
    RadGrad.slug.getEntityID("animation-designer", "DegreeGoal")
    //RadGrad.slug.getEntityID("ba-cs", "DegreeGoal"),
    /*RadGrad.slug.getEntityID("masters-degree", "DegreeGoal")*/
  ]);
  RadGrad.user.setInterestTagIDs(dtID, [
    RadGrad.slug.getEntityID("art", "Tag"),
    RadGrad.slug.getEntityID("computer-graphics", "Tag"),
    RadGrad.slug.getEntityID("silicon-valley", "Tag"),
  ]);
  RadGrad.user.setPicture(dtID, "http://skypencil.com/wp-content/uploads/2014/04/DanielleHulton.jpg");

  RadGrad.user.setAboutMe(dtID, "I reallly enjoy graphic design, and hope that learning computer science skills will allow me to expand my horizons as a graphic designer.");
  RadGrad.user.setSemesterID(dtID, RadGrad.semester.get("Spring", 2018));
}
