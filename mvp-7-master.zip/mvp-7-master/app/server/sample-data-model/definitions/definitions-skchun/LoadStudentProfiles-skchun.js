defineStudentProfilesSkchun = function () {
  defineStudentProfileAmakaYoon();
  defineStudentProfileEnriqueEloy();
  defineStudentProfileFlavioNataniel();
  defineStudentProfileKermitTitus();
  defineStudentProfileMingBai();
  defineStudentProfileMonicaLilly();
  defineStudentProfileRameshaMahendra();
  defineStudentProfileSamsonChun();
  defineStudentProfileStanTrueman();
};
