defineUsersSkchun = function() {
  let skchunUsers = [
    {
      firstName: "Samson",
      middleName: "",
      lastName: "Chun",
      slug: "samsonchun",
      password: "foo",
      uhEmail: "skchun@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Ramesha",
      middleName: "",
      lastName: "Mahendra",
      slug: "rameshamahendra",
      password: "foo",
      uhEmail: "ramesha@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Enrique",
      middleName: "",
      lastName: "Eloy",
      slug: "enriqueeloy",
      password: "foo",
      uhEmail: "enrique@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Flavio",
      middleName: "",
      lastName: "Nataniel",
      slug: "flavionataniel",
      password: "foo",
      uhEmail: "flavio@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Amaka",
      middleName: "",
      lastName: "Yoon",
      slug: "amakayoon",
      password: "foo",
      uhEmail: "amaka@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Ming",
      middleName: "",
      lastName: "Bai",
      slug: "mingbai",
      password: "foo",
      uhEmail: "ming@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Stan",
      middleName: "",
      lastName: "Trueman",
      slug: "stantrueman",
      password: "foo",
      uhEmail: "stantrueman@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Kermit",
      middleName: "",
      lastName: "Titus",
      slug: "kermittitus",
      password: "foo",
      uhEmail: "kermit@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Monica",
      middleName: "",
      lastName: "Lilly",
      slug: "monicalilly",
      password: "foo",
      uhEmail: "monica@hawaii.edu",
      role: RadGrad.role.student
    },

  ];

  _.each(skchunUsers, RadGrad.user.define);
}