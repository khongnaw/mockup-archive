defineStudentProfileEnriqueEloy = function() {
  let acID = RadGrad.user.findBySlug("enriqueeloy")._id;

  let enriqueEloyWorkInstanceData = [

  ];

  let enriqueEloyWorkInstanceIDs = _.map(enriqueEloyWorkInstanceData, RadGrad.workinstance.define);

  let enriqueEloyCourseInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: true, grade: "B", studentID: acID, note: ""},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: true, grade: "C", studentID: acID, note: ""},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: true, grade: "C", studentID: acID, note: ""},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics111", verified: true, grade: "B", studentID: acID, note: ""},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics141", verified: true, grade: "B", studentID: acID, note: ""},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth2xx", verified: true, grade: "B", studentID: acID, note: ""},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth2xx", verified: true, grade: "B", studentID: acID, note: ""},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ics211", verified: true, grade: "B", studentID: acID, note: ""},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ics212", verified: true, grade: "C", studentID: acID, note: ""},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ics241", verified: true, grade: "B", studentID: acID, note: ""},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth2xx", verified: true, grade: "C", studentID: acID, note: ""},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth2xx", verified: true, grade: "C", studentID: acID, note: ""},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ics311", verified: true, grade: "C", studentID: acID, note: ""},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ics314", verified: true, grade: "B", studentID: acID, note: ""},
  ];

  let enriqueEloyCourseInstanceIDs = _.map(enriqueEloyCourseInstanceData, RadGrad.courseinstance.define);

  let enriqueEloyOpportunityInstanceData = [
  ];

  let enriqueEloyOpportunityInstanceIDs = _.map(enriqueEloyOpportunityInstanceData, RadGrad.opportunityinstance.define);

  let enriqueEloyDegreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: enriqueEloyCourseInstanceIDs,
    opportunityInstanceIDs: enriqueEloyOpportunityInstanceIDs,
    workInstanceIDs: enriqueEloyWorkInstanceIDs,
    studentID: acID
  });

  RadGrad.user.setDegreePlanID(acID, enriqueEloyDegreePlan);
  RadGrad.user.setDegreeGoalIDs(acID, [RadGrad.slug.getEntityID("game-designer", "DegreeGoal")]);
  RadGrad.user.setInterestTagIDs(acID, [RadGrad.slug.getEntityID("game-design", "Tag"), RadGrad.slug.getEntityID("computer-graphics", "Tag")], RadGrad.slug.getEntityID("android", "Tag"), RadGrad.slug.getEntityID("ios", "Tag"), RadGrad.slug.getEntityID("cplusplus", "Tag"), RadGrad.slug.getEntityID("mobile-devices", "Tag"));
  RadGrad.user.setPicture(acID, "https://s-media-cache-ak0.pinimg.com/236x/64/e0/e2/64e0e28fe5ba589afbc1f83d1e8a6cff.jpg");
  RadGrad.user.setAboutMe(acID, "I am a sophomore in ICS and interested in developing mobile games.");
  RadGrad.user.setSemesterID(acID, RadGrad.semester.get("Spring", 2018));
};