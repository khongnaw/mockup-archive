defineStudentProfileSamsonChun = function() {
  let acID = RadGrad.user.findBySlug("samsonchun")._id;

  let samsonChunWorkInstanceData = [

  ];

  let samsonChunWorkInstanceIDs = _.map(samsonChunWorkInstanceData, RadGrad.workinstance.define);

  let samsonChunCourseInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: true, grade: "B", studentID: acID, note: ""},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth1xx", verified: true, grade: "A", studentID: acID, note: ""},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth1xx", verified: true, grade: "A", studentID: acID, note: ""},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth1xx", verified: true, grade: "A", studentID: acID, note: ""},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth1xx", verified: true, grade: "A", studentID: acID, note: ""},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ee160", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth1xx", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth1xx", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth1xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Summer", 2014), course: "oth1xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Summer", 2014), course: "oth1xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee211", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee260", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee296", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee213", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee205", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth2xx", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth2xx", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth2xx", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Summer", 2015), course: "oth2xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Summer", 2015), course: "oth2xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ee324", verified: true, grade: "C", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ee371", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ee361", verified: true, grade: "A", studentID: acID},
    //{semesterID: RadGrad.semester.get("Fall", 2016), course: "ee361l", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ee396", verified: true, grade: "A", studentID: acID},
    //{semesterID: RadGrad.semester.get("Fall", 2016), course: "ee362", verified: true, grade: "C", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee315", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee323", verified: false, studentID: acID},
    //{semesterID: RadGrad.semester.get("Spring", 2016), course: "ee323l", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee367", verified: false, studentID: acID},
    //{semesterID: RadGrad.semester.get("Spring", 2016), course: "ee367l", verified: false, studentID: acID},
    //{semesterID: RadGrad.semester.get("Spring", 2016), course: "ee406", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Summer", 2016), course: "oth3xx", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Summer", 2016), course: "oth3xx", verified: false, studentID: acID},
  ];

  let samsonChunCourseInstanceIDs = _.map(samsonChunCourseInstanceData, RadGrad.courseinstance.define);

  let samsonChunOpportunityInstanceData = [
    {semesterID: RadGrad.semester.get("Spring", 2016), opportunity: "business-plan-competition2016", verified: false, hrswk: 10, studentID: acID},
  ];

  let samsonChunOpportunityInstanceIDs = _.map(samsonChunOpportunityInstanceData, RadGrad.opportunityinstance.define);

  let samsonChunDegreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: samsonChunCourseInstanceIDs,
    opportunityInstanceIDs: samsonChunOpportunityInstanceIDs,
    workInstanceIDs: samsonChunWorkInstanceIDs,
    studentID: acID
  });

  RadGrad.user.setDegreePlanID(acID, samsonChunDegreePlan);
  RadGrad.user.setDegreeGoalIDs(acID, [RadGrad.slug.getEntityID("robotics-engineer", "DegreeGoal")]);
  RadGrad.user.setInterestTagIDs(acID, [RadGrad.slug.getEntityID("android", "Tag"), RadGrad.slug.getEntityID("arduino", "Tag"), RadGrad.slug.getEntityID("c", "Tag"), RadGrad.slug.getEntityID("cryptography", "Tag"), RadGrad.slug.getEntityID("wireless-networks", "Tag"), RadGrad.slug.getEntityID("artificial-intelligence", "Tag")]);
  RadGrad.user.setPicture(acID, "http://ia.media-imdb.com/images/M/MV5BMTc0MzY5NzY1Ml5BMl5BanBnXkFtZTcwOTcwMTgwOA@@._V1_UY317_CR17,0,214,317_AL_.jpg");
  RadGrad.user.setAboutMe(acID, "I am a senior in CEng and want to become a drone designer for either a defense contractor or Amazon.");
  RadGrad.user.setSemesterID(acID, RadGrad.semester.get("Spring", 2017));

};

