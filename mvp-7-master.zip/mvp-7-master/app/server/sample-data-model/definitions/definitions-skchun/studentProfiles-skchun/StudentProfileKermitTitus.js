defineStudentProfileKermitTitus = function() {
  let acID = RadGrad.user.findBySlug("kermittitus")._id;

  let kermitTitusWorkInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2013), hrswk: 20, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2013), hrswk: 20, studentID: acID},
    {semesterID: RadGrad.semester.get("Summer", 2013), hrswk: 40, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), hrswk: 20, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), hrswk: 20, studentID: acID},
    {semesterID: RadGrad.semester.get("Summer", 2014), hrswk: 40, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), hrswk: 20, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), hrswk: 20, studentID: acID},
    {semesterID: RadGrad.semester.get("Summer", 2015), hrswk: 40, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2016), hrswk: 20, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), hrswk: 20, studentID: acID},
  ];

  let kermitTitusWorkInstanceIDs = _.map(kermitTitusWorkInstanceData, RadGrad.workinstance.define);

  let kermitTitusCourseInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "B", studentID: acID, note: ""},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: true, grade: "B", studentID: acID, note: ""},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: true, grade: "B", studentID: acID, note: ""},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: true, grade: "B", studentID: acID, note: ""},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: true, grade: "B", studentID: acID, note: ""},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "ee160", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth1xx", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth1xx", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth1xx", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth2xx", verified: true, grade: "C", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee211", verified: true, grade: "C", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee260", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee296", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ee213", verified: true, grade: "C", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ee205", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Summer", 2014), course: "oth1xx", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee324", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee371", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee361", verified: true, grade: "B", studentID: acID},
    //{semesterID: RadGrad.semester.get("Fall", 2015), course: "ee361l", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee396", verified: true, grade: "A", studentID: acID},
    //{semesterID: RadGrad.semester.get("Fall", 2015), course: "ee362", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee315", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee323", verified: true, grade: "C", studentID: acID},
    //{semesterID: RadGrad.semester.get("Spring", 2015), course: "ee323l", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee367", verified: true, grade: "B", studentID: acID},
    //{semesterID: RadGrad.semester.get("Spring", 2015), course: "ee367l", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee342", verified: true, grade: "C", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ee468", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth2xx", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth3xx", verified: true, grade: "C", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth2xx", verified: true, grade: "B", studentID: acID},
    //{semesterID: RadGrad.semester.get("Fall", 2016), course: "ee344", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee496", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee495", verified: false, studentID: acID},
    //{semesterID: RadGrad.semester.get("Spring", 2016), course: "ee449", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth3xx", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: false, studentID: acID},

  ];

  let kermitTitusCourseInstanceIDs = _.map(kermitTitusCourseInstanceData, RadGrad.courseinstance.define);

  let kermitTitusOpportunityInstanceData = [

    {semesterID: RadGrad.semester.get("Summer", 2015), opportunity: "liveaction-internship", verified: true, hrswk: 40, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2016), opportunity: "atthack16", verified: true, hrswk: 10, studentID: acID},
    ];

  let kermitTitusOpportunityInstanceIDs = _.map(kermitTitusOpportunityInstanceData, RadGrad.opportunityinstance.define);

  let kermitTitusDegreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: kermitTitusCourseInstanceIDs,
    opportunityInstanceIDs: kermitTitusOpportunityInstanceIDs,
    workInstanceIDs: kermitTitusWorkInstanceIDs,
    studentID: acID
  });

  RadGrad.user.setDegreePlanID(acID, kermitTitusDegreePlan);
  RadGrad.user.setDegreeGoalIDs(acID, [RadGrad.slug.getEntityID("network-engineer", "DegreeGoal")]);
  RadGrad.user.setInterestTagIDs(acID, [RadGrad.slug.getEntityID("wireless-networks", "Tag"), RadGrad.slug.getEntityID("network-security", "Tag")], RadGrad.slug.getEntityID("cryptography", "Tag"), RadGrad.slug.getEntityID("network-design", "Tag"), RadGrad.slug.getEntityID("computer-engineering", "Tag"));
  RadGrad.user.setPicture(acID, "http://ia.media-imdb.com/images/M/MV5BMjE2NDQ0OTM2NF5BMl5BanBnXkFtZTgwMTM3NDA0NzE@._V1_UY317_CR22,0,214,317_AL_.jpg");
  RadGrad.user.setAboutMe(acID, "I am a senior in CEng interested in optimization of networks.  ");
  RadGrad.user.setSemesterID(acID, RadGrad.semester.get("Spring", 2016));

};

