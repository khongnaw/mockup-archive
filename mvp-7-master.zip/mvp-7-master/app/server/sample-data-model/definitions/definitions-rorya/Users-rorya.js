defineUsersRorya = function () {
  let Users = [
    {
      firstName: "Jonty",
      middleName: "",
      lastName: "Milburn",
      slug: "jontymilburn",
      password: "foo",
      uhEmail: "jontym@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Roy",
      middleName: "",
      lastName: "Anderson",
      slug: "royanderson",
      password: "foo",
      uhEmail: "randerson@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Flanagan",
      middleName: "Randell",
      lastName: "Danell",
      slug: "flanagandanell",
      password: "foo",
      uhEmail: "flandan@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Mirica",
      middleName: "Jordana",
      lastName: "Fitzroy",
      slug: "miricafitzroy",
      password: "foo",
      uhEmail: "mfitzroy@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Anastacia",
      middleName: "Janessa",
      lastName: "Morrison",
      slug: "anastaciamorrison",
      password: "foo",
      uhEmail: "amorrison@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Norman",
      middleName: "Carlton",
      lastName: "Taylor",
      slug: "normantaylor",
      password: "foo",
      uhEmail: "ntaylor@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Mark",
      middleName: "",
      lastName: "Yukimura",
      slug: "markyukimura",
      password: "foo",
      uhEmail: "myukimura@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Tina",
      middleName: "",
      lastName: "Wong",
      slug: "tinawong",
      password: "foo",
      uhEmail: "tinawong@hawaii.edu",
      role: RadGrad.role.student
    }

  ];

  _.each(Users, RadGrad.user.define);
};