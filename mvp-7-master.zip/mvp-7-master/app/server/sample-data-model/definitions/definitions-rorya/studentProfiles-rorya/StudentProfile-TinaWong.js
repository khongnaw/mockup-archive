/**
 * Created by Rory on 1/27/2016.
 */
defineStudentProfileTinaWong = function() {
  let acID = RadGrad.user.findBySlug("tinawong")._id;

  let sampleWorkInstanceData = [];

  let sampleWorkInstanceIDs = _.map(sampleWorkInstanceData, RadGrad.workinstance.define);

  let sampleCourseInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics111", verified: false, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics141", verified: false, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: false, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: false, grade: "B", studentID: acID, credithrs: 1},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: false, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: false, grade: "A", studentID: acID},

    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics211", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics241", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: acID, credithrs: 1},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: false, studentID: acID},

    {semesterID: RadGrad.semester.get("Summer", 2016), course: "oth1xx", verified: false, studentID: acID},

    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ics212", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ics311", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth2xx", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth2xx", verified: false, studentID: acID, credithrs: 1},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth2xx", verified: false, studentID: acID},

    {semesterID: RadGrad.semester.get("Spring", 2017), course: "ics312", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2017), course: "ics361", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2017), course: "ics321", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2017), course: "oth2xx", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2017), course: "oth3xx", verified: false, studentID: acID},

    {semesterID: RadGrad.semester.get("Summer", 2017), course: "oth3xx", verified: false, studentID: acID},

    {semesterID: RadGrad.semester.get("Fall", 2017), course: "ics332", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2017), course: "ics475", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2017), course: "oth3xx", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2017), course: "oth3xx", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2017), course: "oth2xx", verified: false, studentID: acID},

    {semesterID: RadGrad.semester.get("Fall", 2017), course: "ics476", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2017), course: "ics499", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2017), course: "oth3xx", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2017), course: "oth2xx", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2017), course: "oth3xx", verified: false, studentID: acID}
  ];

  let sampleCourseInstanceIDs = _.map(sampleCourseInstanceData, RadGrad.courseinstance.define);

  let sampleOpportunityInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2017), opportunity: "bil-lab", verified: false, hrswk: 20, studentID: acID}
  ];

  let sampleOpportunityInstanceIDs = _.map(sampleOpportunityInstanceData, RadGrad.opportunityinstance.define);

  let sampleDegreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: sampleCourseInstanceIDs,
    opportunityInstanceIDs: sampleOpportunityInstanceIDs,
    workInstanceIDs: sampleWorkInstanceIDs,
    studentID: acID
  });

  RadGrad.user.setDegreePlanID(acID, sampleDegreePlan);
  RadGrad.user.setDegreeGoalIDs(acID,
    [
      RadGrad.slug.getEntityID("bioinformatics-developer", "DegreeGoal"),
      RadGrad.slug.getEntityID("ba-ics", "DegreeGoal")
    ]);
  RadGrad.user.setInterestTagIDs(acID,
    [
      RadGrad.slug.getEntityID("biology", "Tag"),
      RadGrad.slug.getEntityID("algorithms", "Tag"),
      RadGrad.slug.getEntityID("data-science", "Tag"),
      RadGrad.slug.getEntityID("silicon-valley", "Tag"),
      RadGrad.slug.getEntityID("machine-learning", "Tag"),
      RadGrad.slug.getEntityID("linux", "Tag"),
      RadGrad.slug.getEntityID("bioinformatics", "Tag"),
      RadGrad.slug.getEntityID("data-visualization", "Tag")
    ]);
  RadGrad.user.setPicture(acID, "http://i.imgur.com/m2uCvBu.jpg");
  RadGrad.user.setAboutMe(acID, "I've always been interested in biology and computers so once I learned about bioinformatics I knew what I wanted to do for a living. There is a lot to discover and I want to be a part of that.");
  RadGrad.user.setSemesterID(acID, RadGrad.semester.get("Fall", 2018));
};

