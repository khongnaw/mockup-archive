/**
 * Created by Rory on 1/27/2016.
 */
defineStudentProfileMiricaFitzroy = function() {
  let acID = RadGrad.user.findBySlug("miricafitzroy")._id;

  let sampleWorkInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2014), hrswk: 15, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), hrswk: 20, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), hrswk: 15, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), hrswk: 20, studentID: acID}
  ];

  let sampleWorkInstanceIDs = _.map(sampleWorkInstanceData, RadGrad.workinstance.define);

  let sampleCourseInstanceData = [
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "ics111", verified: false, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "ics141", verified: false, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth1xx", verified: false, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth1xx", verified: false, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth1xx", verified: false, grade: "A", studentID: acID, credithrs: 1},

    {semesterID: RadGrad.semester.get("Fall", 2013), course: "ics211", verified: false, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "ics241", verified: false, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: false, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: false, grade: "A", studentID: acID, credithrs: 1},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: false, grade: "C", studentID: acID},

    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ics311", verified: false, grade: "C", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ics314", verified: false, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ics351", verified: false, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: false, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth1xx", verified: false, grade: "A", studentID: acID},

    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ics313", verified: false, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ics312", verified: false, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ics355", verified: false, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth1xx", verified: false, grade: "C", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth1xx", verified: false, grade: "A", studentID: acID, credithrs: 1},

    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ics321", verified: false, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ics332", verified: false, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ics423", verified: false, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth1xx", verified: false, grade: "C", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth1xx", verified: false, grade: "B", studentID: acID, credithrs: 1},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth1xx", verified: false, grade: "C", studentID: acID},

    {semesterID: RadGrad.semester.get("Summer", 2015), course: "oth1xx", verified: false, grade: "A", studentID: acID},

    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics442", verified: false, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics314", verified: false, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics421", verified: false, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: false, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: false, grade: "B", studentID: acID},

    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics471", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics414", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics484", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: acID}
  ];

  let sampleCourseInstanceIDs = _.map(sampleCourseInstanceData, RadGrad.courseinstance.define);

  let sampleOpportunityInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2015), opportunity: "acm-manoa", verified: true, hrswk: 10, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), opportunity: "acm-manoa", verified: true, hrswk: 15, studentID: acID}
  ];

  let sampleOpportunityInstanceIDs = _.map(sampleOpportunityInstanceData, RadGrad.opportunityinstance.define);

  let sampleDegreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: sampleCourseInstanceIDs,
    opportunityInstanceIDs: sampleOpportunityInstanceIDs,
    workInstanceIDs: sampleWorkInstanceIDs,
    studentID: acID
  });

  RadGrad.user.setDegreePlanID(acID, sampleDegreePlan);
  RadGrad.user.setDegreeGoalIDs(acID,
    [
      RadGrad.slug.getEntityID("business-intelligence-analyst", "DegreeGoal"),
      RadGrad.slug.getEntityID("data-scientist", "DegreeGoal"),
      RadGrad.slug.getEntityID("bs-cs", "DegreeGoal")
    ]);
  RadGrad.user.setInterestTagIDs(acID,
    [
      RadGrad.slug.getEntityID("database", "Tag"),
      RadGrad.slug.getEntityID("business", "Tag"),
      RadGrad.slug.getEntityID("west-us", "Tag"),
      RadGrad.slug.getEntityID("hawaii", "Tag"),
      RadGrad.slug.getEntityID("analytical-modeling", "Tag"),
      RadGrad.slug.getEntityID("algorithms", "Tag"),
      RadGrad.slug.getEntityID("elasticsearch", "Tag"),
      RadGrad.slug.getEntityID("data-science", "Tag"),
      RadGrad.slug.getEntityID("data-visualization", "Tag")
    ]);
  RadGrad.user.setPicture(acID, "https://pixabay.com/static/uploads/photo/2015/07/02/10/45/woman-828953_960_720.jpg");
  RadGrad.user.setAboutMe(acID, "I am a senior graduating this semester who is looking to get into the technical side of business.");
  RadGrad.user.setSemesterID(acID, RadGrad.semester.get("Spring", 2016));
};

