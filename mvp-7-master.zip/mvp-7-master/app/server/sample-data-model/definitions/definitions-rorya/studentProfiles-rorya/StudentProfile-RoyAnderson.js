/**
 * Created by Rory on 1/27/2016.
 */
defineStudentProfileRoyAnderson = function() {
  let acID = RadGrad.user.findBySlug("royanderson")._id;

  let sampleWorkInstanceData = [{semesterID: RadGrad.semester.get("Spring", 2015), hrswk: 30, studentID: acID}];

  let sampleWorkInstanceIDs = _.map(sampleWorkInstanceData, RadGrad.workinstance.define);

  let sampleCourseInstanceData = [
    {semesterID: RadGrad.semester.get("Spring", 2010), course: "ics111", verified: false, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2010), course: "oth1xx", verified: false, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2010), course: "oth1xx", verified: false, grade: "B", studentID: acID, credithrs: 1},
    {semesterID: RadGrad.semester.get("Spring", 2010), course: "oth1xx", verified: false, grade: "C", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2010), course: "oth3xx", verified: false, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2010), course: "oth3xx", verified: false, grade: "B", studentID: acID},

    {semesterID: RadGrad.semester.get("Fall", 2011), course: "ics211", verified: false, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2011), course: "oth3xx", verified: false, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2011), course: "oth3xx", verified: false, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2011), course: "oth4xx", verified: false, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2011), course: "oth1xx", verified: false, grade: "A", studentID: acID},

    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ics141", verified: false, grade: "A", studentID: acID},

    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ics212", verified: false, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ics241", verified: false, grade: "A", studentID: acID},

    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics311", verified: false, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics314", verified: false, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: false, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: false, grade: "A", studentID: acID, credithrs: 4},

    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics414", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics332", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: acID, credithrs: 1},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: false, studentID: acID, credithrs: 4},

    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ics312", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ics361", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ics321", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth1xx", verified: false, studentID: acID, credithrs: 1},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth1xx", verified: false, studentID: acID}
  ];

  let sampleCourseInstanceIDs = _.map(sampleCourseInstanceData, RadGrad.courseinstance.define);

  let sampleOpportunityInstanceData = [];

  let sampleOpportunityInstanceIDs = _.map(sampleOpportunityInstanceData, RadGrad.opportunityinstance.define);

  let sampleDegreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: sampleCourseInstanceIDs,
    opportunityInstanceIDs: sampleOpportunityInstanceIDs,
    workInstanceIDs: sampleWorkInstanceIDs,
    studentID: acID
  });

  RadGrad.user.setDegreePlanID(acID, sampleDegreePlan);
  RadGrad.user.setDegreeGoalIDs(acID,
    [
      RadGrad.slug.getEntityID("web-developer", "DegreeGoal"),
      RadGrad.slug.getEntityID("game-designer", "DegreeGoal"),
      RadGrad.slug.getEntityID("bs-cs", "DegreeGoal")
    ]);
  RadGrad.user.setInterestTagIDs(acID,
    [
      RadGrad.slug.getEntityID("web-design", "Tag"),
      RadGrad.slug.getEntityID("javascript", "Tag"),
      RadGrad.slug.getEntityID("css", "Tag"),
      RadGrad.slug.getEntityID("algorithms", "Tag"),
      RadGrad.slug.getEntityID("system-programming", "Tag"),
      RadGrad.slug.getEntityID("bootstrap", "Tag"),
      RadGrad.slug.getEntityID("artificial-intelligence", "Tag"),
      RadGrad.slug.getEntityID("west-us", "Tag"),
      RadGrad.slug.getEntityID("windows", "Tag"),
      RadGrad.slug.getEntityID("unity", "Tag"),
      RadGrad.slug.getEntityID("machine-learning", "Tag"),
      RadGrad.slug.getEntityID("game-design", "Tag"),
      RadGrad.slug.getEntityID("software-engineering", "Tag"),
      RadGrad.slug.getEntityID("astronomy", "Tag"),
      RadGrad.slug.getEntityID("linux", "Tag"),
      RadGrad.slug.getEntityID("english", "Tag"),
      RadGrad.slug.getEntityID("c", "Tag"),
      RadGrad.slug.getEntityID("cplusplus", "Tag"),
      RadGrad.slug.getEntityID("git", "Tag")
    ]);
  RadGrad.user.setPicture(acID, "https://pixabay.com/static/uploads/photo/2015/03/30/19/36/person-700019_960_720.jpg");
  RadGrad.user.setAboutMe(acID, "I am a returning student who is interested in learning web development and game design and general software development.");
  RadGrad.user.setSemesterID(acID, RadGrad.semester.get("Fall", 2017));
};

