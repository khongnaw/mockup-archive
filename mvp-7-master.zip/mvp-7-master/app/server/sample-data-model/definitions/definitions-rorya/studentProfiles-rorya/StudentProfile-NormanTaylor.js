/**
 * Created by Rory on 1/27/2016.
 */
defineStudentProfileNormanTaylor = function() {
  let acID = RadGrad.user.findBySlug("normantaylor")._id;

  let sampleWorkInstanceData = [];

  let sampleWorkInstanceIDs = _.map(sampleWorkInstanceData, RadGrad.workinstance.define);

  let sampleCourseInstanceData = [
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ics111", verified: false, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ics141", verified: false, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth1xx", verified: false, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: false, grade: "B", studentID: acID, credithrs: 4},

    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ics211", verified: false, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ics241", verified: false, grade: "C", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth1xx", verified: false, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: false, grade: "B", studentID: acID, credithrs:4},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth1xx", verified: false, grade: "A", studentID: acID, credithrs: 1},

    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ics311", verified: false, grade: "C", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ics315", verified: false, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth2xx", verified: false, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth1xx", verified: false, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth1xx", verified: false, grade: "B", studentID: acID, credithrs: 1},

    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics314", verified: false, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics312", verified: false, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth3xx", verified: false, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: false, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: false, grade: "B", studentID: acID},

    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics313", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics332", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics321", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: acID, credithrs: 1}
  ];

  let sampleCourseInstanceIDs = _.map(sampleCourseInstanceData, RadGrad.courseinstance.define);

  let sampleOpportunityInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2015), opportunity: "hicapacity", verified: true, hrswk: 10, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), opportunity: "atthack16", verified: true, studentID: acID}
  ];

  let sampleOpportunityInstanceIDs = _.map(sampleOpportunityInstanceData, RadGrad.opportunityinstance.define);

  let sampleDegreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: sampleCourseInstanceIDs,
    opportunityInstanceIDs: sampleOpportunityInstanceIDs,
    workInstanceIDs: sampleWorkInstanceIDs,
    studentID: acID
  });

  RadGrad.user.setDegreePlanID(acID, sampleDegreePlan);
  RadGrad.user.setDegreeGoalIDs(acID,
    [
      RadGrad.slug.getEntityID("web-developer", "DegreeGoal"),
      RadGrad.slug.getEntityID("ba-ics", "DegreeGoal")
    ]);
  RadGrad.user.setInterestTagIDs(acID,
    [
      RadGrad.slug.getEntityID("web-design", "Tag"),
      RadGrad.slug.getEntityID("bootstrap", "Tag"),
      RadGrad.slug.getEntityID("css", "Tag"),
      RadGrad.slug.getEntityID("hawaii", "Tag"),
      RadGrad.slug.getEntityID("art", "Tag"),
      RadGrad.slug.getEntityID("php", "Tag"),
      RadGrad.slug.getEntityID("mobile-devices", "Tag"),
      RadGrad.slug.getEntityID("ios", "Tag")
    ]);
  RadGrad.user.setPicture(acID, "https://pixabay.com/static/uploads/photo/2015/05/19/15/21/human-773712_960_720.jpg");
  RadGrad.user.setAboutMe(acID, "I'm a sophmore who is interested in both web design and mobile apps.");
  RadGrad.user.setSemesterID(acID, RadGrad.semester.get("Spring", 2017));
};

