defineStudentProfileKiraPower = function() {
  let kpID = RadGrad.user.findBySlug("kirapower")._id;

  let sampleWorkInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2013), hrswk: 10, studentID: kpID},
    {semesterID: RadGrad.semester.get("Spring", 2014), hrswk: 10, studentID: kpID},
    {semesterID: RadGrad.semester.get("Fall", 2014), hrswk: 10, studentID: kpID},
    {semesterID: RadGrad.semester.get("Spring", 2015), hrswk: 10, studentID: kpID}
  ];

  let sampleWorkInstanceIDs = _.map(sampleWorkInstanceData, RadGrad.workinstance.define);

  let sampleCourseInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2012), course: "ics111", verified: true, grade: "A", studentID: kpID},
    {semesterID: RadGrad.semester.get("Fall", 2012), course: "oth2xx", verified: true, grade: "A", studentID: kpID},
    {semesterID: RadGrad.semester.get("Fall", 2012), course: "ics141", verified: true, grade: "A", studentID: kpID},
    {semesterID: RadGrad.semester.get("Fall", 2012), course: "oth1xx", verified: true, grade: "A", studentID: kpID},

    {semesterID: RadGrad.semester.get("Spring", 2013), course: "ics211", verified: true, grade: "A", studentID: kpID},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth2xx", verified: true, grade: "A", studentID: kpID},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "ics241", verified: true, grade: "A", studentID: kpID},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth2xx", verified: true, grade: "A", studentID: kpID},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth2xx", verified: true, grade: "A", studentID: kpID},

    {semesterID: RadGrad.semester.get("Fall", 2013), course: "ics212", verified: true, grade: "A", studentID: kpID},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "ics311", verified: true, grade: "A", studentID: kpID},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: true, grade: "A", studentID: kpID},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: true, grade: "A", studentID: kpID},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "A", studentID: kpID},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth1xx", verified: true, grade: "A", studentID: kpID},

    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ics312", verified: true, grade: "A", studentID: kpID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ics321", verified: true, grade: "A", studentID: kpID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth1xx", verified: true, grade: "A", studentID: kpID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth1xx", verified: true, grade: "A", studentID: kpID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: true, grade: "A", studentID: kpID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth1xx", verified: true, grade: "A", studentID: kpID},

    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ics361", verified: true, grade: "A", studentID: kpID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ics314", verified: true, grade: "A", studentID: kpID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth1xx", verified: true, grade: "A", studentID: kpID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: true, grade: "A", studentID: kpID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth3xx", verified: true, grade: "A", studentID: kpID},

    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ics332", verified: true, grade: "A", studentID: kpID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ics419", verified: true, grade: "A", studentID: kpID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth1xx", verified: true, grade: "A", studentID: kpID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth1xx", verified: true, grade: "A", studentID: kpID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth2xx", verified: true, grade: "A", studentID: kpID},

    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics461", verified: false, studentID: kpID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics464", verified: false, studentID: kpID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: false, studentID: kpID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: false, studentID: kpID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth3xx", verified: false, studentID: kpID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth3xx", verified: false, studentID: kpID},

    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics469", verified: false, studentID: kpID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics414", verified: false, studentID: kpID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: false, studentID: kpID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: false, studentID: kpID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth3xx", verified: false, studentID: kpID}
  ];

  let sampleCourseInstanceIDs = _.map(sampleCourseInstanceData, RadGrad.courseinstance.define);

  let sampleOpportunityInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2012), opportunity: "acm-manoa", verified: true, hrswk: 10, studentID: kpID},
    {semesterID: RadGrad.semester.get("Spring", 2013), opportunity: "acm-manoa", verified: true, hrswk: 10, studentID: kpID},
    {semesterID: RadGrad.semester.get("Fall", 2013), opportunity: "acm-manoa", verified: true, hrswk: 10, studentID: kpID},
    {semesterID: RadGrad.semester.get("Spring", 2014), opportunity: "acm-manoa", verified: true, hrswk: 10, studentID: kpID},
    {semesterID: RadGrad.semester.get("Fall", 2014), opportunity: "acm-manoa", verified: true, hrswk: 10, studentID: kpID},
    {semesterID: RadGrad.semester.get("Fall", 2014), opportunity: "hichi", verified: true, hrswk: 10, studentID: kpID},
    {semesterID: RadGrad.semester.get("Spring", 2015), opportunity: "acm-manoa", verified: true, hrswk: 10, studentID: kpID},
    {semesterID: RadGrad.semester.get("Spring", 2015), opportunity: "hichi", verified: true, hrswk: 10, studentID: kpID}
  ];

  let sampleOpportunityInstanceIDs = _.map(sampleOpportunityInstanceData, RadGrad.opportunityinstance.define);

  let sampleDegreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: sampleCourseInstanceIDs,
    opportunityInstanceIDs: sampleOpportunityInstanceIDs,
    workInstanceIDs: sampleWorkInstanceIDs,
    studentID: kpID
  });

  RadGrad.user.setDegreePlanID(kpID, sampleDegreePlan);
  RadGrad.user.setDegreeGoalIDs(kpID, [RadGrad.slug.getEntityID("user-experience-designer", "DegreeGoal")]);

  RadGrad.user.setInterestTagIDs(kpID,
      [RadGrad.slug.getEntityID("artificial-intelligence", "Tag"),
        RadGrad.slug.getEntityID("cognitive-science", "Tag"),
        RadGrad.slug.getEntityID("human-computer-interaction", "Tag")
      ]);

  RadGrad.user.setPicture(kpID, "http://ia.media-imdb.com/images/M/MV5BMTYzNTc2ODgxM15BMl5BanBnXkFtZTgwMDIyNzQwNDE@._V1_UY317_CR20,0,214,317_AL_.jpg");
  RadGrad.user.setAboutMe(kpID, "I am a senior in ICS and interested in helping websites be more user friendly.  I wish to pursue a career in user experience design.");
  RadGrad.user.setSemesterID(kpID, RadGrad.semester.get("Spring", 2016));
};

