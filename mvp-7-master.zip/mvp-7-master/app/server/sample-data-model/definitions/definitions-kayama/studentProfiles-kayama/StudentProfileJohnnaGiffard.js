defineStudentProfileJohnnaGiffard = function() {
  let jgID = RadGrad.user.findBySlug("johnnagiffard")._id;

  let sampleWorkInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2015), hrswk: 10, studentID: jgID}];

  let sampleWorkInstanceIDs = _.map(sampleWorkInstanceData, RadGrad.workinstance.define);

  let sampleCourseInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: true, grade: "A", studentID: jgID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: true, grade: "A", studentID: jgID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: true, grade: "A", studentID: jgID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: true, grade: "A", studentID: jgID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: true, grade: "A", studentID: jgID},

    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee160", verified: false, studentID: jgID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: false, studentID: jgID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: jgID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: jgID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: jgID},

    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ee211", verified: false, studentID: jgID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ee260", verified: false, studentID: jgID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth2xx", verified: false, studentID: jgID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth2xx", verified: false, studentID: jgID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth2xx", verified: false, studentID: jgID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ee296", verified: false, studentID: jgID},

    {semesterID: RadGrad.semester.get("Spring", 2017), course: "ee213", verified: false, studentID: jgID},
    {semesterID: RadGrad.semester.get("Spring", 2017), course: "ee205", verified: false, studentID: jgID},
    {semesterID: RadGrad.semester.get("Spring", 2017), course: "oth2xx", verified: false, studentID: jgID},
    {semesterID: RadGrad.semester.get("Spring", 2017), course: "oth2xx", verified: false, studentID: jgID},
    {semesterID: RadGrad.semester.get("Spring", 2017), course: "oth1xx", verified: false, studentID: jgID},

    {semesterID: RadGrad.semester.get("Fall", 2017), course: "ee324", verified: false, studentID: jgID},
    {semesterID: RadGrad.semester.get("Fall", 2017), course: "ee371", verified: false, studentID: jgID},
    {semesterID: RadGrad.semester.get("Fall", 2017), course: "ee361", verified: false, studentID: jgID},
    {semesterID: RadGrad.semester.get("Fall", 2017), course: "ee361l", verified: false, studentID: jgID},
    {semesterID: RadGrad.semester.get("Fall", 2017), course: "ee396", verified: false, studentID: jgID},
    {semesterID: RadGrad.semester.get("Fall", 2017), course: "ics141", verified: false, studentID: jgID},

    {semesterID: RadGrad.semester.get("Spring", 2018), course: "ee315", verified: false, studentID: jgID},
    {semesterID: RadGrad.semester.get("Spring", 2018), course: "ee323", verified: false, studentID: jgID},
    {semesterID: RadGrad.semester.get("Spring", 2018), course: "ee323l", verified: false, studentID: jgID},
    {semesterID: RadGrad.semester.get("Spring", 2018), course: "ee367", verified: false, studentID: jgID},
    {semesterID: RadGrad.semester.get("Spring", 2018), course: "ee367l", verified: false, studentID: jgID},
    {semesterID: RadGrad.semester.get("Spring", 2018), course: "ee344", verified: false, studentID: jgID},

    {semesterID: RadGrad.semester.get("Fall", 2018), course: "ee342", verified: false, studentID: jgID},
    {semesterID: RadGrad.semester.get("Fall", 2018), course: "oth3xx", verified: false, studentID: jgID},
    {semesterID: RadGrad.semester.get("Fall", 2018), course: "ee468", verified: false, studentID: jgID},
    {semesterID: RadGrad.semester.get("Fall", 2018), course: "oth1xx", verified: false, studentID: jgID},
    {semesterID: RadGrad.semester.get("Fall", 2018), course: "oth2xx", verified: false, studentID: jgID},

    {semesterID: RadGrad.semester.get("Spring", 2019), course: "ee496", verified: false, studentID: jgID},
    {semesterID: RadGrad.semester.get("Spring", 2019), course: "ee495", verified: false, studentID: jgID},
    {semesterID: RadGrad.semester.get("Spring", 2019), course: "ee469", verified: false, studentID: jgID},
    {semesterID: RadGrad.semester.get("Spring", 2019), course: "oth2xx", verified: false, studentID: jgID},
    {semesterID: RadGrad.semester.get("Spring", 2019), course: "oth2xx", verified: false, studentID: jgID},
    {semesterID: RadGrad.semester.get("Spring", 2019), course: "oth2xx", verified: false, studentID: jgID}
  ];
  
  let sampleCourseInstanceIDs = _.map(sampleCourseInstanceData, RadGrad.courseinstance.define);

  let sampleOpportunityInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2015), opportunity: "acm-manoa", verified: true, hrswk: 10, studentID: jgID}];

  let sampleOpportunityInstanceIDs = _.map(sampleOpportunityInstanceData, RadGrad.opportunityinstance.define);

  let sampleDegreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: sampleCourseInstanceIDs,
    opportunityInstanceIDs: sampleOpportunityInstanceIDs,
    workInstanceIDs: sampleWorkInstanceIDs,
    studentID: jgID
  });

  RadGrad.user.setDegreePlanID(jgID, sampleDegreePlan);
  RadGrad.user.setDegreeGoalIDs(jgID, [RadGrad.slug.getEntityID("robotics-engineer", "DegreeGoal")]);

  RadGrad.user.setInterestTagIDs(jgID,
      [RadGrad.slug.getEntityID("robotics", "Tag"),
        RadGrad.slug.getEntityID("computer-engineering", "Tag"),
        RadGrad.slug.getEntityID("circuit-design", "Tag"),
        RadGrad.slug.getEntityID("wireless-networks", "Tag")]);

  RadGrad.user.setPicture(jgID, "http://faceresearch.org/uploads/base/white_female");
  RadGrad.user.setAboutMe(jgID, "I am a freshman in CE and interested in creating my own drone.  I have been playing around with electronics since I was a kid and have entered many science competitions.  I wish to pursue a career in designing drones.");
  RadGrad.user.setSemesterID(jgID, RadGrad.semester.get("Spring", 2019));
};

