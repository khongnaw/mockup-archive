defineStudentProfileKerrCoburn = function() {
  let kcID = RadGrad.user.findBySlug("kerrcoburn")._id;

  let sampleWorkInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2015), hrswk: 10, studentID: kcID}];

  let sampleWorkInstanceIDs = _.map(sampleWorkInstanceData, RadGrad.workinstance.define);

  let sampleCourseInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ics111", verified: true, grade: "A", studentID: kcID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: true, grade: "A", studentID: kcID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ics141", verified: true, grade: "B+", studentID: kcID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth1xx", verified: true, grade: "A", studentID: kcID},

    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ics211", verified: true, grade: "A", studentID: kcID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth2xx", verified: true, grade: "A", studentID: kcID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ics241", verified: true, grade: "B", studentID: kcID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth2xx", verified: true, grade: "A", studentID: kcID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth2xx", verified: true, grade: "A", studentID: kcID},

    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics212", verified: false, studentID: kcID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics311", verified: false, studentID: kcID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: false, studentID: kcID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: false, studentID: kcID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: false, studentID: kcID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: false, studentID: kcID},

    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics312", verified: false, studentID: kcID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics321", verified: false, studentID: kcID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: kcID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: kcID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: kcID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: false, studentID: kcID},

    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ics313", verified: false, studentID: kcID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ics314", verified: false, studentID: kcID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth1xx", verified: false, studentID: kcID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth2xx", verified: false, studentID: kcID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth3xx", verified: false, studentID: kcID},

    {semesterID: RadGrad.semester.get("Spring", 2017), course: "ics332", verified: false, studentID: kcID},
    {semesterID: RadGrad.semester.get("Spring", 2017), course: "ics414", verified: false, studentID: kcID},
    {semesterID: RadGrad.semester.get("Spring", 2017), course: "oth1xx", verified: false, studentID: kcID},
    {semesterID: RadGrad.semester.get("Spring", 2017), course: "oth1xx", verified: false, studentID: kcID},
    {semesterID: RadGrad.semester.get("Spring", 2017), course: "oth2xx", verified: false, studentID: kcID},

    {semesterID: RadGrad.semester.get("Fall", 2017), course: "ics415", verified: false, studentID: kcID},
    {semesterID: RadGrad.semester.get("Fall", 2017), course: "ics481", verified: false, studentID: kcID},
    {semesterID: RadGrad.semester.get("Fall", 2017), course: "oth1xx", verified: false, studentID: kcID},
    {semesterID: RadGrad.semester.get("Fall", 2017), course: "oth1xx", verified: false, studentID: kcID},
    {semesterID: RadGrad.semester.get("Fall", 2017), course: "oth3xx", verified: false, studentID: kcID},
    {semesterID: RadGrad.semester.get("Fall", 2017), course: "oth3xx", verified: false, studentID: kcID},

    {semesterID: RadGrad.semester.get("Spring", 2018), course: "ics466", verified: false, studentID: kcID},
    {semesterID: RadGrad.semester.get("Spring", 2018), course: "ics465", verified: false, studentID: kcID},
    {semesterID: RadGrad.semester.get("Spring", 2018), course: "oth2xx", verified: false, studentID: kcID},
    {semesterID: RadGrad.semester.get("Spring", 2018), course: "oth2xx", verified: false, studentID: kcID},
    {semesterID: RadGrad.semester.get("Spring", 2018), course: "oth3xx", verified: false, studentID: kcID}
  ];

  let sampleCourseInstanceIDs = _.map(sampleCourseInstanceData, RadGrad.courseinstance.define);

  let sampleOpportunityInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2015), opportunity: "ieee-manoa", verified: true, hrswk: 10, studentID: kcID}];

  let sampleOpportunityInstanceIDs = _.map(sampleOpportunityInstanceData, RadGrad.opportunityinstance.define);

  let sampleDegreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: sampleCourseInstanceIDs,
    opportunityInstanceIDs: sampleOpportunityInstanceIDs,
    workInstanceIDs: sampleWorkInstanceIDs,
    studentID: kcID
  });

  RadGrad.user.setDegreePlanID(kcID, sampleDegreePlan);
  RadGrad.user.setDegreeGoalIDs(kcID, [RadGrad.slug.getEntityID("web-developer", "DegreeGoal")]);

  RadGrad.user.setInterestTagIDs(kcID,
      [RadGrad.slug.getEntityID("web-design", "Tag"),
        RadGrad.slug.getEntityID("software-engineering", "Tag")]);

  RadGrad.user.setPicture(kcID, "http://i.ytimg.com/vi/8gHw453kc44/maxresdefault.jpg");
  RadGrad.user.setAboutMe(kcID, "I am a sophomore in ICS and interested in being able to design websites for various companies.");
  RadGrad.user.setSemesterID(kcID, RadGrad.semester.get("Spring", 2018));
};

