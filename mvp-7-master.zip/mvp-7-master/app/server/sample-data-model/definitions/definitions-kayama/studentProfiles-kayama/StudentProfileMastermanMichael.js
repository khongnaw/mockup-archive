defineStudentProfileMastermanMichael = function() {
  let mmID = RadGrad.user.findBySlug("mastermanmichael")._id;

  let sampleWorkInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2015), hrswk: 10, studentID: mmID}];

  let sampleWorkInstanceIDs = _.map(sampleWorkInstanceData, RadGrad.workinstance.define);

  let sampleCourseInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics111", verified: false, studentID: mmID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: false, studentID: mmID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics141", verified: false, studentID: mmID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: false, studentID: mmID}
  ];

  let sampleCourseInstanceIDs = _.map(sampleCourseInstanceData, RadGrad.courseinstance.define);

  let sampleOpportunityInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2015), opportunity: "acm-manoa", verified: true, hrswk: 10, studentID: mmID}];

  let sampleOpportunityInstanceIDs = _.map(sampleOpportunityInstanceData, RadGrad.opportunityinstance.define);

  let sampleDegreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: sampleCourseInstanceIDs,
    opportunityInstanceIDs: sampleOpportunityInstanceIDs,
    workInstanceIDs: sampleWorkInstanceIDs,
    studentID: mmID
  });

  RadGrad.user.setDegreePlanID(mmID, sampleDegreePlan);
  RadGrad.user.setDegreeGoalIDs(mmID, [RadGrad.slug.getEntityID("game-designer", "DegreeGoal")]);

  RadGrad.user.setInterestTagIDs(mmID,
      [RadGrad.slug.getEntityID("game-design", "Tag"),
        RadGrad.slug.getEntityID("computer-graphics", "Tag")]);

  RadGrad.user.setPicture(mmID, "http://previews.123rf.com/images/vgstudio/vgstudio1006/vgstudio100600030/7268971-Portrait-of-happy-smiling-man-isolated-on-white-Stock-Photo-man-men-face.jpg");
  RadGrad.user.setAboutMe(mmID, "I am a freshman in ICS and interested in creating my own game.  I have played video games all my life and I wish to pursue a career in game designing.");
  RadGrad.user.setSemesterID(mmID, RadGrad.semester.get("Spring", 2019));
};

