defineStudentProfileJulianBruno = function() {
  let jb = RadGrad.user.findBySlug("julianbruno")._id;

  let sampleWorkInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2015), hrswk: 15, studentID: jb},
    {semesterID: RadGrad.semester.get("Spring", 2016), hrswk: 15, studentID: jb},
    {semesterID: RadGrad.semester.get("Summer", 2016), hrswk: 30, studentID: jb}
  ];

  let sampleWorkInstanceIDs = _.map(sampleWorkInstanceData, RadGrad.workinstance.define);

  let sampleCourseInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics141", verified: false, grade: "A", studentID: jb},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics111", verified: false, grade: "A", studentID: jb, credithrs: 4},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: false, grade: "A", studentID: jb, credithrs: 4},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: false, grade: "A", studentID: jb},

    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics211", verified: false, studentID: jb, credithrs: 4},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics241", verified: false, studentID: jb},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: false, studentID: jb, credithrs: 4},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: jb},

    {semesterID: RadGrad.semester.get("Summer", 2016), course: "oth1xx", verified: false, studentID: jb},

    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ics311", verified: false, studentID: jb, credithrs: 4},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ics212", verified: false, studentID: jb},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth1xx", verified: false, studentID: jb},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth1xx", verified: false, studentID: jb, credithrs: 1},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth1xx", verified: false, studentID: jb},

    {semesterID: RadGrad.semester.get("Spring", 2017), course: "ics331", verified: false, studentID: jb},
    {semesterID: RadGrad.semester.get("Spring", 2017), course: "ics321", verified: false, studentID: jb},
    {semesterID: RadGrad.semester.get("Spring", 2017), course: "oth1xx", verified: false, studentID: jb},
    {semesterID: RadGrad.semester.get("Spring", 2017), course: "oth1xx", verified: false, studentID: jb},
    {semesterID: RadGrad.semester.get("Spring", 2017), course: "oth1xx", verified: false, studentID: jb, credithrs: 1},

    {semesterID: RadGrad.semester.get("Summer", 2017), course: "oth1xx", verified: false, studentID: jb},

    {semesterID: RadGrad.semester.get("Fall", 2017), course: "ics361", verified: false, studentID: jb},
    {semesterID: RadGrad.semester.get("Fall", 2017), course: "ics314", verified: false, studentID: jb},
    {semesterID: RadGrad.semester.get("Fall", 2017), course: "oth1xx", verified: false, studentID: jb},
    {semesterID: RadGrad.semester.get("Fall", 2017), course: "oth2xx", verified: false, studentID: jb},
    {semesterID: RadGrad.semester.get("Fall", 2017), course: "oth1xx", verified: false, studentID: jb}
  ];

  let sampleCourseInstanceIDs = _.map(sampleCourseInstanceData, RadGrad.courseinstance.define);

  let sampleOpportunityInstanceData = [
    {semesterID: RadGrad.semester.get("Spring", 2016), opportunity: "acm-manoa", verified: true, hrswk: 10, studentID: jb}
  ];

  let sampleOpportunityInstanceIDs = _.map(sampleOpportunityInstanceData, RadGrad.opportunityinstance.define);

  let sampleDegreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: sampleCourseInstanceIDs,
    opportunityInstanceIDs: sampleOpportunityInstanceIDs,
    workInstanceIDs: sampleWorkInstanceIDs,
    studentID: jb
  });

  RadGrad.user.setDegreePlanID(jb, sampleDegreePlan);
  RadGrad.user.setDegreeGoalIDs(jb, [RadGrad.slug.getEntityID("information-security-analyst", "DegreeGoal"), RadGrad.slug.getEntityID("bioinformatics-developer", "DegreeGoal"), RadGrad.slug.getEntityID("game-designer", "DegreeGoal")]);

  RadGrad.user.setInterestTagIDs(jb,
      [RadGrad.slug.getEntityID("web-design", "Tag"),
        RadGrad.slug.getEntityID("java", "Tag"),
        RadGrad.slug.getEntityID("game-design", "Tag"),
        RadGrad.slug.getEntityID("computer-security", "Tag"),
        RadGrad.slug.getEntityID("network-security", "Tag"),
        RadGrad.slug.getEntityID("javascript", "Tag")
      ]);

  RadGrad.user.setPicture(jb, "http://ichef.bbci.co.uk/news/200/media/images/69871000/jpg/_69871689_dolan-cummings.jpg");
  RadGrad.user.setAboutMe(jb, "I am currently pursuing a degree in Computer Science. I have not chosen a specific field of Computer Science that I would like to go into but continually am seeking opportunties in various different areas.");
  RadGrad.user.setSemesterID(jb, RadGrad.semester.get("Spring", 2019));
};
