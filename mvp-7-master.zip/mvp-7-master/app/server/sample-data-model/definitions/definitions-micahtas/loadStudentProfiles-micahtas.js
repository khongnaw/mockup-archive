defineStudentProfilesmicahtas = function(){
  defineStudentProfileShotaIchirou();
  defineStudentProfileMerlinNormand();
  defineStudentProfileMelanieJanine();
  defineStudentProfileDarrenEmmet();
  defineStudentProfileJulianBruno();
  defineStudentProfileAllenSteafan();
  defineStudentProfileSimonIvor();
  defineStudentProfileYunAi();
}
