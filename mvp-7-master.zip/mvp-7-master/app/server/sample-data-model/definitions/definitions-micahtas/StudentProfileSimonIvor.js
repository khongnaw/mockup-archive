defineStudentProfileSimonIvor = function() {
  let si = RadGrad.user.findBySlug("simonivor")._id;

  let sampleWorkInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2015), hrswk: 10, studentID: si},
    {semesterID: RadGrad.semester.get("Spring", 2016), hrswk: 10, studentID: si}
  ];

  let sampleWorkInstanceIDs = _.map(sampleWorkInstanceData, RadGrad.workinstance.define);

  let sampleCourseInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics141", verified: false, grade: "A", studentID: si},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics111", verified: false, grade: "B", studentID: si, credithrs: 4},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: false, grade: "A", studentID: si, credithrs: 4},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: false, grade: "B", studentID: si},

    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics211", verified: false, studentID: si, credithrs: 4},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics241", verified: false, studentID: si},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: false, studentID: si, credithrs: 4},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: si},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: si},

    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ics311", verified: false, studentID: si, credithrs: 4},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ics212", verified: false, studentID: si},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth1xx", verified: false, studentID: si},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth1xx", verified: false, studentID: si, credithrs: 1},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth1xx", verified: false, studentID: si}
  ];

  let sampleCourseInstanceIDs = _.map(sampleCourseInstanceData, RadGrad.courseinstance.define);

  let sampleOpportunityInstanceData = [
  ];

  let sampleOpportunityInstanceIDs = _.map(sampleOpportunityInstanceData, RadGrad.opportunityinstance.define);

  let sampleDegreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: sampleCourseInstanceIDs,
    opportunityInstanceIDs: sampleOpportunityInstanceIDs,
    workInstanceIDs: sampleWorkInstanceIDs,
    studentID: si
  });

  RadGrad.user.setDegreePlanID(si, sampleDegreePlan);
  RadGrad.user.setDegreeGoalIDs(si, [RadGrad.slug.getEntityID("game-designer", "DegreeGoal")]);

  RadGrad.user.setInterestTagIDs(si,
      [RadGrad.slug.getEntityID("game-design", "Tag"),
        RadGrad.slug.getEntityID("computer-graphics", "Tag"),
        RadGrad.slug.getEntityID("human-computer-interaction", "Tag"),
        RadGrad.slug.getEntityID("computer-engineering", "Tag"),
        RadGrad.slug.getEntityID("data-visualization", "Tag")
      ]);

  RadGrad.user.setPicture(si, "http://www.rca.ac.uk/media/images/james_face.focus-none.width-300.JPG");
  RadGrad.user.setAboutMe(si, "I am currently going into my third semester in the Fall of 2016. For my degree I am looking to either go into Computer Science or Computer Engineering not sure which yet, but am leaning more towards the path of Computer Science. I know for a career I would like to go into game design, this interest arose because I have been playing games for a long time.");
  RadGrad.user.setSemesterID(si, RadGrad.semester.get("Spring", 2019));
};
