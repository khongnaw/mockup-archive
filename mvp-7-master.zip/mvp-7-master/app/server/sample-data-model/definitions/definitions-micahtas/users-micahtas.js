defineUsers_micahtas = function(){
  let Users = [
    {
      firstName: "Shota",
      middleName: "",
      lastName: "Ichirou",
      slug: "shotaichirou",
      password: "foo",
      uhEmail: "shotaichirou@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Merlin",
      middleName: "",
      lastName: "Normand",
      slug: "merlinnormand",
      password: "foo",
      uhEmail: "merlinnormand@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Melanie",
      middleName: "",
      lastName: "Janine",
      slug: "melaniejanine",
      password: "foo",
      uhEmail: "melaniejanine@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Darren",
      middleName: "",
      lastName: "Emmet",
      slug: "darrenemmet",
      password: "foo",
      uhEmail: "darrenemmet@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Julian",
      middleName: "",
      lastName: "Bruno",
      slug: "julianbruno",
      password: "foo",
      uhEmail: "julianbruno@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Allen",
      middleName: "",
      lastName: "Steafan",
      slug: "allensteafan",
      password: "foo",
      uhEmail: "allensteafan@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Simon",
      middleName: "",
      lastName: "Ivor",
      slug: "simonivor",
      password: "foo",
      uhEmail: "simonivor@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Yun",
      middleName: "",
      lastName: "Ai",
      slug: "yunai",
      password: "foo",
      uhEmail: "yunai@hawaii.edu",
      role: RadGrad.role.student
    }
  ];
  _.each(Users, RadGrad.user.define);
}
