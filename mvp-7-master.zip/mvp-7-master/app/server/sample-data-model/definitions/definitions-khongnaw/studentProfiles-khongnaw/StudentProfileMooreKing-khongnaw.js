
/**
 * Created by sora on 1/26/16.
 */
defineStudentProfileMooreKing = function() {
    let acID = RadGrad.user.findBySlug("mooreking")._id;

    let sampleWorkInstanceData = [
        {semesterID: RadGrad.semester.get("Summer", 2014), hrswk: 20, studentID: acID}

    ];

    let sampleWorkInstanceIDs = _.map(sampleWorkInstanceData, RadGrad.workinstance.define);

    let sampleCourseInstanceData = [
        {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "A+", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "A", studentID: acID, credithrs : 4},
        {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "B", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "A", studentID: acID ,credithrs : 1},
        {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "B", studentID: acID},


        {semesterID: RadGrad.semester.get("Spring", 2014), course: "ee160", verified: true, grade: "A", studentID: acID, credithrs: 4},
        {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: true, grade: "A+", studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: true, grade: "B", studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: true, grade: "A", studentID: acID},

        {semesterID: RadGrad.semester.get("Summer", 2014), course: "oth2xx", verified: true, grade: "A+", studentID: acID},




        {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee211", verified: false, studentID: acID, credithrs: 4},
        {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee260", verified: false, studentID: acID, credithrs: 4},
        {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee296", verified: false, studentID: acID, credithrs: 1},
        {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: false, studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: false, studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: false, studentID: acID, credithrs: 1},

        {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee213", verified: false, studentID: acID, credithrs : 4},
        {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee205", verified: false, studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth2xx", verified: false, studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth2xx", verified: false, studentID: acID},

        {semesterID: RadGrad.semester.get("Summer", 2015), course: "oth2xx", verified: false, studentID: acID},

        {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee324", verified: false, studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee371", verified: false, studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee361", verified: false, studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: false, studentID: acID, credithrs : 1}, // need ee361l slugs
        {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: false, studentID: acID, credithrs : 1}, // need ee362 slugs
        {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee396", verified: false, studentID: acID, credithrs : 2}, // need ee361l slugs

        {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee315", verified: false, studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee323", verified: false, studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: false, studentID: acID, credithrs : 1}, // need ee323l
        {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee367", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: false, studentID: acID, credithrs : 1}, // need ee367l
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ee406", verified: false, studentID: acID},

        {semesterID: RadGrad.semester.get("Summer", 2016), course: "oth2xx", verified: false, studentID: acID},
        {semesterID: RadGrad.semester.get("Summer", 2016), course: "oth2xx", verified: false, studentID: acID},

        {semesterID: RadGrad.semester.get("Fall", 2016), course: "ee342", verified: false, studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2016), course: "ee468", verified: false, studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2016), course: "ee366", verified: false, studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth2xx", verified: false, studentID: acID},

        {semesterID: RadGrad.semester.get("Spring", 2017), course: "ee495", verified: false, studentID: acID, credithrs : 1},  // need ee495
        {semesterID: RadGrad.semester.get("Spring", 2017), course: "ee496", verified: false, studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2017), course: "oth2xx", verified: false, studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2017), course: "oth2xx", verified: false, studentID: acID}

    ];

    let sampleCourseInstanceIDs = _.map(sampleCourseInstanceData, RadGrad.courseinstance.define);

    let sampleOpportunityInstanceData = [
        {semesterID: RadGrad.semester.get("Fall", 2014), opportunity: "ieee-manoa", verified: true, hrswk: 1, studentID: acID},

    ];

    let sampleOpportunityInstanceIDs = _.map(sampleOpportunityInstanceData, RadGrad.opportunityinstance.define);

    let sampleDegreePlan = RadGrad.degreeplan.define({
        courseInstanceIDs: sampleCourseInstanceIDs,
        opportunityInstanceIDs: sampleOpportunityInstanceIDs,
        workInstanceIDs: sampleWorkInstanceIDs,
        studentID: acID
    });

    RadGrad.user.setDegreePlanID(acID, sampleDegreePlan);
    RadGrad.user.setDegreeGoalIDs(acID,
        [RadGrad.slug.getEntityID("bs-ce", "DegreeGoal")]);
    RadGrad.user.setInterestTagIDs(acID,
        [RadGrad.slug.getEntityID("distributed-computing", "Tag"),
            RadGrad.slug.getEntityID("mathematics", "Tag"),
            RadGrad.slug.getEntityID("microprocessor-design", "Tag"),
            RadGrad.slug.getEntityID("operating-systems", "Tag"),
            RadGrad.slug.getEntityID("electrical-engineering", "Tag"),
            RadGrad.slug.getEntityID("circuit-design", "Tag") ]);

    RadGrad.user.setPicture(acID, "http://ameristaffinc.net/wp-content/uploads/2013/06/happy-computer-guy.jpg");
    RadGrad.user.setAboutMe(acID, "I am a somphmore in CENG. I'm interested in digital logic and computer hardware design. I hope to one day either work for Intel or AMD as a hardware engineer.");
    RadGrad.user.setSemesterID(acID, RadGrad.semester.get("Spring", 2017));
};
