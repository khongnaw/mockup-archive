/**
 * Created by sora on 1/26/16.
 */

defineStudentProfileRoryBlue = function() {
    let acID = RadGrad.user.findBySlug("roryblue")._id;

    let sampleWorkInstanceData = [
        {semesterID: RadGrad.semester.get("Fall", 2013), hrswk: 10, studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2014), hrswk: 10, studentID: acID}

    ];

    let sampleWorkInstanceIDs = _.map(sampleWorkInstanceData, RadGrad.workinstance.define);

    let sampleCourseInstanceData = [
        {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "A", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "C", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "B", studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "A", studentID: acID},


        {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: false, studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: false, studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: false, studentID: acID},
        {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: false, studentID: acID},

        {semesterID: RadGrad.semester.get("Fall", 2014), course: "ics111", verified: false, studentID: acID},
        {semesterID: RadGrad.semester.get("Fall", 2014), course: "ics141", verified: false, studentID: acID}



    ];

    let sampleCourseInstanceIDs = _.map(sampleCourseInstanceData, RadGrad.courseinstance.define);

    let sampleOpportunityInstanceData = [
        {semesterID: RadGrad.semester.get("Spring", 2014), opportunity: "acm-manoa", verified: true, hrswk: 1, studentID: acID},

    ];

    let sampleOpportunityInstanceIDs = _.map(sampleOpportunityInstanceData, RadGrad.opportunityinstance.define);

    let sampleDegreePlan = RadGrad.degreeplan.define({
        courseInstanceIDs: sampleCourseInstanceIDs,
        opportunityInstanceIDs: sampleOpportunityInstanceIDs,
        workInstanceIDs: sampleWorkInstanceIDs,
        studentID: acID
    });

    RadGrad.user.setDegreePlanID(acID, sampleDegreePlan);
  /*  RadGrad.user.setDegreeGoalIDs(acID,
        [RadGrad.slug.getEntityID("game-designer", "DegreeGoal")]);
    //RadGrad.slug.getEntityID("bs-cs", "DegreeGoal")
    */
    RadGrad.user.setInterestTagIDs(acID,
        [RadGrad.slug.getEntityID("web-design", "Tag"),
            RadGrad.slug.getEntityID("bootstrap", "Tag") ]);

    RadGrad.user.setPicture(acID, "http://www.theheadshotguy.co.uk/wp-content/uploads/2013/07/John_Cassidy_The_Headshot_Guy_London_Andy_Murray_05.jpg");
    RadGrad.user.setAboutMe(acID, "I'm a freshman and I'm not sure what my career goal is but I love to draw, read manga, and watch anime.");
    RadGrad.user.setSemesterID(acID, RadGrad.semester.get("Fall", 2017));
};

