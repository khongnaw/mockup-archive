/**
 * Created by sora on 1/26/16.
 */

defineStudentProfileskhongnaw = function () {
    defineStudentProfileAlexanderHawkins();
    defineStudentProfileCarlRamirez();
    defineStudentProfileDerrickMcDaniel();
    defineStudentProfileKelsiePink();
    defineStudentProfileKelvinDawson();
    defineStudentProfileMooreKing();
    defineStudentProfileRichGilchrist();
    defineStudentProfileRoryBlue();
}
