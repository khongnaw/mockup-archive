/**
 * Created by symor on 1/27/2016.
 */
defineUsersSy = function() {
  let Users = [
    {
      firstName: "Ainslee",
      middleName: "",
      lastName: "Frideswide",
      slug: "ainsleefrideswide",
      password: "foo",
      uhEmail: "ainsleefrideswide@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Hermen",
      middleName: "",
      lastName: "Basseme",
      slug: "hermenbassem",
      password: "foo",
      uhEmail: "hermenbassem@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Robin",
      middleName: "",
      lastName: "Nkmura",
      slug: "robinnkmura",
      password: "foo",
      uhEmail: "robinnkmura@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Shota",
      middleName: "",
      lastName: "Sho",
      slug: "shotasho",
      password: "foo",
      uhEmail: "shotasho@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Carina",
      middleName: "",
      lastName: "Nan",
      slug: "carinanan",
      password: "foo",
      uhEmail: "carinanan@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Andre",
      middleName: "",
      lastName: "Jayanta",
      slug: "andrejayanta",
      password: "foo",
      uhEmail: "andrejayanta@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Frank",
      middleName: "",
      lastName: "Niels",
      slug: "frankniels",
      password: "foo",
      uhEmail: "frankniels@hawaii.edu",
      role: RadGrad.role.student
    },
    {
      firstName: "Nicole",
      middleName: "",
      lastName: "Lara",
      slug: "nicolelara",
      password: "foo",
      uhEmail: "nicolelara@hawaii.edu",
      role: RadGrad.role.student
    }


  ];

  _.each(Users, RadGrad.user.define);
}
