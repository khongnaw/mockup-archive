defineStudentProfilesSy = function () {
  defineStudentProfileAinsleeFrideswide();
  defineStudentProfileHermenBassem();
  defineStudentProfileAndreJayanta();
  defineStudentProfileCarinaNan();
  defineStudentProfileFrankNiels();
  defineStudentProfileNicoleLara();
  defineStudentProfilerobinnkmura();
  defineStudentProfileShotaSho();
}
