defineStudentProfileCarinaNan = function() {
  let acID = RadGrad.user.findBySlug("carinanan")._id;

  let sampleWorkInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2014), hrswk: 10, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), hrswk: 10, studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), hrswk: 10, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), hrswk: 10, studentID: acID}

  ];

  let sampleWorkInstanceIDs = _.map(sampleWorkInstanceData, RadGrad.workinstance.define);

  let sampleCourseInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics111", verified: true, grade: "A", studentID: acID, credithrs: 4},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics141", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth2xx", verified: true, grade: "B", studentID: acID, credithrs: 4},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: true, grade: "B", studentID: acID, credithrs: 1},

    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ics211", verified: false, grade: "A", studentID: acID, credithrs: 4},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ics241", verified: false, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth2xx", verified: false, grade: "B", studentID: acID, credithrs: 4},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth1xx", verified: false, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth1xx", verified: false, grade: "A", studentID: acID, credithrs: 1},

    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ics212", verified: false, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ics311", verified: false, grade: "B", studentID: acID, credithrs: 4},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth1xx", verified: false, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth1xx", verified: false, grade: "A", studentID: acID, credithrs: 1},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth1xx", verified: false, grade: "B", studentID: acID, credithrs: 4},

    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics331", verified: false, studentID: acID, credithrs: 4},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics313", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: acID, credithrs: 1},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth1xx", verified: false, studentID: acID, credithrs: 4},





  ];

  let sampleCourseInstanceIDs = _.map(sampleCourseInstanceData, RadGrad.courseinstance.define);

  let sampleOpportunityInstanceData = [
    {semesterID: RadGrad.semester.get("Spring", 2014), opportunity: "acm-manoa", verified: true, hrswk: 1, studentID: acID},

  ];

  let sampleOpportunityInstanceIDs = _.map(sampleOpportunityInstanceData, RadGrad.opportunityinstance.define);

  let sampleDegreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: sampleCourseInstanceIDs,
    opportunityInstanceIDs: sampleOpportunityInstanceIDs,
    workInstanceIDs: sampleWorkInstanceIDs,
    studentID: acID
  });

  RadGrad.user.setDegreePlanID(acID, sampleDegreePlan);
  RadGrad.user.setDegreeGoalIDs(acID,
   [RadGrad.slug.getEntityID("network-engineer", "DegreeGoal"),
   RadGrad.slug.getEntityID("bs-cs", "DegreeGoal")]);

  RadGrad.user.setInterestTagIDs(acID,
    [RadGrad.slug.getEntityID("computer-security", "Tag"),
    RadGrad.slug.getEntityID("cryptography", "Tag"),
    RadGrad.slug.getEntityID("telecommunications", "Tag"),
    RadGrad.slug.getEntityID("network-security", "Tag"),
      RadGrad.slug.getEntityID("wireless-networks", "Tag") ]);

  RadGrad.user.setPicture(acID, "http://teenlife.blogs.pressdemocrat.com/files/2010/09/codding.jpg");
  RadGrad.user.setAboutMe(acID, "I am a sophomore majoring in ics.");
  RadGrad.user.setSemesterID(acID, RadGrad.semester.get("Spring", 2018));
};

