defineStudentProfileAndreJayanta = function() {
  let acID = RadGrad.user.findBySlug("andrejayanta")._id;

  let sampleWorkInstanceData = [
    {semesterID: RadGrad.semester.get("Summer", 2014), hrswk: 40, studentID: acID},
    {semesterID: RadGrad.semester.get("Summer", 2015), hrswk: 40, studentID: acID}

  ];

  let sampleWorkInstanceIDs = _.map(sampleWorkInstanceData, RadGrad.workinstance.define);

  let sampleCourseInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ics111", verified: true, grade: "A", studentID: acID, credithrs: 4},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ics141", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: true, grade: "A", studentID: acID, credithrs: 4},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth1xx", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth1xx", verified: true, grade: "B", studentID: acID, credithrs: 1},

    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ics211", verified: true, grade: "A", studentID: acID, credithrs: 4},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ics241", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: true, grade: "B", studentID: acID, credithrs: 4},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth1xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth1xx", verified: true, grade: "A", studentID: acID, credithrs: 1},

    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics212", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics311", verified: true, grade: "B", studentID: acID, credithrs: 4},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: true, grade: "A", studentID: acID, credithrs: 1},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth1xx", verified: true, grade: "B", studentID: acID, credithrs: 4},

    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ics331", verified: true, grade: "A", studentID: acID, credithrs: 4},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ics313", verified: true, grade: "B", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth1xx", verified: true, grade: "C", studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth1xx", verified: true, grade: "C", studentID: acID, credithrs: 1},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth1xx", verified: true, grade: "B", studentID: acID, credithrs: 4},

    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ics321", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ics361", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ics423", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "ics332", verified: true, grade: "A", studentID: acID},
    {semesterID: RadGrad.semester.get("Fall", 2016), course: "oth2xx", verified: true, grade: "B", studentID: acID, credithrs: 4},

    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics455", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics464", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics425", verified: false, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth2xx", verified: false, studentID: acID, credithrs: 4}



  ];

  let sampleCourseInstanceIDs = _.map(sampleCourseInstanceData, RadGrad.courseinstance.define);

  let sampleOpportunityInstanceData = [
    {semesterID: RadGrad.semester.get("Spring", 2014), opportunity: "acm-manoa", verified: true, hrswk: 1, studentID: acID},

  ];

  let sampleOpportunityInstanceIDs = _.map(sampleOpportunityInstanceData, RadGrad.opportunityinstance.define);

  let sampleDegreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: sampleCourseInstanceIDs,
    opportunityInstanceIDs: sampleOpportunityInstanceIDs,
    workInstanceIDs: sampleWorkInstanceIDs,
    studentID: acID
  });

  RadGrad.user.setDegreePlanID(acID, sampleDegreePlan);
  RadGrad.user.setDegreeGoalIDs(acID,
   [RadGrad.slug.getEntityID("computer-system-engineer", "DegreeGoal")]);
   RadGrad.slug.getEntityID("bs-cs", "DegreeGoal")

  RadGrad.user.setInterestTagIDs(acID,
    [RadGrad.slug.getEntityID("mobile-devices", "Tag"),
    RadGrad.slug.getEntityID("web-design", "Tag"),
      RadGrad.slug.getEntityID("computer-architecture", "Tag") ]);

  RadGrad.user.setPicture(acID, "http://cdn.citynews.ro/sites/default/files/styles/442x293/public/www/articole/pandurul-buleica-se-face-student1361202600.jpg");
  RadGrad.user.setAboutMe(acID, "I am a senior majoring in computer science");
  RadGrad.user.setSemesterID(acID, RadGrad.semester.get("Spring", 2016));
};

