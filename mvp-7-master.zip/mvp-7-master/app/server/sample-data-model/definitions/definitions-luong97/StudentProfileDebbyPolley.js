defineDebbyPolleyProfile = function() {
  let acID = RadGrad.user.findBySlug("debbypolley")._id;

  let workInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2013), hrswk: 15, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), hrswk: 12, studentID: acID},

    {semesterID: RadGrad.semester.get("Fall", 2014), hrswk: 15, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), hrswk: 12, studentID: acID},

    {semesterID: RadGrad.semester.get("Fall", 2014), hrswk: 18, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), hrswk: 12, studentID: acID},

    {semesterID: RadGrad.semester.get("Fall", 2015), hrswk: 11, studentID: acID},
  ];

  let workInstanceIDs = _.map(workInstanceData, RadGrad.workinstance.define);

  let courseInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2012), course: "oth2xx", verified: true, grade: "A",studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Fall", 2012), course: "oth1xx", verified: true, grade: "B",studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Fall", 2012), course: "oth1xx", verified: true, grade: "B",studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Fall", 2012), course: "oth1xx", verified: true, grade: "C",studentID: acID, credithrs:3},

    {semesterID: RadGrad.semester.get("Spring", 2013), course: "ee160", verified: true, grade: "B+",studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth2xx", verified: true, grade: "B",studentID: acID, credithrs:4},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth2xx", verified: true, grade: "C",studentID: acID, credithrs:4},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth1xx", verified: true, grade: "B",studentID: acID, credithrs:1},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth1xx", verified: true, grade: "B",studentID: acID, credithrs:3},

    {semesterID: RadGrad.semester.get("Fall", 2013), course: "ee211", verified: true, grade: "C",studentID: acID, credithrs:4},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "ee260", verified: true, grade: "B",studentID: acID, credithrs:4},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "A",studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "D",studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "B",studentID: acID, credithrs:1},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "B",studentID: acID, credithrs:1},

    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ee205", verified: true, grade: "A",studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ee213", verified: true, grade: "A",studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: true, grade: "C",studentID: acID, credithrs:4},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: true, grade: "B",studentID: acID, credithrs:4},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth1xx", verified: true, grade: "B",studentID: acID, credithrs:3},

    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee324", verified: true, grade: "C",studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee371", verified: true, grade: "D+",studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee361", verified: true, grade: "B-",studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee361l", verified: true, grade: "A",studentID: acID, credithrs:1},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ics414", verified: true, grade: "B",studentID: acID, credithrs:3},

    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee315", verified: true, grade: "B",studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee323", verified: true, grade: "B",studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee323l", verified: true, grade: "B",studentID: acID, credithrs:1},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee367", verified: true, grade: "A",studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ee367l", verified: true, grade: "C",studentID: acID, credithrs:1},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee396", verified: true, grade: "A",studentID: acID, credithrs:3},

    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee342", verified: true, grade: "D", studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth3xx", verified: true, grade: "A", studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics314", verified: true, grade: "B", studentID: acID, credithrs:1},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee495", verified: true, grade: "A-", studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee496", verified: true, grade: "A-", studentID: acID, credithrs:3},

    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics414", verified: true, studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth3xx", verified: true, studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth3xx", verified: true, studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth3xx", verified: true, studentID: acID, credithrs:3},
  ];

  let courseInstanceIDs = _.map(courseInstanceData, RadGrad.courseinstance.define);

  let opportunityInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2013), opportunity: "ieee-manoa", verified: true, hrswk: 10, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), opportunity: "ieee-manoa", verified: true, hrswk: 10, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), opportunity: "itma-manoa", verified: true, hrswk: 10, studentID: acID},

    {semesterID: RadGrad.semester.get("Fall", 2014), opportunity: "ieee-manoa", verified: true, hrswk: 10, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), opportunity: "ieee-manoa", verified: true, hrswk: 10, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), opportunity: "acm-manoa", verified: true, hrswk: 10, studentID: acID},
  ];

  let opportunityInstanceIDs = _.map(opportunityInstanceData, RadGrad.opportunityinstance.define);

  let degreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: courseInstanceIDs,
    opportunityInstanceIDs: opportunityInstanceIDs,
    workInstanceIDs: workInstanceIDs,
    studentID: acID
  });

  RadGrad.user.setDegreePlanID(acID, degreePlan);
  /*
  RadGrad.user.setDegreeGoalIDs(acID,
      [
          RadGrad.slug.getEntityID("software-engineer", "DegreeGoal")
      ]);
  */
  RadGrad.user.setInterestTagIDs(acID,
      [
        RadGrad.slug.getEntityID("software-engineering", "Tag"),
        RadGrad.slug.getEntityID("oop", "Tag"),
        RadGrad.slug.getEntityID("operating-systems", "Tag"),
      ]);

  RadGrad.user.setPicture(acID, "http://static1.1.sqspcdn.com/static/f/635776/24849182/1399577104983/Barany_ProfileWatsonsBay.jpg?token=P%2BHdobTNbi233huRFB4MFJGaB1k%3D");
  RadGrad.user.setAboutMe(acID, "I'm about to graduate with my BS in Computer Science and hope to get a job in the software engineering industry.");
  RadGrad.user.setSemesterID(acID, RadGrad.semester.get("Spring", 2016));
};

