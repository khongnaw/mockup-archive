defineKailynDaniellProfile = function() {
  let acID = RadGrad.user.findBySlug("kailyndaniell")._id;

  let workInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2013), hrswk: 10, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), hrswk: 10, studentID: acID},
    {semesterID: RadGrad.semester.get("Summer", 2013), hrswk: 40, studentID: acID},

    {semesterID: RadGrad.semester.get("Fall", 2014), hrswk: 10, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), hrswk: 15, studentID: acID},
    {semesterID: RadGrad.semester.get("Summer", 2013), hrswk: 40, studentID: acID},

    {semesterID: RadGrad.semester.get("Fall", 2014), hrswk: 8, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), hrswk: 10, studentID: acID},

    {semesterID: RadGrad.semester.get("Fall", 2014), hrswk: 15, studentID: acID},
    {semesterID: RadGrad.semester.get("Summer", 2013), hrswk: 30, studentID: acID},
  ];

  let workInstanceIDs = _.map(workInstanceData, RadGrad.workinstance.define);

  let courseInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2012), course: "oth2xx", verified: true, grade: "A",studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Fall", 2012), course: "oth1xx", verified: true, grade: "B",studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Fall", 2012), course: "oth1xx", verified: true, grade: "B",studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Fall", 2012), course: "oth1xx", verified: true, grade: "C",studentID: acID, credithrs:3},

    {semesterID: RadGrad.semester.get("Spring", 2013), course: "ee160", verified: true, grade: "B+",studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth2xx", verified: true, grade: "B",studentID: acID, credithrs:4},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth2xx", verified: true, grade: "C",studentID: acID, credithrs:4},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth1xx", verified: true, grade: "B",studentID: acID, credithrs:1},
    {semesterID: RadGrad.semester.get("Spring", 2013), course: "oth1xx", verified: true, grade: "B",studentID: acID, credithrs:3},

    {semesterID: RadGrad.semester.get("Fall", 2013), course: "ee211", verified: true, grade: "C",studentID: acID, credithrs:4},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "ee260", verified: true, grade: "B",studentID: acID, credithrs:4},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "A",studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "D",studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "B",studentID: acID, credithrs:1},
    {semesterID: RadGrad.semester.get("Fall", 2013), course: "oth2xx", verified: true, grade: "B",studentID: acID, credithrs:1},

    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ee205", verified: true, grade: "A",studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ee213", verified: true, grade: "A",studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: true, grade: "C",studentID: acID, credithrs:4},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth2xx", verified: true, grade: "B",studentID: acID, credithrs:4},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "oth1xx", verified: true, grade: "B",studentID: acID, credithrs:3},

    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee324", verified: true, grade: "C",studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee371", verified: true, grade: "D+",studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee361", verified: true, grade: "B-",studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ee361l", verified: true, grade: "A",studentID: acID, credithrs:1},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "ics414", verified: true, grade: "B",studentID: acID, credithrs:3},

    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee315", verified: true, grade: "B",studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee323", verified: true, grade: "B",studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee323l", verified: true, grade: "B",studentID: acID, credithrs:1},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee367", verified: true, grade: "A",studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Spring", 2014), course: "ee367l", verified: true, grade: "C",studentID: acID, credithrs:1},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "ee396", verified: true, grade: "A",studentID: acID, credithrs:3},

    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee342", verified: true, grade: "D", studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "oth3xx", verified: true, grade: "A", studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ics314", verified: true, grade: "B", studentID: acID, credithrs:1},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee495", verified: true, grade: "A-", studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Fall", 2015), course: "ee496", verified: true, grade: "A-", studentID: acID, credithrs:3},

    {semesterID: RadGrad.semester.get("Spring", 2016), course: "ics414", verified: true, studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth3xx", verified: true, studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth3xx", verified: true, studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Spring", 2016), course: "oth3xx", verified: true, studentID: acID, credithrs:3},
  ];

  let courseInstanceIDs = _.map(courseInstanceData, RadGrad.courseinstance.define);

  let opportunityInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2013), opportunity: "ieee-manoa", verified: true, hrswk: 10, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), opportunity: "ieee-manoa", verified: true, hrswk: 10, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2014), opportunity: "itma-manoa", verified: true, hrswk: 10, studentID: acID},

    {semesterID: RadGrad.semester.get("Fall", 2014), opportunity: "ieee-manoa", verified: true, hrswk: 10, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), opportunity: "ieee-manoa", verified: true, hrswk: 10, studentID: acID},
    {semesterID: RadGrad.semester.get("Spring", 2015), opportunity: "acm-manoa", verified: true, hrswk: 10, studentID: acID}
  ];

  let opportunityInstanceIDs = _.map(opportunityInstanceData, RadGrad.opportunityinstance.define);

  let degreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: courseInstanceIDs,
    opportunityInstanceIDs: opportunityInstanceIDs,
    workInstanceIDs: workInstanceIDs,
    studentID: acID
  });

  RadGrad.user.setDegreePlanID(acID, degreePlan);
  RadGrad.user.setDegreeGoalIDs(acID,
      [
          RadGrad.slug.getEntityID("computer-system-engineer", "DegreeGoal")
      ]);
  RadGrad.user.setInterestTagIDs(acID,
      [
        RadGrad.slug.getEntityID("software-engineering", "Tag"),
        RadGrad.slug.getEntityID("operating-systems", "Tag"),
      ]);

  RadGrad.user.setPicture(acID, "http://i.dailymail.co.uk/i/pix/2015/11/20/16/2EA540CA00000578-3327325-image-a-11_1448038512033.jpg");
  RadGrad.user.setAboutMe(acID, "I didn't think I would end up in Computer Engineering, but here I am! I'm not the best of students but I really enjoy the field and hope to graduate soon.");
  RadGrad.user.setSemesterID(acID, RadGrad.semester.get("Spring", 2016));
};

