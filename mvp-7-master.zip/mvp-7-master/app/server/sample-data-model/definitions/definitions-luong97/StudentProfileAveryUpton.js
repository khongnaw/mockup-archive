defineAveryUptonProfile = function() {
  let acID = RadGrad.user.findBySlug("averyupton")._id;

  let workInstanceData = [
      {semesterID: RadGrad.semester.get("Fall", 2015), hrswk: 12, studentID: acID},
      {semesterID: RadGrad.semester.get("Spring", 2015), hrswk: 12, studentID: acID},
  ];

  let workInstanceIDs = _.map(workInstanceData, RadGrad.workinstance.define);

  let courseInstanceData = [
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth2xx", verified: true, grade: "A",studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth1xx", verified: true, grade: "B",studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth1xx", verified: true, grade: "B",studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Fall", 2014), course: "oth1xx", verified: true, grade: "A",studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth2xx", verified: true, grade: "A",studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth2xx", verified: true, grade: "A",studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth1xx", verified: true, grade: "B",studentID: acID, credithrs:3},
    {semesterID: RadGrad.semester.get("Spring", 2015), course: "oth1xx", verified: true, grade: "B",studentID: acID, credithrs:3},
  ];

  let courseInstanceIDs = _.map(courseInstanceData, RadGrad.courseinstance.define);

  let opportunityInstanceData = [

  ];

  let opportunityInstanceIDs = _.map(opportunityInstanceData, RadGrad.opportunityinstance.define);

  let degreePlan = RadGrad.degreeplan.define({
    courseInstanceIDs: courseInstanceIDs,
    opportunityInstanceIDs: opportunityInstanceIDs,
    workInstanceIDs: workInstanceIDs,
    studentID: acID
  });

  RadGrad.user.setDegreePlanID(acID, degreePlan);
  RadGrad.user.setInterestTagIDs(acID,
      [
        RadGrad.slug.getEntityID("english", "Tag"),
        RadGrad.slug.getEntityID("psychology", "Tag"),
        RadGrad.slug.getEntityID("sociology", "Tag"),
        RadGrad.slug.getEntityID("android", "Tag"),
      ]);

  RadGrad.user.setPicture(acID, "http://www.american.edu/uploads/standard/large/avery-luck-student-teaching_2.jpg");
  RadGrad.user.setAboutMe(acID, "I'm currently a freshmen enrolled in the ICS program - I'm excited to be in the field and am looking forward to seeing what I would be interested in exploring what I want to do professionally.");
  RadGrad.user.setSemesterID(acID, RadGrad.semester.get("Spring", 2018));
};
