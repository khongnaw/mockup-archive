// Before loading sample data model, delete all pre-existing data.
// RadGrad.deleteAll();
// RadGrad.verifyEmptyDataModel();

users = RadGrad.user.find().fetch()
console.log("Found users: " + String(users));

if( users.length < 1 ){
    console.log("No seed users were found. Seeding data");

    // See the definitions/ directory for the definitions of these functions.
    // Order of invocation of the following functions is sometimes important.
    // For example, Tag definitions refer to TagTypes, so TagTypes must be defined first.

    console.log("Seeding Tags");
    defineOpportunityTypes();
    defineTagTypes();

    /* Define tags */
    defineTags();
    defineTagMkshimod();
    defineTagAljonp();
    defineTagKayama();
    defineTagbjboado();
    defineTagkhongnaw();
    defineTagRorya();
    defineTagLuong97();
    defineTagSkchun();

    console.log("Seeding Semesters");
    /* Define Semesters */
    defineSemesters();

    console.log("Seeding Users");
    /* Define Users */
    defineUsers();
    defineUsersSkchun();
    defineUsers_kayama();
    defineUsers_khongnaw();
    defineUsersAljonp();
    defineUsers_gyim();
    defineUsersmichael4();
    defineUsersRorya();
    defineUsers_micahtas();
    defineUsersbjboado();
    defineUsersSy();
    defineUsers_mkshimod();
    defineUsersJgarces();
    defineUsersLuong97();

    console.log("Seeding Opportunities");
    /* Define Opportunities */
    defineOpportunities();
    defineOpportunitiesRorya();
    defineSkchunOpportunities();
    defineOpportunitiesbjboado();

    console.log("Seeding Courses");
    /* Define Courses */
    defineCourses();
    defineCoursesAljonp();
    defineCoursesKayama();
    defineCoursesKhongnaw();
    defineCoursesRorya();
    defineCoursesLuong97();
    defineCoursesSkchun();
    defineCoursesbjboado();
    defineCoursesMkshimod();
    defineCoursesSy();
    defineCoursesJgarces();

    console.log("Seeding Degree Goals");
    /* Define Degree Goals */
    defineDegreeGoals();
    defineDegreeGoalsKayama();
    defineDegreeGoalsAljonp();
    defineDegreeGoalsJgarces();

    console.log("Seeding Profiles");
    /* Define Profiles */
    defineStudentProfile();
    defineStudentProfilesRorya();
    defineStudentProfileskayama();
    defineStudentProfileskhongnaw();
    defineStudentProfilesAljonp();

    defineStudentProfilesmichael4();
    defineStudentProfilesmichael4();
    defineStudentProfilesgyim();
    defineStudentProfilesSkchun();

    defineStudentProfilesmicahtas();
    defineStudentProfilesbjboado();
    defineStudentProfilesSy();
    defineStudentProfilesmkshimod();
    defineStudentProfilesJgarces();
    defineStudentProfilesLuong97();

}
else{
    console.log("Seed users were found. Data will not be seeded");
}
