This folder contains seed data for this radgrad
mockup. The seed data was taken from a collaborative
assignment done by the students of the UH Manoa ICS 414
course in Spring 2016.

Source: https://github.com/radgrad/ics-data-model

