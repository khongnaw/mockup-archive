function popIt(){
  // the "href" attribute of .modal-trigger must specify the modal ID that wants to be triggered
  $('.modal-trigger').leanModal();
}


function scrollTab(){

  $('ul.tabs').each(function(){
    // For each set of tabs, we want to keep track of
    // which tab is active and its associated content
    var $active, $content, $links = $(this).find('a');

    // If the location.hash matches one of the links, use that as the active tab.
    // If no match is found, use the first link as the initial active tab.
    $active = $($links.filter('[href="'+location.hash+'"]')[0] || $links[0]);
    $active.addClass('active');

    $content = $($active[0].hash);

    // Hide the remaining content
    $links.not($active).each(function () {
      $(this.hash).hide();
    });

    // Bind the click event handler
    $(this).on('click', 'a', function(e){

      // Make the old tab inactive.
      $active.removeClass('active');
      $content.hide();

      // Update the variables with the new link and content
      $active = $(this);
      $content = $(this.hash);

      // Make the tab active.
      $active.addClass('active');
      $content.show();

      // Prevent the anchor's default click action
      e.preventDefault();
    });
  });
};

function renderCharts(){
  var GPA= document.getElementById("GPA").getContext("2d");
  var pieData = [

    {
      value : 3.5,
      color : "#4caf50"
    }

  ];

  var pieOptions = {
    segmentShowStroke : false,
    animateScale : true
  };

  new Chart(GPA).Pie(pieData, pieOptions);

  var CREDITS= document.getElementById("CREDITS").getContext("2d");
  var pieData2 = [

    {
      value : 90,
      color : "#4caf50"
    },

    {
      value : 10,
      color : "#d50000"
    }

  ];

  var pieOptions2 = {
    segmentShowStroke : false,
    animateScale : true
  };

  new Chart(CREDITS).Pie(pieData2, pieOptions2);

  var RANK = document.getElementById("RANK").getContext("2d");
  var pieData3 = [

    {
      value : 95,
      color : "#64b5f6"
    }

  ];

  var pieOptions3 = {
    segmentShowStroke : false,
    animateScale : true
  };

  new Chart(RANK).Pie(pieData3, pieOptions3);
}

renderCharts();
scrollTab();
popIt();