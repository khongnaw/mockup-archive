Template.opportunityAdvisor.onRendered(function () {
  $('.tooltipped').tooltip();
  $('.collapsible').collapsible({
    accordion: false // A setting that changes the collapsible behavior to expandable instead of the default accordion style
  });
  $('select').material_select();

});

Template.opportunityAdvisor.helpers({

  'getAllOpportunities': function () {

    var allOpportunities = Opportunities.find().fetch();

    var opportunitiesAdded = OpportunityHistory.find({user: Meteor.user().profile.name}).fetch().map(function (object) {
      return object.courseSlug;
    });

    var listOpportunities = [];

    _.map(allOpportunities, function(course){
      if(opportunitiesAdded.indexOf(course.slug) < 0 ){
        listOpportunities.push(Opportunities.find({slug: course.slug}).fetch());
      }
    });

    return _.flatten(listOpportunities);
  },

  getOpportunityRecommendations: function () {

    //User tags in an array
    var myTags = Tags.find({users: Meteor.user().profile.name}).map(function (object) {
      return object.slug;
    });

    var TagRecommendations = [];

    //Iterate through user tags and look for courses with the corresponding tag
    _.map(myTags, function (tag) {
      if (Opportunities.find({tags: tag}).count() > 0) {
        TagRecommendations.push(Opportunities.find({tags: tag}).fetch());
      }
    });

    //Don't include the course if it has already been added
    return _.uniq(_.flatten(TagRecommendations), function (event) {
      return event.slug;
    });
  }

});

Template.opportunityAdvisor.events({
  'click .btnOp': function () {
    var id = this._id;
    var semester = $("#semesterInput" + id).val();
    var year = $("#yearInput" + id).val();

    var opportunityInstance = [{user: Meteor.user().profile.name, season: semester, year: year, courseSlug: this.slug, verified: false}];

    var courseCount = $('.'+semester+year).length;

    sweetAlert(
        {title: "Are you sure?",
          text: "This will add the selected opportunity to your plan.",
          type: "warning",   showCancelButton: true,
          confirmButtonColor: "#E34777",
          confirmButtonText: "Add it!",
          closeOnConfirm: true},
        function(isConfirm){
          if(isConfirm) {
            $('body').removeClass('lean-overlay');
            $('.lean-overlay').remove();

            if (courseCount > 0) {
              Meteor.call('addOpportunity', opportunityInstance);

            }

            else{
              Meteor.call('addOpportunity', opportunityInstance);
              Router.go('degreePlanner');
              document.location.reload(true);
            }

          }
        });


  }

});

UI.registerHelper("localizedDateAndTime", function(date) {
  if(date) {
    return moment(date).format('l LT'); // shorthand for localized format "5/23/2014 3:47 PM"
  }
});
