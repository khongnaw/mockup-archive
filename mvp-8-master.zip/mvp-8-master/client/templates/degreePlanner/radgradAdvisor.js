Template.radgradAdvisor.onRendered(function () {
  $('.tooltipped').tooltip();
  $('.collapsible').collapsible({
    accordion: false // A setting that changes the collapsible behavior to expandable instead of the default accordion style
  });
  $('select').material_select();

});

Template.radgradAdvisor.helpers({

  'getAllCourses': function () {

    var allCourses = Courses.find().fetch();

    var coursesAdded = CourseHistory.find({user: Meteor.user().profile.name}).fetch().map(function (object) {
      return object.courseSlug;
    });

    var listCourse = [];

    _.map(allCourses, function(course){
      if(coursesAdded.indexOf(course.slug) < 0 ){
        listCourse.push(Courses.find({slug: course.slug}).fetch());
      }
    });

    return _.flatten(listCourse);
    //return Courses.find();
  },

  getTagRecommendations: function () {

    //User tags in an array
    var myTags = Tags.find({users: Meteor.user().profile.name}).map(function (object) {
      return object.slug;
    });

    var TagRecommendations = [];

    //Iterate through user tags and look for courses with the corresponding tag
    _.map(myTags, function (tag) {
      if (Courses.find({tags: tag}).count() > 0) {
        TagRecommendations.push(Courses.find({tags: tag}).fetch());
      }
    });

    //Don't include the course if it has already been added
    return _.uniq(_.flatten(TagRecommendations), function (event) {
      return event.slug;
    });
  }

});

Template.radgradAdvisor.events({
  'click .btnCo': function () {

    var id = this._id;
    var semester = $("#semesterInput" + id).val();
    var year = $("#yearInput" + id).val();

    var courseCount = $('.'+semester+year).length;

    var courseInstance = [{user: Meteor.user().profile.name, season: semester, year: year, courseSlug: this.slug, verified: false}];

    sweetAlert(
        {title: "Are you sure?",
          text: "This will add the selected course to your plan.",
          type: "warning",   showCancelButton: true,
          confirmButtonColor: "#E34777",
          confirmButtonText: "Add it!",
          closeOnConfirm: true},
        function(isConfirm){
          if(isConfirm) {
            $('body').removeClass('lean-overlay');
            $('.lean-overlay').remove();

            if (courseCount > 0) {
              Meteor.call('addCourse', courseInstance);

            }

            else{
              Meteor.call('addCourse', courseInstance);
              Router.go('degreePlanner');
              document.location.reload(true);
            }

          }
        });
  }

});