/**
 *
 * Created by Josephine on 5/2/16.
 */
Template.CourseList.onRendered(function(){

  $(".owl-carousel").owlCarousel({
    margin:20,
    lazyLoad: true,
    responsive:{
      0:{
        items:1,
        nav:true
      },
      600:{
        items:2,
        nav:true
      },
      1000:{
        items:2,
        nav:true
      }
    }


  });

});

Template.CourseList.helpers({

  listAllSemesters: function(){

    var studentHistory = CourseHistory.find({user: Meteor.user().profile.name}).fetch();

    var groups = _.groupBy(studentHistory, function(value){
      return value.season + value.year;
    });

    return _.chain(_.map(groups, function(group){
      return {
        user: group[0].user,
        season: group[0].season,
        year: group[0].year,
        grade: group[0].grade,
        courses: _.map(_.pluck(group, 'courseSlug'), function(course){
           return Courses.find({slug: course}).fetch();
        }),
        opportunities: _.map(_.pluck(OpportunityHistory.find({user:group[0].user, season: group[0].season, year: group[0].year}).fetch(), 'courseSlug'), function(opportunity){
          return Opportunities.find({slug: opportunity}).fetch();
        })
      };
    })).sortBy('season').reverse().sortBy("year").reverse().value();
  },

  isNotVerified: function(){
    return CourseHistory.find({user:Meteor.user().profile.name , courseSlug: this.slug, verified:false}).count() > 0;
  },

  isNotVerifiedOpp: function(){
    return OpportunityHistory.find({user:Meteor.user().profile.name , courseSlug: this.slug, verified:false}).count() > 0;
  }

});

Template.CourseList.events({

  'click .removeCourse': function() {
    var courseSlug = this.slug;
    var select = $('#'+this._id);
    var season = select.attr("season");
    var year = parseInt(select.attr("year"));
    var name = Meteor.user().profile.name;

    sweetAlert(
        {title: "Are you sure?",
          text: "",
          type: "warning",   showCancelButton: true,
          confirmButtonColor: "#E34777",
          confirmButtonText: "Yes, delete it!",
          closeOnConfirm: true},
        function(isConfirm){
          if(isConfirm) {
            Meteor.call("removeCourse", name, courseSlug, season, year);
            Router.go('degreePlanner');
            document.location.reload(true);
          }
        });
  },

  'click .removeOpportunity': function() {
    var courseSlug = this.slug;
    var select = $('#'+this._id);
    var season = select.attr("season");
    var year = parseInt(select.attr("year"));
    var name = Meteor.user().profile.name;

    sweetAlert(
        {title: "Are you sure?",
          text: "",
          type: "warning",   showCancelButton: true,
          confirmButtonColor: "#E34777",
          confirmButtonText: "Yes, delete it!",
          closeOnConfirm: true},
        function(isConfirm){
          if(isConfirm) {
            Meteor.call("removeOpportunity", name, courseSlug, season, year);
            Router.go('degreePlanner');
            document.location.reload(true);
          }
        });
  }

});