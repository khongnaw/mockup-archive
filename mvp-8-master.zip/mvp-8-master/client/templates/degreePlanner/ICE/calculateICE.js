/**
 *
 * Created by Lithop on 5/4/16.
 */

Template.CalculateICE.helpers({

  'getCompetency': function () {

    var score = 0;
    var myCourseHistory = _.pluck(CourseHistory.find({$and: [{user: Meteor.user().profile.name}, {courseSlug: {$ne: 'othxxx'}}]}).fetch(), 'grade');

    _.each(myCourseHistory, function (item) {
      if (item === 'A')
        score += 4;
      else if (item === 'B')
        score += 3;
      else
        score += 4;
    });
    if (score > 100)
      score = 100;

    return score;
  },

  'getInnovation': function () {

    var score = 0;
    var x = [];
    //get all the verified opportunities associated with user
    var myOpportunities = _.pluck(OpportunityHistory.find({$and: [{user: Meteor.user().profile.name}]}).fetch(), 'courseSlug');

    //iterate through those opportunities and pull out ICE points
    _.each(myOpportunities, function(item){
      // console.log(Opportunities.find({slug: item}).fetch());
      x.push (_.pluck(Opportunities.find({slug: item}).fetch(), 'iceInnovation'));
    });

    //sum up ICE points
    _.each(x, function(item){
      score+= item[0];
    });
    if(score > 100)
      score = 100;

    return score;
  },
  'getExperience': function () {

    var score = 0;
    var x = [];
    //get all the verified opportunities associated with user
    var myOpportunities = _.pluck(OpportunityHistory.find({$and: [{user: Meteor.user().profile.name}]}).fetch(), 'courseSlug');

    //iterate through those opportunities and pull out ICE points
    _.each(myOpportunities, function(item){
      // console.log(Opportunities.find({slug: item}).fetch());
      x.push (_.pluck(Opportunities.find({slug: item}).fetch(), 'iceExperience'));
    });

    //sum up ICE points
    _.each(x, function(item){
      score+= item[0];
    });
    if(score > 100)
      score = 100;

    return score;
  }

});