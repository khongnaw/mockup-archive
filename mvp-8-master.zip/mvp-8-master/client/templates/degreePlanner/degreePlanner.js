/**
 * 
 * Created by mike on 4/12/2016.
 */

$(document).ready(function(){
  // the "href" attribute of .modal-trigger must specify the modal ID that wants to be triggered
  $('.modal-trigger').leanModal();

});

Template.degreePlanner.onRendered(function(){
  $('.modal-trigger').leanModal();

  this.$('ul.tabs').tabs();
  this.$('.collapsible').collapsible();
});