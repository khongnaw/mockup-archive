
Template.LandingEvents.helpers({

  listAllEvents: function(){

    return Opportunities.find({}, {limit:5}).fetch();

  }



});