Template.LandingHeader.onRendered(function(){
  $('.modal-trigger').leanModal();

  $('.slider').slider({
    interval: 6000,
    transition: 300,
    height: 500
  });

  this.$(".button-collapse").sideNav();

});