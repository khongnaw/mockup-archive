/**
 * Created by mike on 4/22/2016.
 */
Template.myTags.onRendered(function(){
  $('.tooltipped').tooltip();

});
Template.myTags.helpers({


  'getUserTags': function () {
   return Tags.find({users: Meteor.user().profile.name});
  },

  'getAllTags': function () {
    return Tags.find();
  },

  'getAllCareerGoals': function () {
    return CareerGoals.find();
  },

});




