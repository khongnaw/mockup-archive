/**
 * Created by mike on 4/22/2016.
 */

Template.careerGoals.onRendered(function(){

  $('.tooltipped').tooltip();

});
Template.careerGoals.helpers({


  'getCareerGoals': function () {
    return CareerGoals.find({users: Meteor.user().profile.name});
  },

  'getAllCareerGoals': function () {
    return CareerGoals.find();
  },

});

