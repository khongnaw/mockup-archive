
Template.HomeOpportunities.helpers({

  /* List events that have a matching interest tag.*/
  listMyEvents: function(){

    //User tags in an array
    var myTags = Tags.find({users: Meteor.user().profile.name}).map(function(object){
      return object.slug;
    });

    var myEvents = [];

    //Iterate through user tags and look for events with the corresponding tag
    _.map(myTags, function(tag){
      if (Opportunities.find({tags: tag}).count() > 0) {
        myEvents.push(Opportunities.find({tags: tag}).fetch());
      }
    });

    //Don't include the event if it has already been added
    return _.uniq(_.flatten(myEvents), function(event){
      return event.slug;
    });
  },

  listAllEvents: function(){

    return Opportunities.find().fetch();

  }

});

Template.HomeOpportunities.onRendered(function(){

  $('.modal-trigger').leanModal({
    dismissible: true, // Modal can be dismissed by clicking outside of the modal
    opacity: .5 // Opacity of modal background
  });
});