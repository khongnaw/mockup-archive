
Template.OpportunitiesTable.helpers({

  listAllEvents: function(){

    return Opportunities;

  },

  settings: function(){
    return{
      collection: Opportunities,
      showFilter: true,
      fields: ['name', 'description']
    };
  }

});