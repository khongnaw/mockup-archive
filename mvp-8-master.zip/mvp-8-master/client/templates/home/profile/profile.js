/**
 *
 * Created by mike on 4/19/2016.
 */
//var cursor = Users.find();


Template.profile.helpers({


  'getUserProfile': function () {
    return Users.find({slug: Meteor.user().profile.name});
  },

  'getImageProfile': function () {
    return Images.find({slug: Meteor.user().profile.name});
  },

  'getGPA': function () {

    var score = 0;
    var divisor = 0;
    var myCourseHistory = _.pluck(CourseHistory.find({$and: [{user: Meteor.user().profile.name}, {verified: true}]}).fetch(), 'grade');

    _.each(myCourseHistory, function (item) {
      divisor++;
      if (item === 'A')
        score += 4;
      else if (item === 'B')
        score += 3;
    });


    return (score/divisor).toFixed(2);
  },
  'getCreditProgress': function () {

    var myCourseHistory = CourseHistory.find({$and: [{user: Meteor.user().profile.name}, {verified: true}]}).fetch();

    return ((myCourseHistory.length*3)/120)*100;
  }

});

