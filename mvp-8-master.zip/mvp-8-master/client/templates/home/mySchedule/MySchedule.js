Template.MySchedule.helpers({

  currentSemester: function(){
    return "Spring 2016";
  },

  currentSchedule:function(){

    var myCourses = CourseHistory.find({user:Meteor.user().profile.name, season: "Spring", year: 16}).map(function(object){
      return object.courseSlug;
    });

    var myClasses = [];


    _.map(myCourses, function(tag){
      if (Courses.find({slug: tag}).count() > 0) {
        myClasses.push(Courses.find({slug: tag}).fetch());
      }
    });

    return _.flatten(myClasses);
  },

  currentOpportunities:function(){

    var myCourses = OpportunityHistory.find({user:Meteor.user().profile.name, season: "Spring", year: 16}).map(function(object){
      return object.courseSlug;
    });

    var myOpportunities = [];


    _.map(myCourses, function(tag){
      if (Opportunities.find({slug: tag}).count() > 0) {
        myOpportunities.push(Opportunities.find({slug: tag}).fetch());
      }
    });

    return _.flatten(myOpportunities);
  }


});


Template.MySchedule.onRendered(function(){

});