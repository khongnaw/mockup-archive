/**
 * Created by mike on 4/12/2016.
 *
 */
Template.home.onRendered(function(){
  this.$('ul.tabs').tabs();
  this.$('.collapsible').collapsible();


});