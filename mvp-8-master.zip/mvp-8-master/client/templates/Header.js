Template.Header.onRendered(function(){
  this.$(".button-collapse").sideNav();
});