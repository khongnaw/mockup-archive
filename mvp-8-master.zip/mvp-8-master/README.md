# MVP 8 RadGrad
by Josephine Garces, Michael Spencer, and Brian Boado under the instruction of Dr. Philip Johnson.

Quick Links
=========================
- [Status](#milestone-4-update-may-5-2016)
- [Functionality](#functions)
 - [Wiki](https://github.com/radgrad/mvp-8/wiki)
- [Task Assignment](#milestone-4-task-assignment)
 - [MVP 8 HuBoard](https://huboard.com/radgrad/mvp-8)
- [MVP 8 Deployed System](http://radgrad-mvp-8.meteorapp.com/) 

About RadGrad
=========================
RadGrad is a system that will help Computer Science and Engineering students plan how they spend their time 
productively and improve their post-graduation outcomes. RadGrad analyzes degree program progress with respect to a student's career goals and helps the student plan courses, as well as academic and extracurricular activities for the current following semesters.

## RadGrad MVP 8 Live

The latest release is live at [radgrad-mvp-8.meteorapp.com](http://radgrad-mvp-8.meteorapp.com/).
 
 
## Milestone 4 Update (May 5, 2016)
* Created backend functions for RadGrad Manager, Projection, and Degree Planner modules for interaction with database.

* Implemented add and removal of Courses and Opportunities to RadGrad Planner.

* Implemented the displaying of the student's course history into the Degree Planner.

* Populated RadGrad Manager with Courses and Opportunities that have yet to be taken by the student or have not been added to the Planner.

* Added ICE points to Opportunities and implemented the calculation algorithms for Innovation, Competency and Experience points.

### Milestone 1 Task Assignment
 * Josephine: Initialized the database schemas for career goals, courses, opportunities, tags, and tag types, as well as loading and cleaning the data from ics-data-model to be compatible. Added CAS authentication and customized the login header template for the landing page. Added side navigation for mobile view.
 
 * Michael: Created static templates for home page and degree planner page. These pages are now ready to add dynamic components with meteor back end.  Also coordinated iron router for pages an enabled compatibility with Materialize Javascript functions.
 
 * Brian: Porting static code from mock-up repository to the Landing page. Currently trying to get the carousel and graphs to appear. 

### Milestone 2 Task Assignment
 * Josephine: Implemented image upload and setup _My Events_ module for User-Specific Opportunities and All Opportunities view (through pop-up modal). Implemented accounts and authentication based on the defined allowedUsers in settings.json file.
 
 * Michael: Implemented Profile module home page; this section now updates user info based on login account.  Created and wrote methods for user collection.
 
 * Brian: Redesign of Landing page. Based on feedback from our Usability test, we removed the graphs and events. Currently condensing the page to have information more appealing. Added a Meet the Team section on footer.

### Milestone 3 Task Assignment

* Josephine: Contributed to significant design changes on the Landing page, which includes removing the carousel, and
 restructuring some parts. Implemented My Events to output events and opportunities based on the user's Interest tags, as well as a pop-up modal with a sortable and filterable catalog of all opportunities. Created schema and seed data 
 for user's course history and implemented My Schedule functionality to take the student's schedule for the current 
 semester.

* Michael:  Modified database seeds for interest tags and career goals.  Implemented tag display on the home page and created a menu for browsing all tags.  The system uses click events to toggle and save user tags.

* Brian: Made adjustments to the landing page, minor changes to the fonts. Was unable to work on the ICE metric design
 for the homepage and fixing the cards on the landing page for this milestone. Had to reset computer and had conflicts
 with other courses. Will move these duties to the next milestone.
 
### Milestone 4 Task Assignment

* Josephine: Created backend functions for Projection and Degree Planner modules for interaction with database. Implemented the displaying of the student's course history into the Degree Planner. Implemented removal of Courses and Opportunities to RadGrad Planner. Made adjustments to backend functions in determining what Courses and Opportunities show up on the Manager. Created ICE Projections on the Degree Planner page. 

* Michael:  Created and implemented the advising interface on the degree planner page.  This module displays recommended opportunities and courses in a list format based on user tags.  Clicking on an item brings up a menu which gives more detailed information about the item and allows the user to add it to their degree plan.  I also updated the profile module on the home page to display GPA and credit completion data.  Finally, I redesigned the module to display ICE points and implemented the calculation algorithms for Innovation, Competency and Experience, and updated opportunity seeds/schemas with ICE.
 
* Brian: Worked on the documentation side of the RadGrad site. Created three separate pages to brifely explain the functionality of each parts for
each page. A screenshot for each part has been added, and will be further explained on the User Guide section of the Wiki.

Current progress and status of MVP-8 RadGrad issues are available on [MVP-8 HuBoard](https://huboard.com/radgrad/mvp-8).


# Quick Start
## Background
Before diving into the application, you may want to familiarize yourself with [Meteor](https://www.meteor.com/).

For more information on the motivation behind this project, please see [RadGrad.org](http://radgrad.org/).

## Basic Usage
* Download the latest version of the application at: https://github.com/radgrad/mvp-8

* Invoke the application for the first time using:

```
meteor --settings ../config/settings.development.json
```
or
```
meteor --settings config\settings.development.json
```

* In production, use

```
meteor --settings ../config/settings.production.json
```

*Note:* The settings file is needed to provide CAS parameter information. Note that you won't be able to successfully login until you edit the settings.development.json file to indicate that your UH account should be one of those allowed to login.


# Functions
User guide and list of functions are available on the [RadGrad Wiki](https://github.com/radgrad/mvp-8/wiki).


## Bugs and Issues

To file an issue, please see [https://github.com/radgrad/mvp-8/issues](https://github.com/radgrad/mvp-8/issues.).

## License
This project is licensed under the [MIT License](https://opensource.org/licenses/MIT). For more information, please visit:
* Quick Summary: https://tldrlegal.com/license/mit-license
* Expanded Summary: https://en.wikipedia.org/wiki/MIT_License
