/*
* Populates User profile with data for testing purposes.
* */

if (Users.find({slug: "jgarces", firstName:{$exists:false}}).count() !== 0) {

  Users.update({slug: "jgarces"}, {
    $set: {
      firstName: "Josephine",
      lastName: "Garces",
      about: "My current academic interests include programming languages - Java, C, and Python - web design, and communications. Besides studying and work, I usually put a lot of my free time towards reading short stories and news articles or finding new ways to make my life easier.",
      gpa: 4.0
    }
  });

}

if (Tags.find({'users': "jgarces"}).count() === 0){
  Tags.update({slug: "game-design"}, {
    $push: {"users": "jgarces"}
  });

  Tags.update({slug: "network-design"}, {
    $push: {"users": "jgarces"}
  });

  Tags.update({slug: "software-engineering"}, {
    $push: {"users": "jgarces"}
  });

  CareerGoals.update({slug: "bs-cs"}, {
    $push: {"users": "jgarces"}
  });
}

if (CourseHistory.find({'user': "jgarces"}).count() === 0){

  var jgarcesData = [
    {user:"jgarces", season: "Fall", year:12, courseSlug: "ics111", verified: true, grade: "A"},
    {user:"jgarces", season: "Fall", year:12, courseSlug: "ics141", verified: true, grade: "A"},
    {user:"jgarces", season: "Fall", year:12, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"jgarces", season: "Fall", year:12, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"jgarces", season: "Fall", year:12, courseSlug: "othxxx", verified: true, grade: "A"},

    {user:"jgarces", season: "Spring", year:13, courseSlug: "ics211", verified: true, grade: "A"},
    {user:"jgarces", season: "Spring", year:13, courseSlug: "ics241", verified: true, grade: "A"},
    {user:"jgarces", season: "Spring", year:13, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"jgarces", season: "Spring", year:13, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"jgarces", season: "Spring", year:13, courseSlug: "othxxx", verified: true, grade: "A"},


    {user:"jgarces", season: "Fall", year:13, courseSlug: "ics211", verified: true, grade: "A"},
    {user:"jgarces", season: "Fall", year:13, courseSlug: "ics311", verified: true, grade: "A"},
    {user:"jgarces", season: "Fall", year:13, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"jgarces", season: "Fall", year:13, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"jgarces", season: "Fall", year:13, courseSlug: "othxxx", verified: true, grade: "A"},


    {user:"jgarces", season: "Spring", year:14, courseSlug: "ics313", verified: true, grade: "A"},
    {user:"jgarces", season: "Spring", year:14, courseSlug: "ics321", verified: true, grade: "A"},
    {user:"jgarces", season: "Spring", year:14, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"jgarces", season: "Spring", year:14, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"jgarces", season: "Spring", year:14, courseSlug: "othxxx", verified: true, grade: "A"},


    {user:"jgarces", season: "Fall", year:14, courseSlug: "ics215", verified: true, grade: "A"},
    {user:"jgarces", season: "Fall", year:14, courseSlug: "ics331", verified: true, grade: "A"},
    {user:"jgarces", season: "Fall", year:14, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"jgarces", season: "Fall", year:14, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"jgarces", season: "Fall", year:14, courseSlug: "othxxx", verified: true, grade: "A"},


    {user:"jgarces", season: "Spring", year:15, courseSlug: "ics451", verified: true, grade: "A"},
    {user:"jgarces", season: "Spring", year:15, courseSlug: "ics455", verified: true, grade: "A"},
    {user:"jgarces", season: "Spring", year:15, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"jgarces", season: "Spring", year:15, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"jgarces", season: "Spring", year:15, courseSlug: "othxxx", verified: true, grade: "A"},


    {user:"jgarces", season: "Fall", year:15, courseSlug: "ics314", verified: true, grade: "A"},
    {user:"jgarces", season: "Fall", year:15, courseSlug: "ics332", verified: true, grade: "A"},
    {user:"jgarces", season: "Fall", year:15, courseSlug: "ics415", verified: true, grade: "A"},
    {user:"jgarces", season: "Fall", year:15, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"jgarces", season: "Fall", year:15, courseSlug: "othxxx", verified: true, grade: "A"},

    {user:"jgarces", season: "Spring", year:16, courseSlug: "ics414", verified: true, grade: "A"},
    {user:"jgarces", season: "Spring", year:16, courseSlug: "ics432", verified: true, grade: "A"},
    {user:"jgarces", season: "Spring", year:16, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"jgarces", season: "Spring", year:16, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"jgarces", season: "Spring", year:16, courseSlug: "othxxx", verified: true, grade: "A"}
  ];

  _.map(jgarcesData, function(data) {
    CourseHistory.insert(data);
  });

}

if (OpportunityHistory.find({'user': "jgarces"}).count() === 0){

  var joOppData = [
    {user:"jgarces", season: "Spring", year:16, courseSlug: "atthack16", verified: true},
    {user:"jgarces", season: "Spring", year:16, courseSlug: "hicapacity", verified: true},
    {user:"jgarces", season: "Fall", year:15, courseSlug: "summer-intern", verified: true},
    {user:"jgarces", season: "Fall", year:15, courseSlug: "student-research-symposium", verified: true}
  ];

  _.map(joOppData, function(data) {
    OpportunityHistory.insert(data);
  });
}




if (Users.find({slug: "michael4", firstName:{$exists:false}}).count() !== 0) {
  Users.update({slug: "michael4"}, {
    $set: {
      firstName: "Michael",
      lastName: "Spencer",
      about: "I am a Computer Engineer",
      gpa: 4.0
    }
  });
}


if (CourseHistory.find({'user': "michael4"}).count() === 0){

  var michaelData = [
    {user:"michael4", season: "Fall", year:12, courseSlug: "ics111", verified: true, grade: "B"},
    {user:"michael4", season: "Fall", year:12, courseSlug: "ics141", verified: true, grade: "B"},
    {user:"michael4", season: "Fall", year:12, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"michael4", season: "Fall", year:12, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"michael4", season: "Fall", year:12, courseSlug: "othxxx", verified: true, grade: "A"},

    {user:"michael4", season: "Spring", year:13, courseSlug: "ics211", verified: true, grade: "B"},
    {user:"michael4", season: "Spring", year:13, courseSlug: "ics241", verified: true, grade: "A"},
    {user:"michael4", season: "Spring", year:13, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"michael4", season: "Spring", year:13, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"michael4", season: "Spring", year:13, courseSlug: "othxxx", verified: true, grade: "A"},


    {user:"michael4", season: "Fall", year:13, courseSlug: "ics211", verified: true, grade: "A"},
    {user:"michael4", season: "Fall", year:13, courseSlug: "ics311", verified: true, grade: "A"},
    {user:"michael4", season: "Fall", year:13, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"michael4", season: "Fall", year:13, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"michael4", season: "Fall", year:13, courseSlug: "othxxx", verified: true, grade: "A"},


    {user:"michael4", season: "Spring", year:14, courseSlug: "ee211", verified: true, grade: "A"},
    {user:"michael4", season: "Spring", year:14, courseSlug: "ee260", verified: true, grade: "A"},
    {user:"michael4", season: "Spring", year:14, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"michael4", season: "Spring", year:14, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"michael4", season: "Spring", year:14, courseSlug: "othxxx", verified: true, grade: "A"},


    {user:"michael4", season: "Fall", year:14, courseSlug: "ee213", verified: true, grade: "A"},
    {user:"michael4", season: "Fall", year:14, courseSlug: "ee361", verified: true, grade: "A"},
    {user:"michael4", season: "Fall", year:14, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"michael4", season: "Fall", year:14, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"michael4", season: "Fall", year:14, courseSlug: "othxxx", verified: true, grade: "A"},


    {user:"michael4", season: "Spring", year:15, courseSlug: "ee315", verified: true, grade: "A"},
    {user:"michael4", season: "Spring", year:15, courseSlug: "ee468", verified: true, grade: "A"},
    {user:"michael4", season: "Spring", year:15, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"michael4", season: "Spring", year:15, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"michael4", season: "Spring", year:15, courseSlug: "othxxx", verified: true, grade: "A"},


    {user:"michael4", season: "Fall", year:15, courseSlug: "ics314", verified: true, grade: "A"},
    {user:"michael4", season: "Fall", year:15, courseSlug: "ics332", verified: true, grade: "A"},
    {user:"michael4", season: "Fall", year:15, courseSlug: "ics415", verified: true, grade: "A"},
    {user:"michael4", season: "Fall", year:15, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"michael4", season: "Fall", year:15, courseSlug: "othxxx", verified: true, grade: "A"},

    {user:"michael4", season: "Spring", year:16, courseSlug: "ics414", verified: true, grade: "A"},
    {user:"michael4", season: "Spring", year:16, courseSlug: "ee323", verified: true, grade: "A"},
    {user:"michael4", season: "Spring", year:16, courseSlug: "ee342", verified: true, grade: "A"},
    {user:"michael4", season: "Spring", year:16, courseSlug: "ee371", verified: true, grade: "A"}
  ];

  _.map(michaelData, function(data) {
    CourseHistory.insert(data);
  });
}
if (OpportunityHistory.find({'user': "michael4"}).count() === 0){

  var michaelOppData = [
    {user:"michael4", season: "Fall", year:12, courseSlug: "atthack16", verified: true},
    {user:"michael4", season: "Fall", year:12, courseSlug: "hicapacity", verified: true},
    {user:"michael4", season: "Fall", year:12, courseSlug: "summer-intern", verified: true},
    {user:"michael4", season: "Fall", year:12, courseSlug: "student-research-symposium", verified: true}

  ];

  _.map(michaelOppData, function(data) {
    OpportunityHistory.insert(data);
  });
}



if (Tags.find({'users': "michael4"}).count() === 0){

  Tags.update({slug: "nursing"}, {
    $push: {"users": "michael4"}
  });


  CareerGoals.update({slug: "bs-cs"}, {
    $push: {"users": "michael4"}
  });

  CareerGoals.update({slug: "game-designer"}, {
    $push: {"users": "michael4"}
  });

}


if (Users.find({slug: "bjboado", firstName:{$exists:false}}).count() !== 0) {
  Users.update({slug: "bjboado"}, {
    $set: {
      firstName: "Brian",
      lastName: "Boado",
      about: "I am a Software Developer",
      gpa: 4.0
    }
  });
}

if (Tags.find({'users': "bjboado"}).count() === 0) {

  CareerGoals.update({slug: "bs-cs"}, {
    $push: {"users": "bjboado"}
  });

}

if (CourseHistory.find({'user': "bjboado"}).count() === 0){

  var bjboadoData = [
    {user:"bjboado", season: "Fall", year:12, courseSlug: "ics111", verified: true, grade: "A"},
    {user:"bjboado", season: "Fall", year:12, courseSlug: "ics141", verified: true, grade: "A"},
    {user:"bjboado", season: "Fall", year:12, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"bjboado", season: "Fall", year:12, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"bjboado", season: "Fall", year:12, courseSlug: "othxxx", verified: true, grade: "A"},

    {user:"bjboado", season: "Spring", year:13, courseSlug: "ics211", verified: true, grade: "A"},
    {user:"bjboado", season: "Spring", year:13, courseSlug: "ics241", verified: true, grade: "A"},
    {user:"bjboado", season: "Spring", year:13, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"bjboado", season: "Spring", year:13, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"bjboado", season: "Spring", year:13, courseSlug: "othxxx", verified: true, grade: "A"},


    {user:"bjboado", season: "Fall", year:13, courseSlug: "ics211", verified: true, grade: "A"},
    {user:"bjboado", season: "Fall", year:13, courseSlug: "ics311", verified: true, grade: "A"},
    {user:"bjboado", season: "Fall", year:13, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"bjboado", season: "Fall", year:13, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"bjboado", season: "Fall", year:13, courseSlug: "othxxx", verified: true, grade: "A"},


    {user:"bjboado", season: "Spring", year:14, courseSlug: "ics313", verified: true, grade: "A"},
    {user:"bjboado", season: "Spring", year:14, courseSlug: "ics321", verified: true, grade: "A"},
    {user:"bjboado", season: "Spring", year:14, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"bjboado", season: "Spring", year:14, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"bjboado", season: "Spring", year:14, courseSlug: "othxxx", verified: true, grade: "A"},


    {user:"bjboado", season: "Fall", year:14, courseSlug: "ics215", verified: true, grade: "A"},
    {user:"bjboado", season: "Fall", year:14, courseSlug: "ics331", verified: true, grade: "A"},
    {user:"bjboado", season: "Fall", year:14, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"bjboado", season: "Fall", year:14, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"bjboado", season: "Fall", year:14, courseSlug: "othxxx", verified: true, grade: "A"},


    {user:"bjboado", season: "Spring", year:15, courseSlug: "ics451", verified: true, grade: "A"},
    {user:"bjboado", season: "Spring", year:15, courseSlug: "ics455", verified: true, grade: "A"},
    {user:"bjboado", season: "Spring", year:15, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"bjboado", season: "Spring", year:15, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"bjboado", season: "Spring", year:15, courseSlug: "othxxx", verified: true, grade: "A"},


    {user:"bjboado", season: "Fall", year:15, courseSlug: "ics314", verified: true, grade: "A"},
    {user:"bjboado", season: "Fall", year:15, courseSlug: "ics332", verified: true, grade: "A"},
    {user:"bjboado", season: "Fall", year:15, courseSlug: "ics415", verified: true, grade: "A"},
    {user:"bjboado", season: "Fall", year:15, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"bjboado", season: "Fall", year:15, courseSlug: "othxxx", verified: true, grade: "A"},

    {user:"bjboado", season: "Spring", year:16, courseSlug: "ics414", verified: true, grade: "A"},
    {user:"bjboado", season: "Spring", year:16, courseSlug: "ics432", verified: true, grade: "A"},
    {user:"bjboado", season: "Spring", year:16, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"bjboado", season: "Spring", year:16, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"bjboado", season: "Spring", year:16, courseSlug: "othxxx", verified: true, grade: "A"}
  ];

  _.map(bjboadoData, function(data) {
    CourseHistory.insert(data);
  });
}

