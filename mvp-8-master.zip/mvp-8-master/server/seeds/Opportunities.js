/**
 * Opportunities Seed
 * Created by Josephine on 4/13/2016
 * */

var opportunitiesSeed = [
  {
    name: "College of Engineering (COE) Student Research Symposium",
    slug: "student-research-symposium",
    description: "Provides undergraduate engineering students the opportunity to present their scholarly works in a friendly yet professional setting similar to national and international conferences. ",
    opportunityType: "event",
    sponsor: "philipjohnson",
    tags: ["electrical-engineering"],
    icon:"http://puu.sh/owIaf/cd44ad4d17.png",
    startActive: moment("2015-10-10").toDate(),
    endActive: moment("2016-04-20").toDate(),
    iceExperience: 0,
    iceInnovation: 10
  },
  {
    name: "Summer Intern - Survey",
    slug: "summer-intern",
    description: "Hawaiian Electric Engineering Summer Internships offer students an opportunity to gain real life survey experience working on professional level projects and 'hands-on' challenges.  Interns are coached and mentored by employees who are committed to helping the interns develop their technical skills and explore future professional opportunities. ",
    opportunityType: "internship",
    sponsor: "philipjohnson",
    icon: "http://files.www.aroundcampusgroup.com/student-internships/customer-relations-internship/cr-internship.png",
    tags: ["electrical-engineering"],
    startActive: moment("2016-01-01").toDate(),
    endActive: moment("2016-01-29").toDate(),
    iceExperience: 30,
    iceInnovation: 5
  },
  {
    name: "Software Engineering Internships @ Qualcomm (Summer 2016)",
    slug: "qualcomm",
    description: "Headquartered in San Diego, Qualcomm develops, manufactures, markets, licenses, and operates advanced 4G & 3G communications systems and products based on its proprietary digital wireless technologies. ",
    opportunityType: "internship",
    sponsor: "philipjohnson",
    icon: "http://files.www.aroundcampusgroup.com/student-internships/customer-relations-internship/cr-internship.png",
    tags: ["electrical-engineering", "software-engineering"],
    startActive: moment("2015-12-04").toDate(),
    endActive: moment("2016-03-01").toDate(),
    iceExperience: 30,
    iceInnovation: 5
  },
  {
    name: "4 month Intern Engineer opportunities at Qualcomm Research Center Vienna, Austria",
    slug: "qualcomm-research-center-vienna",
    description: "Join our Corporate R&D team in Vienna, Austria and interact closely with system engineers and software developers in a world-class Computer Vision team. ",
    opportunityType: "internship",
    sponsor: "philipjohnson",
    icon: "http://files.www.aroundcampusgroup.com/student-internships/customer-relations-internship/cr-internship.png",
    tags: ["electrical-engineering", "software-engineering"],
    startActive: moment("2016-01-12").toDate(),
    endActive: moment("2016-03-10").toDate(),
    iceExperience: 30,
    iceInnovation: 5
  },
  {
    name: "National Student Exchange",
    slug: "national-student-exchange",
    description: "A study away experience that fits into university initiatives for globalization, diversity and engagement. NSE participants have found their exchanges culturally enriching, academically rewarding, and one of the most significant experiences of their undergraduate education.",
    opportunityType: "club",
    sponsor: "philipjohnson",
    icon:"http://discoverycrc.com/wp-content/uploads/2014/09/Community-Icon.png",
    tags: ["electrical-engineering", "software-engineering"],
    startActive: moment("2016-01-11").toDate(),
    endActive: moment("2016-05-13").toDate(),
    iceExperience: 0,
    iceInnovation: 10
  },

  {
    name: "Data Science Specialization",
    slug: "data-science-specialization",
    description: "This Specialization covers the concepts and tools you'll need throughout the entire data science pipeline, from asking the right kinds of questions to making inferences and publishing results. In the final Capstone Project, you'll apply the skills learned by building a data product using real-world data. At completion, students will have a portfolio demonstrating their mastery of the material. ",
    opportunityType: "cloud-ed",
    sponsor: "philipjohnson",
    icon: "http://www.teamsoftware.com/assets/uploads/2016/01/Cloud-Icon-01.png",
    tags: ["data-science", "r", "machine-learning"],
    startActive: moment("2016-01-01").toDate(),
    endActive: moment("2016-01-17").toDate(),
    iceExperience: 0,
    iceInnovation: 10
  },
  {
    name: "Shidler Business Plan Competition 2016",
    slug: "business-plan-competition2016",
    description: "Form teams and compete to come up with the best business plan. Substantial cash prizes for highest scoring teams. Teams that reach the semi-final round will gain access to mentors who can advise during the business plan process and business pitch preparation. ",
    opportunityType: "event",
    sponsor: "philipjohnson",
    tags: ["business"],
    icon: "https://cdn3.iconfinder.com/data/icons/illustricon-tech/512/development.desktop-512.png",
    startActive: moment("2016-01-17").toDate(),
    endActive: moment("2016-01-31").toDate(),
    iceExperience: 10,
    iceInnovation: 10
  },

  {
    name: "ASECOLab",
    slug: "aseco-lab",
    description: "We study how security is achieved through adaptation, and how fortifications give an illusion of security. This has to do with economics, but also with cryptography. ",
    opportunityType: "research",
    sponsor: "philipjohnson",
    icon: "http://kiskash.com/wp-content/uploads/2015/12/research-icon.png",
    tags: ["computer-security", "economics", "cryptography"],
    startActive: moment("2016-01-11").toDate(),
    endActive: moment("2016-12-31").toDate(),
    iceExperience: 0,
    iceInnovation: 10
  },
  {
    name: "Bioinformatics Laboratory",
    slug: "bil-lab",
    description: "The main research projects at BiL Manoa are Bioinformatics and Computational Biology. ",
    opportunityType: "research",
    sponsor: "philipjohnson",
    icon: "http://kiskash.com/wp-content/uploads/2015/12/research-icon.png",
    tags: ["bioinformatics", "biology", "hawaii"],
    startActive: moment("2016-01-02").toDate(),
    endActive: moment("2016-01-03").toDate(),
    iceExperience: 0,
    iceInnovation: 15
  },
  {
    name: "Collaborative Software Development Laboratory",
    slug: "csdl",
    description: "Our goal is to support collaborative development of world-class software development skills.   Through research, education, and technology transfer, we pursue this goal for CSDL members, the University of Hawaii, our affiliates, and the Hawaiian, U.S., and international software research and development communities.  ",
    opportunityType: "research",
    sponsor: "philipjohnson",
    icon: "http://kiskash.com/wp-content/uploads/2015/12/research-icon.png",
    tags: ["education", "software-engineering", "electrical-engineering"],
    startActive: moment("2016-01-11").toDate(),
    endActive: moment("2016-12-31").toDate(),
    iceExperience: 0,
    iceInnovation: 15
  },
  {
    name: "Concurrency Research Group",
    slug: "corg",
    description: "CoRG researchers develop novel simulation models, algorithms, and systems for parallel and distributed computing platforms and applications. We study platforms including single clusters, grids that aggregate multiple high-end clusters across different institutions, and even thousands of volatile PCs scattered over the Internet.  ",
    opportunityType: "research",
    sponsor: "philipjohnson",
    icon: "http://kiskash.com/wp-content/uploads/2015/12/research-icon.png",
    tags: ["algorithms", "parallel-programming", "distributed-computing"],
    startActive: moment("2016-01-11").toDate(),
    endActive: moment("2016-12-31").toDate(),
    iceExperience: 0,
    iceInnovation: 20
  },
  {
    name: "Hawaii Computer-Human Interaction Lab",
    slug: "hichi",
    description: "We are an interdisciplinary team of researchers interested in understanding how people use information systems and dedicated to informing design based on human performance data.  ",
    opportunityType: "research",
    sponsor: "philipjohnson",
    icon: "http://kiskash.com/wp-content/uploads/2015/12/research-icon.png",
    tags: ["human-computer-interaction", "cognitive-science", "engineering"],
    startActive: moment("2016-05-20").toDate(),
    endActive: moment("2016-07-20").toDate(),
    iceExperience: 0,
    iceInnovation: 10
  },

  {
    name: "HICapacity",
    slug: "hicapacity",
    description: "At HI Capacity, we focus on providing education and raising the awareness of all these topics in the local community.  If you are passionate about a subject and would love to help organize a Community Night, we are always looking for you. ",
    opportunityType: "club",
    sponsor: "philipjohnson",
    icon:"http://discoverycrc.com/wp-content/uploads/2014/09/Community-Icon.png",
    tags: ["engineering", "software-engineering", "computer-engineering"],
    startActive: moment("2016-01-11").toDate(),
    endActive: moment("2016-12-31").toDate(),
    iceExperience: 30,
    iceInnovation: 0
  },
  {
    name: "ATT Hackathon 2016",
    slug: "atthack16",
    description: "Come turn your ideas into apps and put your coding skills to the test.  Compete for cash and prices as you work with other developers and industry experts to fast-build an app from scratch in 24 hours. ",
    opportunityType: "event",
    sponsor: "philipjohnson",
    icon: "https://cdn3.iconfinder.com/data/icons/illustricon-tech/512/development.desktop-512.png",
    tags: ["computer-engineering", "software-engineering"],
    startActive: moment("2016-01-02").toDate(),
    endActive: moment("2016-01-03").toDate(),
    iceExperience: 0,
    iceInnovation: 10
  },
  {
    name: "ACM Manoa",
    slug: "acm-manoa",
    description: "ACM is the world's largest education and scientific computing society.  It delivers resrouces that advance computing as a science and a profession.  ACM provides the computing field's premier Digital Library and serves its members and the computing profession with leading-edge publications, conferences, and career resources.  ",
    opportunityType: "club",
    sponsor: "philipjohnson",
    icon:"http://discoverycrc.com/wp-content/uploads/2014/09/Community-Icon.png",
    tags: ["computer-engineering", "software-engineering"],
    startActive: moment("2016-01-11").toDate(),
    endActive: moment("2016-12-31").toDate(),
    iceExperience: 15,
    iceInnovation: 15
  },
  {
    name: "IEEE Student Chapter",
    slug: "ieee-manoa",
    description: "IEEE is a non-profit, technical professional association of more than 380,000 individual members in 150 countries.  IEEE is the largest professional organization in the world.  Through its members, IEEE is a leading authority in technical areas ranging from computer engineering, biomedical technology, electric power, telecommunications, aerospace and consumer electronics.  ",
    opportunityType: "club",
    sponsor: "philipjohnson",
    icon:"http://developer.amd.com/wordpress/media/2013/03/library_ieee1.png",
    tags: ["computer-engineering", "electrical-engineering", "software-engineering"],
    startActive: moment("2016-01-11").toDate(),
    endActive: moment("2016-12-31").toDate(),
    iceExperience: 10,
    iceInnovation: 10
  },
  {
    name: "ITMA Student Chapter",
    slug: "itma-manoa",
    description: "The Information Technology Management Association (ITMA) is a business club motivated and dedicated to provide its members social and professional relationships, provide access to technical resources, and be an example of a growing technical environment to foster career development. The Purposes of the Information Technology Management Association are to provide a better understanding of the nature and functions of information systems and related areas. Prepare its members for a career in information technology. Proliferate interaction between members and the business community. ",
    opportunityType: "club",
    sponsor: "philipjohnson",
    icon:"http://discoverycrc.com/wp-content/uploads/2014/09/Community-Icon.png",
    tags: ["business", "finance", "it"],
    startActive: moment("2016-01-11").toDate(),
    endActive: moment("2016-12-31").toDate(),
    iceExperience: 10,
    iceInnovation: 10
  },
  {
    name: "LiveAction internship",
    slug: "liveaction-internship",
    description: "LiveAction was originally founded as ActionPacked Networks to aid the US Department of Defense in the operation of its networks.  LiveAction Software was created including an innovative visual display, real-time big data analytics for decision-making and deep integration with routers and switches for unparalleled network control.  ",
    opportunityType: "internship",
    sponsor: "philipjohnson",
    icon: "http://files.www.aroundcampusgroup.com/student-internships/customer-relations-internship/cr-internship.png",
    tags: ["hawaii", "silicon-valley", "network-design", "computer-engineering", "software-engineering"],
    startActive: moment("2016-05-20").toDate(),
    endActive: moment("2016-07-20").toDate(),
    iceExperience: 30,
    iceInnovation: 0
  },
  {
    name: "Global Game Jam",
    slug: "global-game-jam",
    description: "The Global Game Jam (GGJ) is the world's largest game jam event (game creation) taking place around the world at physical locations. At each site, participants gather to develop ideas, form small groups, create new, creative, innovative games, and present them to their peers and the global community, all in a limited time span.  ",
    opportunityType: "event",
    sponsor: "philipjohnson",
    icon: "https://cdn3.iconfinder.com/data/icons/illustricon-tech/512/development.desktop-512.png",
    tags: ["game-design"],
    startActive: moment("2016-01-29").toDate(),
    endActive: moment("2016-01-31").toDate(),
    iceExperience: 0,
    iceInnovation: 10  }
];


if (Opportunities.find().count() === 0){
  _.each(opportunitiesSeed, function(opportunities){
    Opportunities.insert(opportunities);
  });

}
