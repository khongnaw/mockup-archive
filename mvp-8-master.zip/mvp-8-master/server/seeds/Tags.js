/**
 * Tags Seed
 * Created by Josephine on 4/13/16
 */

var tagsSeed = [

  {
    name: "Computer Graphics",
    slug: "computer-graphics",
    description: "The set of technologies used to create art with computers. ",
    tagType: "cs-disciplines"
  },
  {
    name: "Computer Vision",
    slug: "computer-vision",
    description: "A field that includes methods for acquiring, processing, analyzing, and understanding images and, in general, high-dimensional data from the real world in order to produce numerical or symbolic information.  ",
    tagType: "cs-disciplines"
  },
  {
    name: "Data Visualization",
    slug: "data-visualization",
    description: "Communicates information clearly and efficiently to users via the statistical graphics, plots, information graphics, tables, and charts selected. Effective visualization helps users in analyzing and reasoning about data and evidence.  ",
    tagType: "cs-disciplines"
  },
  {
    name: "Circuit Design",
    slug: "circuit-design",
    description: "A graphic representation of an electric circuit in which actual circuit components are represented by standard symbols.  ",
    tagType: "cs-disciplines"
  },
  /* TECHNOLOGIES */
  {
    name: "Objective-C",
    slug: "objective-c",
    description: "The primary programming language you use when writing software for OS X and iOS.  It’s a superset of the C programming language and provides object-oriented capabilities and a dynamic runtime.  ",
    tagType: "technologies"
  },
  {
    name: "Node",
    slug: "node",
    description: "As an asynchronous event driven framework, Node.js is designed to build scalable network applications.  ",
    tagType: "technologies"
  },
  {
    name: "Angular",
    slug: "angular",
    description: "A structural framework for dynamic web apps. It lets you use HTML as your template language and lets you extend HTML's syntax to express your application's components clearly and briefly.  ",
    tagType: "technologies"
  },
  {
    name: "Django",
    slug: "django",
    description: "is a free and open source web application framework, written in Python. A web framework is a set of components that helps you to develop websites faster and easier.  ",
    tagType: "technologies"
  },
  {
    name: "OS/X",
    slug: "osx",
    description: "OS X is the operating system that powers every Mac. Built on a rock-solid UNIX foundation, it’s engineered to take full advantage of what the hardware is capable of.  ",
    tagType: "technologies"
  },
  /* LOCATIONS */
  {
    name: "Mexico",
    slug: "mexico",
    description: "A country between the U.S. and Central America that's known for its Pacific and Gulf of Mexico beaches and its diverse landscape of mountains, deserts and jungles.  ",
    tagType: "locations"
  },
  {
    name: "Central America",
    slug: "central-america",
    description: "The southernmost, isthmian portion of the North American continent, which connects with South America on the southeast.  ",
    tagType: "locations"
  },

  {
    name: "Algorithms",
    slug: "algorithms",
    description: "A concentration on computer science, it is a self-contained step-by-step set of operations to be performed. Algorithms exist that perform calculation, data processing, and automated reasoning. ",
    tagType: "cs-disciplines"
  },
  {
    name: "System Programming",
    slug: "system-programming",
    description: "The activity of programming computer system software. ",
    tagType: "cs-disciplines"
  },
  {
    name: "Web Design",
    slug: "web-design",
    description: "Encompasses many different skills and disciplines in the production and maintenance of websites. ",
    tagType: "cs-disciplines"
  },
  {
    name: "Database",
    slug: "database",
    description: "Database is an organized collection of data. It is the collection of schemas, tables, queries, reports, views and other objects. ",
    tagType: "cs-disciplines"
  },

  /* NON-CS DISCIPLINES */
  {
    name: "Meteorology",
    slug: "meteorology",
    description: "The interdisciplinary scientific study of the atmosphere. ",
    tagType: "non-cs-disciplines"
  },
  {
    name: "Music",
    slug: "music",
    description: "The study of an art form and cultural activity whose medium is sound and silence.. ",
    tagType: "non-cs-disciplines"
  },
  {
    name: "Natural Resources",
    slug: "natural-resources",
    description: "The study of resources and supplies that originate from Earth. ",
    tagType: "non-cs-disciplines"
  },
  {
    name: "Nursing",
    slug: "nursing",
    description: "The study of care of individuals, families, and communities so they may attain, maintain, or recover optimal health and quality of life. ",
    tagType: "non-cs-disciplines"
  },
  {
    name: "Oceanography",
    slug: "oceanography",
    description: "The study of Earth science that studies the ocean. ",
    tagType: "non-cs-disciplines"
  },
  {
    name: "Ilokano",
    slug: "ilokano",
    description: "The study of the language of the Northern region of the Philippines. ",
    tagType: "non-cs-disciplines"
  },
  /* TECHNOLOGIES */
  {
    name: "ElasticSearch",
    slug: "elasticsearch",
    description: "Designed to take data from any source and search, analyze, and visualize it in real time. ",
    tagType: "technologies"
  },
  {
    name: "Bootstrap",
    slug: "bootstrap",
    description: "An HTML, CSS, and JS framework for developing responsive, mobile first projects on the web. ",
    tagType: "technologies"
  },
  {
    name: "Eclipse",
    slug: "eclipse",
    description: "Known for Java IDE, C/C++, JavaScript and PHP IDEs built on extensible platforms for creating desktop, Web and cloud IDEs. ",
    tagType: "technologies"
  },
  {
    name: "Atom",
    slug: "atom",
    description: "A text editor that's modern, approachable, yet hackable to the core—a tool you can customize to do anything but also use productively without ever touching a config file.  ",
    tagType: "technologies"
  },
  {
    name: "JUnit",
    slug: "junit",
    description: "A simple framework to write repeatable tests. It is an instance of the xUnit architecture for unit testing frameworks..  ",
    tagType: "technologies"
  },

  {
    name: "Business",
    slug: "business",
    description: "A business, also known as an enterprise, agency, or a firm, is an entity involved in the provision of goods, services, or both to consumers. ",
    tagType: "non-cs-disciplines"
  },
  {
    name: "Chemistry",
    slug: "chemistry",
    description: "Chemistry is a branch of physical science that studies the composition, structure, properties and change of matter.  ",
    tagType: "non-cs-disciplines"
  },
  {
    name: "Foreign Languages",
    slug: "foreign-languages",
    description: "A foreign language is a language indigenous to another country. It is also a language not spoken in the native country of the person referred to.  ",
    tagType: "non-cs-disciplines"
  },
  {
    name: "Communications",
    slug: "communications",
    description: "Communication is the purposeful activity of information exchange between two or more participants in order to convey or receive the intended meanings through a shared system of signs and semiotic rules.  ",
    tagType: "non-cs-disciplines"
  },
  {
    name: "Dance",
    slug: "dance",
    description: "Dance is a performance art form consisting of purposefully selected sequences of human movement.  ",
    tagType: "non-cs-disciplines"
  },
  {
    name: "Computer Ethics",
    slug: "computer-ethics",
    description: "Computer Ethics is a part of practical philosophy which concern with how computing professionals should make decisions regarding professional and social conduct.  ",
    tagType: "non-cs-disciplines"
  },
  {
    name: "Engineering Ethics",
    slug: "engineering-ethics",
    description: "Engineering ethics is the field of applied ethics and system of moral principles that apply to the practice of engineering. The field examines and sets the obligations by engineers to society, to their clients, and to the profession.  ",
    tagType: "non-cs-disciplines"
  },

  /* TECHNOLOGIES */
  {
    name: "Postgres",
    slug: "postgres",
    description: "PostgreSQL is a powerful, open source object-relational database system.  ",
    tagType: "technologies"
  },
  {
    name: "Ruby",
    slug: "ruby",
    description: "Ruby is a dynamic, open source programming language with a focus on simplicity and productivity. It has an elegant syntax that is natural to read and easy to write.  ",
    tagType: "technologies"
  },
  {
    name: "Rails",
    slug: "rails",
    description: "Ruby on Rails is an open-source web framework that's optimized for programmer happiness and sustainable productivity. It lets you write beautiful code by favoring convention over configuration.  ",
    tagType: "technologies"
  },
  {
    name: "CSS",
    slug: "css",
    description: "Cascading Style Sheets (CSS) is a style sheet language used for describing the presentation of a document written in a markup language.  ",
    tagType: "technologies"
  },
  {
    name: "Docker",
    slug: "docker",
    description: "An open platform for distributed applications for developers and sysadmins.  ",
    tagType: "technologies"
  },
  {
    name: "Common Lisp",
    slug: "common-lisp",
    description: "Common Lisp is the modern, multi-paradigm, high-performance, compiled, ANSI-standardized, most prominent descendant of the long-running family of Lisp programming languages.  ",
    tagType: "technologies"
  },
  {
    name: "Scheme",
    slug: "scheme",
    description: "Scheme is a principal dialect of the computer programming language Lisp. It follows a minimalist design philosophy that specifies a small standard core accompanied by powerful tools for language extension.  ",
    tagType: "technologies"
  },
  {
    name: "Prolog",
    slug: "prolog",
    description: "Prolog is a general purpose logic programming language associated with artificial intelligence and computational linguistics.  It has its roots in first-order logic, a formal logic, and is declarative: the program logic is expressed in terms of relations, represented as facts and rules.  ",
    tagType: "technologies"
  },
  {
    name: "Cryptography",
    slug: "cryptography",
    description: "The practice and study of techniques for secure communication. ",
    tagType: "cs-disciplines"
  },
  {
    name: "Artificial intelligence",
    slug: "artificial-intelligence",
    description: "The study of how to create computer software that are capable of intelligent behavior.  ",
    tagType: "cs-disciplines"
  },
  {
    name: "Data science",
    slug: "data-science",
    description: "The interdisciplinary field about processes and systems to extract knowledge or insights from data in various forms.  ",
    tagType: "cs-disciplines"
  },
  {
    name: "Computer architecture",
    slug: "computer-architecture",
    description: "A set of rules and methods that describe the functionality, organization and implementation of computer systems.  ",
    tagType: "cs-disciplines"
  },
  {
    name: "Parallel programming",
    slug: "parallel-programming",
    description: "A type of computation in which many calculations are carried out simultaneously.  ",
    tagType: "cs-disciplines"
  },
  // Non ICS discipline
  {
    name: "Theater",
    slug: "theater",
    description: "A collaborative form of fine art that uses live performers to present the experience to the audience.  ",
    tagType: "non-cs-disciplines"
  },
  {
    name: "Travel Industry Management",
    slug: "travel-industry",
    description: "Hospitality management and tourism transportation management.  ",
    tagType: "non-cs-disciplines"
  },
  {
    name: "Urban and Regional Planning",
    slug: "urban-reg-planning",
    description: "A technical and political process concerned with the use of land, protection and use of the environment, public welfare, and the design of the urban environment.  ",
    tagType: "non-cs-disciplines"
  },
  {
    name: "Women's Studies",
    slug: "women-studies",
    description: "An interdisciplinary field of academic study that examines gender as a social and cultural construct.  ",
    tagType: "technologies"
  },
  /* LOCATIONS */
  {
    name: "Hawaii",
    slug: "hawaii",
    description: "The 50th U.S. state located in Oceania.  ",
    tagType: "locations"
  },
  {
    name: "Silicon Valley",
    slug: "silicon-valley",
    description: "A nickname for the southern portion of the San Francisco Bay Area. Home to the world's largest high-tech corporations.  ",
    tagType: "locations"
  },
  {
    name: "Western US",
    slug: "west-us",
    description: "The westernmost portion of the North American continent.  ",
    tagType: "locations"
  },
  {
    name: "Eastern US",
    slug: "east-us",
    description: "The easternmost portion of the North American continent.  ",
    tagType: "locations"
  },
  {
    name: "Southern US",
    slug: "south-us",
    description: "The southernmost portion of the North American continent.  ",
    tagType: "locations"
  },

  {
    name: "High Performance Programming",
    slug: "high-performance-programming",
    description: "Programming associated with high performance computing (HPC). Programming for HPCs requires the use of special programming techniques to take advantage of their parallel archietecture. ",
    tagType: "cs-disciplines"
  },
  {
    name: "Machine Learning",
    slug: "machine-learning",
    description: "Machine learning is a subfield of computer science that explores the use of algorithms which can be used to make data-driven predictions or decisions. ",
    tagType: "cs-disciplines"
  },
  {
    name: "Theory Of Computation",
    slug: "theory-of-computation",
    description: "Theory of computation is a branch of theoretical computer science and mathematics that deals with how efficiently problems can be solved using computational algorithms. It is divided up into three additional branches - automa theory and language, computability theory and computational complexity theory. ",
    tagType: "cs-disciplines"
  },
  {
    name: "Robotics",
    slug: "robotics",
    description: "Robotics is a branch of engineering that deals with the design, construction and application of robots as well as their associated computer systems. Robotics encompasses several fields including mechanical engineering, elecrical engineering, electronic engineering and computer science. ",
    tagType: "cs-disciplines"
  },
  {
    name: "Game Design",
    slug: "game-design",
    description: "Game design is the application of design and asthetics to create a game. ",
    tagType: "cs-disciplines"
  },
  {
    name: "Midwestern US",
    slug: "midwestern-us",
    description: "Also known as the Midwest, the Midwestern US is one of four major geographical regions in the United States encompassing 12 states. It includes: Illinois, Indiana, Iowa, Kansas, Michigan, Minnesota, Missouri, Nebraska, North Dakota, Ohio, South Dakota, and Wisconsin. ",
    tagType: "locations"
  },
  {
    name: "Japan",
    slug: "japan",
    description: "Japan is an country located in East Asia and in the Pacific Ocean made up of 6852 individual islands and a population of over 126 million. Japan also has the world's third largest economy by nominal GDP. ",
    tagType: "locations"
  },
  {
    name: "China",
    slug: "china",
    description: "Officially called The People's Republic of China (PRC), China is the world's most populous country and is located in East Asia. It is home to over 1.35 billion people and has become of the world's fastest growing economies. ",
    tagType: "locations"
  },
  {
    name: "Asia",
    slug: "asia",
    description: "Asia is the Earth's largest and most populous continent, comprising of 30% of Earth's land area as well as 60% of the human population. Asia is home to unusually dense and large settlements and is home to some of the world's most rapidly growing economies such as China and India. ",
    tagType: "locations"
  },
  {
    name: "India",
    slug: "india",
    description: "The Republic of India is a country in South Asia and is the second-most populous country in the world with over 1.2 billion people. India is one of the fastest growing major economies in the world. ",
    tagType: "locations"
  },
  {
    name: "Java",
    slug: "java",
    description: "Java is a general-purpose, class-based and object-oriented programming language that was released by Sun Microsystems in 1995. As of 2015, it is one of the most popular programming languages in use, with a reported 9 million developers using it. ",
    tagType: "technologies"
  },
  {
    name: "Spring",
    slug: "spring",
    description: "Spring is a framework that provides a model for the programming and configuration of Java-based enterprise applications. It focuses on the 'plumbing' aspect of enterprise applications, allowing developers to focus on higher, application-level business logic. ",
    tagType: "technologies"
  },
  {
    name: "Hibernate",
    slug: "hibernate",
    description: "Hibernate, or more properly known as Hibernate ORM, is an Object/Relational Mapping framework which provides useful features in building data-persistant applications. ",
    tagType: "technologies"
  },
  {
    name: "RDBMS",
    slug: "rdbms",
    description: "A RDBMS or Relational Database Managment System refers to a specific type of database management system that uses a relational model for data storage. Example of RDBMSs include MySQL, Microsoft SQL Server and Oracle Database. ",
    tagType: "technologies"
  },
  {
    name: "Calculus",
    slug: "calculus",
    description: "Calculus is the mathematical study of change, in the same way that geometry is the study of shape and algebra is the study of operations and their application to solving equations. ",
    tagType: "cs-disciplines"
  },
  {
    name: "Javascript",
    slug: "javascript",
    description: "Javascript is a high-level programming language based on the ECMAScript language specification and is one of the major technologies used to create website content and is suppsrted by all modern web browsers. Javascript has become one of the most popular programming languages on the web with the proliferation of numerous frameworks, libraries, practice and usage in recent years. ",
    tagType: "technologies"
  },

  {
    name: "Electrical Engineering",
    slug: "electrical-engineering",
    description: "Electrical engineering is a field of engineering that generally deals with the study and application of electricity, electronics, and electromagnetism. ",
    tagType: "non-cs-disciplines"
  },
  {
    name: "Mechanical Engineering",
    slug: "mechanical-engineering",
    description: "Mechanical engineering is the discipline that applies the principles of engineering, physics, and materials science for the design, analysis, manufacturing, and maintenance of mechanical systems. ",
    tagType: "non-cs-disciplines"
  },
  {
    name: "Civil Engineering",
    slug: "civil-engineering",
    description: "Civil engineering is a professional engineering discipline that deals with the design, construction, and maintenance of the physical and naturally built environment, including works like roads, bridges, canals, dams, and buildings. ",
    tagType: "non-cs-disciplines"
  },
  {
    name: "Computer Engineering",
    slug: "computer-engineering",
    description: "Computer engineering is a discipline that integrates several fields of electrical engineering and computer science required to develop computer hardware and software. ",
    tagType: "cs-disciplines"
  },
  {
    name: "REST",
    slug: "rest",
    description: "REST stands for Representational State Transfer, and is the software architectural style of the World Wide Web. REST's coordinated set of constraints, applied to the design of components in a distributed hypermedia system, can lead to a higher-performing and more maintainable software architecture. ",
    tagType: "technologies"
  },
  {
    name: "dotNET",
    slug: "dotnet",
    description: ".NET (dotNET) 2015 is the umbrella that represents the key pieces of the .NET platform delivered from Microsoft, including the .NET Framework, the recently announced .NET Core, and a shared common layer of packages, compilers and runtime. ",
    tagType: "technologies"
  },
  {
    name: "SharePoint",
    slug: "share-point",
    description: "SharePoint is a web application platform in the Microsoft Office server suite. Launched in 2001,[3] SharePoint combines various functions which are traditionally separate applications: intranet, extranet, content management, document management, personal cloud, enterprise social networking, enterprise search, business intelligence, workflow management, web content management, and an enterprise application store. ",
    tagType: "technologies"
  },
  {
    name: "jQuery",
    slug: "jquery",
    description: "jQuery is a fast, small, and feature-rich JavaScript library. It makes things like HTML document traversal and manipulation, event handling, animation, and Ajax much simpler with an easy-to-use API that works across a multitude of browsers. ",
    tagType: "technologies"
  },
  {
    name: "iOS",
    slug: "ios",
    description: "iOS (originally iPhone OS) is a mobile operating system created and developed by Apple Inc. and distributed exclusively for Apple hardware. It is the operating system that presently powers many of the company's mobile devices, including the iPhone, iPad, and iPod touch.  ",
    tagType: "technologies"
  },
  {
    name: "Object-Oriented Programming (OOP)",
    slug: "oop",
    description: "Object-oriented programming (OOP) is a programming language model organized around objects rather than 'actions' and data rather than logic. ",
    tagType: "technologies"
  },
  {
    name: "Integrated Circuit Design",
    slug: "integrated-circuit-design",
    description: "a subset of electronics engineering, encompassing the particular logic and circuit design techniques required to design integrated circuits, or ICs.  ",
    tagType: "technologies"
  },
  {
    name: "Business Administration",
    slug: "business-administration",
    description: "Business administration is the process of managing a business or non-profit organization, so that it remains stable and continues to grow. ",
    tagType: "non-cs-disciplines"
  },

  {
    name: "Windows",
    slug: "windows",
    description: "Windows is an operating system developed and sold by Microsoft. ",
    tagType: "technologies"
  },
  {
    name: "Matlab",
    slug: "matlab",
    description: "Matlab is a high-level language and interactive environment used by engineers and scientists for numerical computing, data analysis, and algorithm development, and application development. ",
    tagType: "technologies"
  },
  {
    name: "Mathematica",
    slug: "mathematica",
    description: "Mathematica is a symbolic mathematical computation program used for technical computing in areas such as science, engineering, mathematics, and computing. ",
    tagType: "technologies"
  },
  {
    name: "Unity",
    slug: "unity",
    description: "Unity is a cross-platform game engine and game development platform. ",
    tagType: "technologies"
  },
  {
    name: "Azure",
    slug: "azure",
    description: "Azure is a cloud computing platform and infrastructure created by Microsoft for developing and deploying apps, storing and recovering data, or doing large scale computations. ",
    tagType: "technologies"
  },

  //cs disciplines
  {
    name: "Computer Security",
    slug: "computer-security",
    description: "Computer Security is the protection of information systems from theft or damage to the hardware, the software, and to the information on them, as well as from disruption or misdirection of the services they provide. ",
    tagType: "cs-disciplines"
  },

  //non-cs disciplines
  {
    name: "Finance",
    slug: "finance",
    description: "Finance is the planning, management, and control of financial resources to achieve financial goals. ",
    tagType: "non-cs-disciplines"
  },
  {
    name: "Geology and Geophysics",
    slug: "geology-geophysics",
    description: "Geology and Geophysics is centered around the scientific study of the exterior and interior of the Earth and other planetary bodies. ",
    tagType: "non-cs-disciplines"
  },
  {
    name: "Hawaiian",
    slug: "hawaiian",
    description: "The study of the Hawaiian language. ",
    tagType: "non-cs-disciplines"
  },
  {
    name: "History",
    slug: "history",
    description: "History is the study of change and continuity in human society over time. ",
    tagType: "non-cs-disciplines"
  },
  {
    name: "Journalism",
    slug: "journalism",
    description: "Journalism is gathering, processing, and reporting information as news through many media platforms such as print, broadcast, and online. ",
    tagType: "non-cs-disciplines"
  },

  {
    name: "Dynamic Programming",
    slug: "dynamic-programming",
    description: "Dynamic programming is a method for solving a complex problem by breaking it down into a collection of simpler subproblems, solving each of those subproblems just once, and storing their solutions - ideally, using a memory-based data structure.  ",
    tagType: "cs-disciplines"
  },
  {
    name: "Analytical Modeling",
    slug: "analytical-modeling",
    description: "Analytical models are mathematical models that have a closed form solution, i.e. the solution to the equations used to describe changes in a system can be expressed as a mathematical analytic function. ",
    tagType: "cs-disciplines"
  },
  {
    name: "Distributed Computing",
    slug: "distributed-computing",
    description: "A distributed system is a software system in which components located on networked computers communicate and coordinate their actions by passing messages. The components interact with each other in order to achieve a common goal.",
    tagType: "cs-disciplines"
  },

  /*non-CS Disciplines*/
  {
    name: "Law",
    slug: "law",
    description: "Law is a system of rules that are enforced through social institutions to govern behaviour.  ",
    tagType: "non-cs-disciplines"
  },
  {
    name: "Linguistics",
    slug: "linguistics",
    description: "The scientific study of language and its structure, including the study of morphology, syntax, phonetics, and semantics.  There are three aspects to this study: language form, language meaning, and language in context.  ",
    tagType: "non-cs-disciplines"
  },
  {
    name: "Marketing",
    slug: "marketing",
    description: "Marketing describe the means of communication between the company and the consumer audience.  ",
    tagType: "non-cs-disciplines"
  },
  {
    name: "Mathematics",
    slug: "mathematics",
    description: "Mathematics is the study of topics such as quantity (numbers), structure, space, and change.  ",
    tagType: "non-cs-disciplines"
  },
  {
    name: "Medicine",
    slug: "medicine",
    description: "Medicine is the science and practice of the diagnosis, treatment, and prevention of disease.  ",
    tagType: "non-cs-disciplines"
  },

  //*technologies*/
  {
    name: "NumPy",
    slug: "numpy",
    description: "NumPy is the fundamental package for scientific computing with Python.  ",
    tagType: "technologies"
  },
  {
    name: "SciPy",
    slug: "scipy",
    description: "SciPy is an open source Python library used by scientists, analysts, and engineers doing scientific computing and technical computing.  ",
    tagType: "technologies"
  },
  {
    name: "SimPy",
    slug: "simpy",
    description: "SimPy is a process-based discrete-event simulation framework based on standard Python.  ",
    tagType: "technologies"
  },
  {
    name: "S3",
    slug: "s3",
    description: "Amazon S3 is an online file storage web service offered by Amazon Web Services.  ",
    tagType: "technologies"
  },
  {
    name: "Amazon Web Services",
    slug: "amazon-web-services",
    description: "Amazon Web Services, is a collection of cloud computing services, also called web services, that make up a cloud-computing platform offered by Amazon.com. These services operate from 12 geographical regions across the world.  ",
    tagType: "technologies"
  },
  {
    name: "Software Engineering",
    slug: "software-engineering",
    description: "The systematic application of scientific and technological knowledge, methods, and experience to the design, implementation, testing, and documentation of software",
    tagType: "cs-disciplines"
  },

  {
    name: "Microprocessor Design",
    slug: "microprocessor-design",
    description: "Microprocessor Design is the design engineering task of creating a microprocessor, an integrated circuit that contains the functions of a central processing unit of a computer.  ",
    tagType: "cs-disciplines"
  },
  {
    name: "Operating Systems",
    slug: "operating-systems",
    description: "The study of the system software that manages the computer's hardware and software resources. ",
    tagType: "cs-disciplines"
  },
  {
    name: "Network Design",
    slug: "network-design",
    description: "Network Design, which includes topological design, network synthesis, and network realization, is the design task of ensuring a new telecommunications network or service. ",
    tagType: "cs-disciplines"
  },
  {
    name: "Wireless Networks",
    slug: "wireless-networks",
    description: "Wireless Networks is the discipline and study of telecommunication networks that are not connected by cables of any kind. ",
    tagType: "cs-disciplines"
  },
  {
    name: "Network Security",
    slug: "network-security",
    description: "Network Security is the discipline and study that involves securing a computer network infrastructure through a set of policies and procedures in order to track and avoid unauthorized access and exploitation of network services and resources. ",
    tagType: "cs-disciplines"
  },
  /*non-CS Disciplines*/
  {
    name: "Accounting",
    slug: "accounting",
    description: "Accounting is the measurement, processing and communication of financial information about economic entities.",
    tagType: "non-cs-disciplines"
  },
  {
    name: "Aerospace",
    slug: "aerospace",
    description: "Aerospace is the human effort in science, engineering and business to fly in the atmosphere of Earth (aeronautics) and surrounding space (astronautics).",
    tagType: "non-cs-disciplines"
  },
  {
    name: "Agriculture",
    slug: "agriculture",
    description: "Agriculture is the cultivation of animals, plants, fungi, and other life forms for food, fiber, biofuel, medicinal and other products used to sustain and enhance human life.",
    tagType: "non-cs-disciplines"
  },
  {
    name: "Animal Sciences",
    slug: "animal-sciences",
    description: "The study of the biology of Animals including genetics, microbiology, animal behavior, nutrition, physiology, and reproduction.",
    tagType: "non-cs-disciplines"
  },
  {
    name: "Anthropology",
    slug: "anthropology",
    description: "The study of humanity and the workings of societies around the world.  Topics include sociocultural, biological, archaeological and linguistic anthropology.",
    tagType: "non-cs-disciplines"
  },
  {
    name: "Architecture",
    slug: "architecture",
    description: "The process and the product of planning, designing, and constructing buildings and other physical structures. ",
    tagType: "non-cs-disciplines"
  },
  {
    name: "Art",
    slug: "art",
    description: "A diverse range of human activities in creating visual, auditory or performing artifacts" +
    " artworks, expressing the author's imaginative or technical skill, intended to be appreciated for their beauty or emotional power.",
    tagType: "non-cs-disciplines"
  },
  {
    name: "Astronomy",
    slug: "astronomy",
    description: " The study of celestial objects (such as stars, galaxies, planets, moons, asteroids, comets and nebulae) and processes (such as supernovae explosions, gamma ray bursts, and cosmic microwave background radiation), the physics, chemistry, and evolution of such objects and processes, and more generally all phenomena that originate outside the atmosphere of Earth. ",
    tagType: "non-cs-disciplines"
  },
  {
    name: "Biology",
    slug: "biology",
    description: "A natural science concerned with the study of life and living organisms, including their structure, function, growth, evolution, distribution, and taxonomy.",
    tagType: "non-cs-disciplines"
  },
  {
    name: "Botany",
    slug: "botany",
    description: "Also called plant science(s) or plant biology, is the science of plant life and a branch of" +
    " biology.",
    tagType: "non-cs-disciplines"
  },
  {
    name: "Physics",
    slug: "physics",
    description: "The study and branch of science concerned with matter and motion, including the study of the properties and mechanics of heat, light, sound, electricity, magnetism, and the structure of atoms.",
    tagType: "non-cs-disciplines"
  },
  {
    name: "Political Science",
    slug: "political-science",
    description: "The study and branch of knowledge that is concerned with government and political institutions, as well as analysis of political actions and behaviors.",
    tagType: "non-cs-disciplines"
  },
  {
    name: "Psychology",
    slug: "psychology",
    description: "The scientific study of the human mind and its functions, especially those affecting behavior in a given context.",
    tagType: "non-cs-disciplines"
  },
  {
    name: "Public Health",
    slug: "public-health",
    description: "The study of protecting and improving the population's health through healthy lifestyle,  research for disease and injury prevention, as well as the detection and control of infectious diseases.",
    tagType: "non-cs-disciplines"
  },
  {
    name: "Sociology",
    slug: "sociology",
    description: "The study and science of the development, structure, and function of human social relationships.",
    tagType: "non-cs-disciplines"
  },
  /*technologies*/
  {
    name: "Linux",
    slug: "linux",
    description: " A Unix-like and mostly POSIX-compliant computer operating system (OS) assembled under the model of free and open-source software development and distribution.",
    tagType: "technologies"
  },
  {
    name: "Python",
    slug: "python",
    description: "A high level programming language used for object oriented programming and scripting.",
    tagType: "technologies"
  },
  {
    name: "Telecommunications",
    slug: "telecommunications",
    description: "Telecommunication occurs when the exchange of information between two or more entities (communication) includes the use of technology. Communication technology uses channels to transmit information (as electrical signals), either over a physical medium (such as signal cables), or in the form of electromagnetic waves.",
    tagType: "technologies"
  },
  {
    name: "IT",
    slug: "it",
    description: "Information technology (IT) is the application of computers and telecommunications equipment to store, retrieve, transmit and manipulate data, often in the context of a business or other enterprise.",
    tagType: "technologies"
  },
  {
    name: "Perl",
    slug: "perl",
    description: "A high-level general-purpose Unix scripting language.",
    tagType: "technologies"
  },
  {
    name: "React",
    slug: "react",
    description: "An open-source JavaScript library providing a view for data rendered as HTML. React views are typically rendered using components that contain additional components specified as custom HTML tags.",
    tagType: "technologies"
  },
  {
    name: "Android",
    slug: "android",
    description: "A mobile operating system based on the Linux kernel designed for touchscreen mobile devices.",
    tagType: "technologies"
  },
  {
    name: "R",
    slug: "r",
    description: "A programming language and software environment for statistical computing and graphics supported by the R Foundation for Statistical Computing.",
    tagType: "technologies"
  },
  {
    name: "TensorFlow",
    slug: "tensorflow",
    description: "An open source software library for numerical computation using data flow graphs.",
    tagType: "technologies"
  },
  {
    name: "MapReduce",
    slug: "mapreduce",
    description: "A programming model and an associated implementation for processing and generating large data sets with a parallel, distributed algorithm on a cluster.",
    tagType: "technologies"
  },
  {
    name: "Hadoop",
    slug: "hadoop",
    description: "A free, Java-based programming framework that supports the processing of large data sets in a distributed computing environment. It is part of the Apache project sponsored by the Apache Software Foundation.",
    tagType: "technologies"
  },
  {
    name: "SQL",
    slug: "sql",
    description: "Also known as Structured Query Language, is a special-purpose programming language designed for managing data held in a relational database management system (RDBMS), or for stream processing in a relational data stream management system (RDSMS).",
    tagType: "technologies"
  },
  {
    name: "Economics",
    slug: "economics",
    description: "A social science that studies how individuals, governments, firms and nations make choices on allocating scarce resources to satisfy their unlimited wants.",
    tagType: "non-cs-disciplines"
  },
  {
    name: "Education",
    slug: "education",
    description: "A field of study that deals with the methods and problems of teaching.",
    tagType: "non-cs-disciplines"
  },
  {
    name: "Engineering",
    slug: "engineering",
    description: "The work of designing and creating large structures or new products or systems by using scientific methods..",
    tagType: "non-cs-disciplines"
  },
  {
    name: "English",
    slug: "english",
    description: "The study of literature written in the English language, English linguistics, and English sociolinguistics.",
    tagType: "non-cs-disciplines"
  },
  {
    name: "MySQL",
    slug: "mysql",
    description: "The world's most popular open-source database, enabling the cost-effective delivery of reliable, high-performance and scalable web-based and embedded database application.",
    tagType: "technologies"
  },
  {
    name: "Mongo",
    slug: "mongo",
    description: "A cross-platform document-oriented database.  Mongo eschews the traditional table-based relation database structure in favor of JSON-like documents with dynamic schemas, making integration of data in certain types of application easier and faster.",
    tagType: "technologies"
  },
  {
    name: "NoSQL",
    slug: "nosql",
    description: "A database that provides mechanism for storage and retrieval of data which is modeled in means other than the tabular relations used in relational databases.",
    tagType: "technologies"
  },
  {
    name: "D3",
    slug: "d3",
    description: "D3, also known as data-driven documents is a JavaScript library for manipulating documents based on data.  D3 helps bring data to life using HTML, SVG, and CSS.",
    tagType: "technologies"
  },
  {
    name: "PHP",
    slug: "php",
    description: "PHP is a server-side scripting language designed for web development but also used as a general-purpose programming language.",
    tagType: "technologies"
  },

  {
    name: "Selenium",
    slug: "selenium",
    description: "A portable suite of tools that automates web drivers across many platforms, enabling the user to test software in a number of programming languages.",
    tagType: "technologies"
  },
  {
    name: "Arduino",
    slug: "arduino",
    description: "An open-source computer hardware - micro-controller kits - for building devices that can communicate and interact with objects in the physical world.",
    tagType: "technologies"
  },
  {
    name: "Raspberry PI",
    slug: "raspberry-pi",
    description: "A series of small, single-board computers that enables users to learn programming.",
    tagType: "technologies"
  },
  {
    name: "Human Computer Interaction",
    slug: "human-computer-interaction",
    description: "The design and use of computer technology, focusing particularly on the interfaces between people (users) and computers.",
    tagType: "cs-disciplines"
  },
  {
    name: "Mobile Devices",
    slug: "mobile-devices",
    description: "A small computing device, typically small enough to be handheld having a display screen with touch input and/or a miniature keyboard.",
    tagType: "cs-disciplines"
  },
  {
    name: "Cognitive Science",
    slug: "cognitive-science",
    description: "The interdisciplinary scientific study of the mind and its processes.",
    tagType: "cs-disciplines"
  },
  {
    name: "Bioinformatics",
    slug: "bioinformatics",
    description: "An interdisciplinary field that develops methods and software tools for understanding biological data.",
    tagType: "cs-disciplines"
  },
  {
    name: "Medical Informatics",
    slug: "medical-informatics",
    description: "is informatics in health care. It is a multidisciplinary field that uses health information technology (HIT) to improve health care via any combination of higher quality, higher efficiency (spurring lower cost and thus greater availability), and new opportunities.",
    tagType: "cs-disciplines"
  },
  {
    name: "C",
    slug: "c",
    description: "A general-purpose, imperative computer programming language, supporting structured programming, lexical variable scope and recursion, while a static type system prevents many unintended operations.",
    tagType: "technologies"
  },
  {
    name: "C++",
    slug: "cplusplus",
    description: "A general-purpose programming language. It has imperative, object-oriented and generic programming features, while also providing facilities for low-level memory manipulation.",
    tagType: "technologies"
  },
  {
    name: "C-Sharp",
    slug: "c-sharp",
    description: "A multi-paradigm programming language encompassing strong typing, imperative, declarative, functional, generic, object-oriented (class-based), and component-oriented programming disciplines.",
    tagType: "technologies"
  },
  {
    name: "Swift",
    slug: "swift",
    description: "A multi-paradigm, compiled programming language created for iOS, OS X, watchOS and tvOS" +
    " development by Apple Inc.",
    tagType: "technologies"
  },
  {
    name: "Git",
    slug: "git",
    description: "A widely-used source code management system for software development. ",
    tagType: "technologies"
  },
  {
    name: "Australia",
    slug: "australia",
    description: "An Oceanian country comprising the mainland of the Australian continent, the island of Tasmania, and numerous smaller islands.",
    tagType: "locations"
  },
  {
    name: "Africa",
    slug: "africa",
    description: "The world's second-largest and second-most-populous continent.",
    tagType: "locations"
  },
  {
    name: "Europe",
    slug: "europe",
    description: "A continent that comprises the westernmost part of Eurasia.",
    tagType: "locations"
  },
  {
    name: "South America",
    slug: "south-america",
    description: "A continent located in the Western Hemisphere, mostly in the Southern Hemisphere, with a relatively small portion in the Northern Hemisphere.",
    tagType: "locations"
  },
  {
    name: "Canada",
    slug: "canada",
    description: "A country in the northern part of North America.",
    tagType: "locations"
  },
  {
    name: "Department of Defence",
    slug: "dod",
    description: "The Department of Defence (DoD, USDOD, or DOD) is an executive branch department of the federal government of the United States charged with coordinating and supervising all agencies and functions of the government concerned directly with national security and the United States Armed Forces. The Department is also the largest employer in the world, with more than 2.13 million active duty servicemen and women as well as their support staff of civilian workers.",
    tagType: "locations"
  }

];

if (Tags.find().count() === 0){
  _.each(tagsSeed, function(tags){
    Tags.insert(tags);
  });

}

