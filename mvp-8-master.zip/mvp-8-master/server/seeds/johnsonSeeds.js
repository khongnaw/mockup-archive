/**
 * Created by mike on 5/4/2016.
 */

if (CourseHistory.find({'user': "johnson"}).count() === 0){

  var johnsonData = [
    {user:"johnson", season: "Fall", year:12, courseSlug: "ics111", verified: true, grade: "B"},
    {user:"johnson", season: "Fall", year:12, courseSlug: "ics141", verified: true, grade: "B"},
    {user:"johnson", season: "Fall", year:12, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"johnson", season: "Fall", year:12, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"johnson", season: "Fall", year:12, courseSlug: "othxxx", verified: true, grade: "A"},

    {user:"johnson", season: "Spring", year:13, courseSlug: "ics211", verified: true, grade: "B"},
    {user:"johnson", season: "Spring", year:13, courseSlug: "ics241", verified: true, grade: "A"},
    {user:"johnson", season: "Spring", year:13, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"johnson", season: "Spring", year:13, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"johnson", season: "Spring", year:13, courseSlug: "othxxx", verified: true, grade: "A"},


    {user:"johnson", season: "Fall", year:13, courseSlug: "ics211", verified: true, grade: "A"},
    {user:"johnson", season: "Fall", year:13, courseSlug: "ics311", verified: true, grade: "A"},
    {user:"johnson", season: "Fall", year:13, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"johnson", season: "Fall", year:13, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"johnson", season: "Fall", year:13, courseSlug: "othxxx", verified: true, grade: "A"},


    {user:"johnson", season: "Spring", year:14, courseSlug: "ee211", verified: true, grade: "A"},
    {user:"johnson", season: "Spring", year:14, courseSlug: "ee260", verified: true, grade: "A"},
    {user:"johnson", season: "Spring", year:14, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"johnson", season: "Spring", year:14, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"johnson", season: "Spring", year:14, courseSlug: "othxxx", verified: true, grade: "A"},


    {user:"johnson", season: "Fall", year:14, courseSlug: "ee213", verified: true, grade: "A"},
    {user:"johnson", season: "Fall", year:14, courseSlug: "ee361", verified: true, grade: "A"},
    {user:"johnson", season: "Fall", year:14, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"johnson", season: "Fall", year:14, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"johnson", season: "Fall", year:14, courseSlug: "othxxx", verified: true, grade: "A"},


    {user:"johnson", season: "Spring", year:15, courseSlug: "ee315", verified: true, grade: "A"},
    {user:"johnson", season: "Spring", year:15, courseSlug: "ee468", verified: true, grade: "A"},
    {user:"johnson", season: "Spring", year:15, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"johnson", season: "Spring", year:15, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"johnson", season: "Spring", year:15, courseSlug: "othxxx", verified: true, grade: "A"},


    {user:"johnson", season: "Fall", year:15, courseSlug: "ics314", verified: true, grade: "A"},
    {user:"johnson", season: "Fall", year:15, courseSlug: "ics332", verified: true, grade: "A"},
    {user:"johnson", season: "Fall", year:15, courseSlug: "ics415", verified: true, grade: "A"},
    {user:"johnson", season: "Fall", year:15, courseSlug: "othxxx", verified: true, grade: "A"},
    {user:"johnson", season: "Fall", year:15, courseSlug: "othxxx", verified: true, grade: "A"},

    {user:"johnson", season: "Spring", year:16, courseSlug: "ics414", verified: true, grade: "A"},
    {user:"johnson", season: "Spring", year:16, courseSlug: "ee323", verified: true, grade: "A"},
    {user:"johnson", season: "Spring", year:16, courseSlug: "ee342", verified: true, grade: "A"},
    {user:"johnson", season: "Spring", year:16, courseSlug: "ee371", verified: true, grade: "A"}
  ];

  _.map(johnsonData, function(data) {
    CourseHistory.insert(data);
  });
}
if (OpportunityHistory.find({'user': "johnson"}).count() === 0){

  var johnsonOppData = [
    {user:"johnson", season: "Fall", year:12, courseSlug: "atthack16", verified: true},
    {user:"johnson", season: "Fall", year:12, courseSlug: "hicapacity", verified: true},
    {user:"johnson", season: "Fall", year:12, courseSlug: "summer-intern", verified: true},
    {user:"johnson", season: "Fall", year:12, courseSlug: "student-research-symposium", verified: true}

  ];

  _.map(johnsonOppData, function(data) {
    OpportunityHistory.insert(data);
  });
}



if (Tags.find({'users': "johnson"}).count() === 0){

  Tags.update({slug: "nursing"}, {
    $push: {"users": "johnson"}
  });


  CareerGoals.update({slug: "bs-cs"}, {
    $push: {"users": "johnson"}
  });

  CareerGoals.update({slug: "game-designer"}, {
    $push: {"users": "johnson"}
  });

}
