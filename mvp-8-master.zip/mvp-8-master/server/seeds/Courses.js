/**
 * ICS and CE Courses
 * Created by Josephine on 4/13/16
 */

var coursesSeeds = [

  {
    name: "Discrete Mathematics for Computer Science II",
    slug: "ics241",
    number: "ICS 241",
    description: "Discrete Mathematics for Computer Science II (3) Program correctness, recurrence relations and their solutions, divide and conquer relations, relations and their properties, graph theory, trees and their applications, Boolean algebra, introduction to formal languages and automata theory.",
    tags: ["mathematics", "data-science"],
    iceValue: 3
  },
  {
    name: "Algorithms",
    slug: "ics311",
    number: "ICS 311",
    description: "Algorithms (4) (4 1-hr Lec) Design and correctness of algorithms, including divide-and-conquer, greedy and dynamic programming methods. Complexity analyses using recurrence relations, probabilistic methods, and NP-completeness. Applications to order statistics, disjoint sets, B-trees and balanced trees, graphs, network flows, and string matching.",
    tags: ["software-engineering", "mathematics","theory-of-computation","java","mapreduce","algorithms"],
    iceValue: 3
  },
  {
    name: "Machine-Level and Systems Programming",
    slug: "ics312",
    number: "ICS 312",
    description: "Machine-Level and Systems Programming (3) Machine organization, machine instructions, addressing modes, assembler language, subroutine linkage, linking to higher-level languages, interface to operating systems, introduction to assemblers, loaders and compilers. ",
    tags: ["microprocessor-design", "operating-systems", "computer-engineering","computer-architecture"],
    iceValue: 3
  },
  {
    name: "Programming Language Theory",
    slug: "ics313",
    number: "ICS 313",
    description: "Programming Language Theory (3) Syntax, semantics, control structures, variable binding and scopes, data and control abstractions. Programming in functional (LISP) and logic (Prolog) programming styles. ",
    tags: ["software-engineering", "microprocessor-design", "linguistics"],
    iceValue: 3
  },
  {
    name: "Basic Concepts of Computer Science",
    slug: "ics222",
    number: "ICS 222",
    description: "What is computer science about? What is the difference between computers and other machines? What are the limits of computation? Are there computers that are not machines? Understand the basic issues of computability, complexity, and network effects, and learn to apply them in the practice of computation. ",
    tags: [ "theory-of-computation","computer-architecture"],
    iceValue: 3

  },
  {
    name: "Software Engineering I",
    slug: "ics314",
    number: "ICS 314",
    description: "Problem analysis and design, team-oriented development, quality assurance, configuration management, project planning.",
    tags: ["software-engineering", "javascript", "web-design"],
    iceValue: 3
  },
  {
    name: "Data Storage and Retrieval",
    slug: "ics321",
    number: "ICS 321",
    description: "Data storage devices, timing and capacity, programming for files, hashed and indexed files, introduction to relational database systems.",
    tags: ["software-engineering", "database", "system-programming", "data-science"],
    iceValue: 3
  },
  {
    name: "Logic Design and Microprocessors",
    slug: "ics331",
    number: "ICS 331",
    description: "Basic machine architecture, microprocessors, bus organization, circuit elements, logic circuit analysis and design, microcomputer system design.",
    tags: ["microprocessor-design", "circuit-design", "arduino", "machine-learning"],
    iceValue: 3
  },
  {
    name: "Operating Systems",
    slug: "ics332",
    number: "ICS 332",
    description: "Operating system concepts and structure, processes and threads, CPU scheduling, memory management, scheduling, file systems, inter-process communication, virtualization, popular operating systems.",
    tags: ["software-engineering", "operating-systems", "computer-architecture", "windows", "ios", "osx"],
    iceValue: 3
  },
  {
    name: "Network Design and Management",
    slug: "ics351",
    number: "ICS 351",
    description: "Overview of the internet and its capabilities; introduction to HTTP, TCP/IP, ethernet, and wireless 802.11; routers, switches, and NAT; network and wireless security; practical experience in designing and implementing networks.",
    tags: ["software-engineering", "network-design", "network-security", "wireless-networks"],
    iceValue: 3
  },

  {
    name: "The Science, Psychology and Philosophy of Systems Design",
    slug: "ics419",
    number: "ICS 419",
    description: "Scientific, psychological and philosophical bases of systems design, including a survey of human-factors and ergonomic standards; the nature of innovation and creativity as it relates to systems design. Web-enhanced course.",
    tags: ["software-engineering", "computer-engineering"],
    iceValue: 3
  },
  {
    name: "Database System",
    slug: "ics421",
    number: "ICS 421",
    description: "Principles of database systems, data modeling, relational models, database design, query languages, query optimization, concurrency control data security.",
    tags: ["software-engineering", "computer-engineering", "data-visualization"],
    iceValue: 3
  },
  {
    name: "Data Processing",
    slug: "ics422",
    number: "ICS 422",
    description: "Role of data processing in organizations, programming practices, ethics, sequential and indexed file processing, report writing, online transaction processing.",
    tags: ["data-science","software-engineering", "computer-engineering"],
    iceValue: 3
  },
  {
    name: "Data Security and Cryptography I",
    slug: "ics423",
    number: "ICS 423",
    description: "History of secret communication and confidential data storage. Elements of cryptography and cryptanalysis. Classical ciphers. Symmetric key cryptography. Public key cryptography. Data security in cyberspace.",
    tags: ["cryptography", "software-engineering", "computer-engineering"],
    iceValue: 3
  },
  {
    name: "Application Frameworks",
    slug: "ics424",
    number: "ICS 424",
    description: "Experience producing applications with at least two different applications frameworks.",
    tags: ["software-engineering", "computer-engineering"],
    iceValue: 3
  },
  {
    name: "Design for Mobile Devices",
    slug: "ics466",
    number: "ICS 466",
    description: " Lecture introducing design issues, programming languages, operating systems and mark-up languages for internet-enabled mobile devices, such as cell phones and PDAs.",
    tags: ["software-engineering", "silicon-valley", "mobile-devices"],
    iceValue: 3
  },
  {
    name: "Cognitive Science",
    slug: "ics469",
    number: "ICS 469",
    description: "Introduces basic concepts, central problems, and methods from cognitive science. Identifies contributions from disciplines such as cognitive psychology, linguistics, artificial intelligence, philosophy, and neuroscience.",
    tags: ["psychology", "artificial-intelligence", "cognitive-science", "linguistics"],
    iceValue: 3
  },
  {
    name: "Probability, Statistics, and Queuing",
    slug: "ics471",
    number: "ICS 471",
    description: "A hands-on introduction to probability, statistical inference, regression, Markov chains, queuing theory. Use of an interactive statistical graphics environment such as R.",
    tags: ["r", "mathematics", "data-science"],
    iceValue: 3
  },
  {
    name: "Introduction to Bioinformatics Sequences and Genomes Analysis",
    slug: "ics475",
    number: "ICS 475",
    description: "Introduction to bioinformatics to computer sciences students by focusing on how computer sciences techniques can be used for the storage, analysis, prediction and simulation of biological sequences (DNA, RNA and proteins).",
    tags: ["bioinformatics", "data-visualization", "medical-informatics", "biology"],
    iceValue: 3
  },
  {
    name: "Bioinformatics Algorithms and Tool Development",
    slug: "ics476",
    number: "ICS 476",
    description: "Study of commonly used bioinformatic algorithms, with an emphasis on string, tree, and graph algorithms. Presentation of probabilistic and clustering methods. Implementation of the studied algorithms and design of applications.",
    tags: ["bioinformatics", "data-visualization", "medical-informatics", "biology"],
    iceValue: 3
  },

  {
    name: "Introduction to Computer Science I",
    slug: "ics111",
    number: "ICS 111",
    description: "Overview of computer science, writing programs.",
    tags: ["java"],
    iceValue: 3
  },
  {
    name: "Discrete Mathematics for Computer Science I",
    slug: "ics141",
    number: "ICS 141",
    description: "Logic, sets, functions, matrices, algorithmic concepts, mathematical reasoning, recursion, counting techniques, probability theory.",
    tags: ["mathematics", "algorithms"],
    iceValue: 3
  },
  {
    name: "Introduction to Computer Science II",
    slug: "ics211",
    number: "ICS 211",
    description: "Algorithms and their complexity, introduction to software engineering, data structures, searching and sorting algorithms, numerical errors. Pre: grade of 'B' or higher in 111 or consent.",
    tags: ["algorithms"],
    iceValue: 3
  },
  {
    name: "Program Structure",
    slug: "ics212",
    number: "ICS 212",
    description: "Program organization paradigms, programming environments, implementation of a module from specifications, the C and C++ programming languages. Pre: 211 or consent.",
    tags: ["c", "cplusplus"],
    iceValue: 3
  },
  {
    name: "Introduction to Scripting",
    slug: "ics215",
    number: "ICS 215",
    description: "Introduction to scripting languages for the integration of applications and systems. Scripting in operating systems, web pages, server-side application integration, regular expressions, event handling, input validation, selection, repetition, parameter passing, Perl, JavaScript, and PHP. A-F only. Pre: 211 (or concurrent), or consent. (Once a year)",
    tags: ["perl", "javascript", "ruby"],
    iceValue: 3
  },
  {
    name: "Computer Communication Networks",
    slug: "ee449",
    number: "EE 449",
    description: "ISO Reference Model. Physical Layer, Data Link Layer, Network Layer and Transport Layer protocols. Wired and wireless local-area networks. Structure and operation of the Internet including routing, congestion control and flow control. Pre: 315 and one of 342, or MATH 371 or MATH 471; or consent.",
    tags: ["computer-engineering", "electrical-engineering"],
    iceValue: 3
  },
  {
    name: "Computer Architecture",
    slug: "ee461",
    number: "EE 461",
    description: "Structure of stored program machines, data flow machines, pipelining, fault-tolerant computing, instruction set design, effects of compilation on architecture, RISC vs. CISC architecture, uses of parallelism. Pre: 361.",
    tags: ["computer-engineering", "computer-architecture"],
    iceValue: 3
  },
  {
    name: "Object-oriented Software Engineering",
    slug: "ee467",
    number: "EE 467",
    description: "Introduction to advanced techniques for designing, implementing, and testing computer software with a particular focus on using object-oriented design, analysis, and programming to produce high-quality computer programs that solve non-trivial problems. Pre: 367 or consent.",
    tags: ["software-engineering", "computer-engineering", "oop"],
    iceValue: 3
  },
  {
    name: "Introduction to Operating Systems",
    slug: "ee468",
    number: "EE 468",
    description: "Computer system organization; multiprocessor systems, memory hierarchies, assemblers, compilers, operating systems, virtual machine, memory management, processor management; information management. Pre: 361 (or concurrent) and 367 or consent.",
    tags: ["computer-engineering", "operating-systems"],
    iceValue: 3
  },

  {
    name: "Object Oriented Programming",
    slug: "ee205",
    number: "EE 205",
    description: "Second-level programming for computer engineers. Object-oriented programming paradigm, definition and use of classes, fundamentals of object-oriented design in modern object-oriented languages such as C++. Common data structures, simple searching and sorting techniques. CEE, EE, ME, PREN majors only. A-F only. Pre: 160 or consent. (Once a year).",
    tags: ["software-engineering", "computer-engineering"],
    iceValue: 3
  },
  {
    name: "Basic Circuit Analysis I",
    slug: "ee211",
    number: "EE 211",
    description: "Linear passive circuits, time domain analysis, transient and steady-state responses, phasors, impedance and admittance; power and energy, frequency responses, resonance. Pre: MATH 243 (or concurrent) or MATH 252A (or concurrent), and PHYS 272 (or concurrent); or consent.",
    tags: ["electrical-engineering", "computer-engineering", "circuit-design", "calculus"],
    iceValue: 3
  },
  {
    name: "Basic Circuit Analysis II",
    slug: "ee213",
    number: "EE 213",
    description: "(3 Lec, 1 3-hr Lab) Laplace transforms and their application to circuits, Fourier transforms and their applications to circuits, frequency selective circuits, introduction to and design of active filters, convolution, and state space analysis of circuits. A-F only. Pre: 211, and MATH 244 (or concurrent) or MATH 253A (or concurrent); or consent.",
    tags: ["electrical-engineering", "computer-engineering", "matlab", "circuit-design", "calculus"],
    iceValue: 3
  },
  {
    name: "Introduction to Digital Design",
    slug: "ee260",
    number: "EE 260",
    description: "Introduction to the design of digital systems with an emphasis on design methods and the implementation and use of fundamental digital components. Pre: 160 or 110 or ICS 111 or consent.",
    tags: ["microprocessor-design", "electrical-engineering", "computer-architecture", "computer-engineering", "circuit-design"],
    iceValue: 3
  },
  {
    name: "Signal and Systems Analysis",
    slug: "ee315",
    number: "EE 315",
    description: "Discrete-time and continuous time signals and systems, linear systems, convolution, Fourier series, Fourier transform, sampling. Pre: 213 and either MATH 244 or MATH 253A; or consent.",
    tags: ["matlab", "electrical-engineering", "computer-engineering", "calculus"],
    iceValue: 3
  },

  {
    name: "Introduction to Computer Graphics",
    slug: "ics481",
    number: "ICS 481",
    description: "Fundamentals of computer graphics including graphics hardware, representation, manipulation, and display of two- and three-dimensional objects, use of commercial software. Pre: 311 and either MATH 216, MATH 242, or MATH 252A; or consent. ",
    tags: ["art", "computer-graphics"],
    iceValue: 3
  },
  {
    name: "Computer Vision",
    slug: "ics483",
    number: "ICS 483",
    description: "Introductory course in computer vision. Topics include image formation, image processing and filtering, edge detection, texture analysis and synthesis, binocular stereo, segmentation, tracking, object recognition and applications. A-F only. Pre: 212 and 311, or consent. Once a year. ",
    tags: ["computer-vision"],
    iceValue: 3
  },
  {
    name: "Data Visualization",
    slug: "ics484",
    number: "ICS 484",
    description: "ntroduction to data visualization through practical techniques for turning data into images to produce insight. Topics include: information visualization, geospatial visualization, scientific visualization, social network visualization, and medical visualization. Junior standing or higher. Pre: two ICS 300-level courses. (Spring only) ",
    tags: ["data-visualization"],
    iceValue: 3
  },
  {
    name: "Video Game Design and Development",
    slug: "ics485",
    number: "ICS 485",
    description: "Students will team design, build, and demonstrate video games or related interactive entertainment environments and applications. Topics will include emerging computer science techniques relevant to the development of these types of environments. Junior standing or higher. Pre: two ICS 300-level courses. (Spring only) ",
    tags: ["computer-graphics", "art"],
    iceValue: 3
  },
  {
    name: "Programming for Engineers",
    slug: "ee160",
    number: "EE 160",
    description: " Introductory course on computer programming and modern computing environments with an emphasis on algorithm and program design, implementation and debugging. Includes a hands-on laboratory to develop and practice programming skills. Restricted to engineering freshmen and sophomores. A-F only. Pre: Math 241 (or concurrent) or consent. ",
    tags: ["c","linux"],
    iceValue: 3
  },

  {
    name: "Security and Trust I: Resource Protections",
    slug: "ics355",
    number: "ICS 355",
    description: "Security and trust in computers, networks, and society. Security models. Access and authorization. Availability and Denial-of-Service. Trust processes and network interactions. ",
    tags: ["network-security"],
    iceValue: 3
  },
  {
    name: "Introduction to Artificial Intelligence Programming",
    slug: "ics361",
    number: "ICS 361",
    description: "Introduction to the theory of Artificial Intelligence and the practical application of AI techniques in Functional (Common LISP and/or Scheme) and Logic (Prolog) programming languages. Students gain practical experience through programming assignments and projects. ",
    tags: ["artificial-intelligence", "common-lisp", "scheme", "prolog"],
    iceValue: 3
  },
  {
    name: "Computing Ethics for Lab Assistants",
    slug: "ics390",
    number: "ICS 390",
    description: "A lecture/discussion/internship on ethical issues and instructional techniques for students assisting a laboratory section of ICS 101. The class uses multiple significant writing and oral presentation activities to help students learn course content.",
    tags: ["computer-ethics", "communications"],
    iceValue: 3
  },
  {
    name: "Software Engineering II",
    slug: "ics414",
    number: "ICS 414",
    description: "Continuation of 314. Project management, quality, and productivity control, testing and validation, team management. Team-oriented software-implementation project. ",
    tags: ["web-design", "software-engineering"],
    iceValue: 3
  },
  {
    name: "Introduction to Programming for the Web",
    slug: "ics415",
    number: "ICS 415",
    description: "Introduction to emerging technologies for construction of World Wide Web (WWW)-based software. Covers programming and scripting languages used for the creation of WWW sites and client-server programming. Students will complete a medium-sized software project that uses languages and concepts discussed in class. ",
    tags: ["web-design", "software-engineering"],
    iceValue: 3
  },
  {
    name: "Ethics in Electrical Engineering",
    slug: "ee495",
    number: "EE 495",
    description: "Equip electrical engineers with the necessary background for ethical reasoning, as it pertains to technology, society, workplace issues, and the environment. ",
    tags: ["engineering-ethics"],
    iceValue: 3
  },
  {
    name: "Digital Systems and Computer Design Lab",
    slug: "ee361l",
    number: "EE 361L",
    description: "Laboratory for 361, experiments on digital systems and interfacing. ",
    tags: ["microprocessor-design", "electrical-engineering", "computer-engineering"],
    iceValue: 3
  },
  {
    name: "Microelectronic Circuits I Lab",
    slug: "ee323l",
    number: "EE 323L",
    description: "Experiments on linear and logic properties of diodes and transistor networks. ",
    tags: ["electrical-engineering", "circuit-design"],
    iceValue: 3
  },
  {
    name: "Computer Data Structures and Algorithms Lab",
    slug: "ee367l",
    number: "EE 367L",
    description: "Laboratory for 367. ",
    tags: ["electrical-engineering", "algorithms", "system-programming", "cplusplus"],
    iceValue: 3
  },

  {
    name: "Security and Trust II: Information Assurance",
    slug: "ics455",
    number: "ICS 455",
    description: "Channel security. Trojan and noninterference. Basic concepts of cryptology. Cryptographic primitives. Protocols for authentication and key establishment. Pre: 355. (Fall only).",
    tags: ["network-security"],
    iceValue: 3
  },
  {
    name: "Artificial Intelligence",
    slug: "ics461",
    number: "ICS 461",
    description: "Survey of artificial intelligence: natural language processing, vision and robotics, expert systems. Emphasis on fundamental concepts: search, planning, and problem solving, logic, knowledge representation. Pre: 311 or consent.",
    tags: ["algorithms"],
    iceValue: 3
  },
  {
    name: "Artificial Intelligence for Games",
    slug: "ics462",
    number: "ICS 462",
    description: "Techniques to stimulate intelligence in video games: movement, pathfinding with A* search, decision/behavior trees, state machines, machine learning, tactics. Extend games with your own AI implementations; experience 'shootout' contests for the best AI algorithm/implementation. Pre: 212 and (314 or 361) and (PHYS 151 or PHYS 170). (Alt. years)",
    tags: ["algorithms"],
    iceValue: 3
  },
  {
    name: "Human Computer Interaction I",
    slug: "ics464",
    number: "ICS 464",
    description: "Application of concepts and methodologies of human factors, psychology and software engineering to address ergonomic, cognitive, and social factors in the design and evaluation of human-computer systems. Pre: two ICS 300-level courses or consent.",
    tags: ["software-engineering"],
    iceValue: 3
  },
  {
    name: "Introduction to Hypermedia",
    slug: "ics465",
    number: "ICS 465",
    description: "Basic issues of interactive access to information in various formats on computers. Available hardware and software: editing, integration, programming. Implementation of a sample information system. Pre: 311.",
    tags: ["algorithms"],
    iceValue: 3
  },

  {
    name: "Digital Systems and Computer Design",
    slug: "ee361",
    number: "EE 361",
    description: "Design methodology, processor design, control design, memory organization, system organization. Pre: 160 and 260, or consent. ",
    tags: ["microprocessor-design", "electrical-engineering", "computer-engineering"],
    iceValue: 3
  },
  {
    name: "CMOS VLSI Design",
    slug: "ee366",
    number: "EE 366",
    description: "Introduction to the design of very large scale integrated (VLSI) systems and use of CAD tools and design languages. Lab includes hands-on use of CAD tools and experiments with field programmable logic devices. Pre: 260. ",
    tags: ["electrical-engineering", "circuit-design"],
    iceValue: 3
  },
  {
    name: "Computer Data Structures and Algorithms",
    slug: "ee367",
    number: "EE 367",
    description: "Introduction to computer programming algorithms with emphasis on advanced data structures, input-output routines, files, and interpreters. Pre: 205 (with a minimum grade of C-) and ICS 141. ",
    tags: ["electrical-engineering", "algorithms", "system-programming", "cplusplus"],
    iceValue: 3
  },
  {
    name: "Engineering Electromagnetics I",
    slug: "ee371",
    number: "EE 371",
    description: "Transient and steady-state waves on transmission lines. Plane wave solutions of Maxwell's equations. Application of Maxwell's equations under static and time-varying conditions. ",
    tags: ["electrical-engineering", "mathematics", "physics"],
    iceValue: 3
  },
  {
    name: "Wireless Data Networks",
    slug: "ee469",
    number: "EE 469",
    description: "Mobile agent's platforms and systems, mobile agent-based service implementation, middleware, and configuration, wireless local area networks, wireless protocols, network architecture supporting wireless applications, routing protocols in mobile and wireless networks, handoff in mobile and wireless networks. Pre: 344 and 367, or consent. ",
    tags: ["electrical-engineering", "wireless-networks", "network-design"],
    iceValue: 3
  },

  {
    name: "Computer Security and Ethics",
    slug: "ics425",
    number: "ICS 425",
    description: "Theoretical results, security policy, encryption, key management, digital signatures, certificates, passwords. Ethics: privacy, computer crime, professional ethics. Effects of the computer revolution on society.",
    tags: ["computer-security"],
    iceValue: 3
  },
  {
    name: "Computer System Security",
    slug: "ics426",
    number: "ICS 426",
    description: " Information flow, confinement, information assurance, malicious programs, vulnerability analysis, network security, writing secure programs.",
    tags: ["computer-security", "network-security"],
    iceValue: 3
  },
  {
    name: "Computer Architecture",
    slug: "ics431",
    number: "ICS 431",
    description: "Memory management, control flow, interrupt mechanisms, multiprocessor systems, special-purpose devices.",
    tags: ["computer-architecture"],
    iceValue: 3
  },
  {
    name: "Concurrent and High-Performance Programming",
    slug: "ics432",
    number: "ICS 432",
    description: "Principles of concurrent and high performance programming. Multi-threading in C and Java for shared-memory programming. Distributed memory programming with Java. Introduction to cluster computing.",
    tags: ["parallel-programming", "high-performance-programming"],
    iceValue: 3
  },
  {
    name: "Machine Learning Fundamentals",
    slug: "ics435",
    number: "ICS 435",
    description: "Introduction to machine learning concepts with a focus on relevant ideas from computational neuroscience. Information processing and learning in the nervous system. Neural networks. Supervised and unsupervised learning. Basics of statistical learning theory.",
    tags: ["machine-learning"],
    iceValue: 3
  },
  {
    name: "Web Design and Management",
    slug: "ics315",
    number: "ICS 315",
    description: "Web design principles, XML and HTML, tables, forms, and frames, multimedia objects, security, scripting for web applications, web servers, commercial aspects, new technology.",
    tags: ["web-design"],
    iceValue: 3
  },
  {
    name: "Computer Project",
    slug: "ics499",
    number: "ICS 499",
    description: "Individual or small-group projects in system design or application under faculty supervision.",
    tags: [],
    iceValue: 3
  },

  {
    name: "Theory of Computation",
    slug: "ics441",
    number: "ICS 441",
    description: "Grammars, sequential machines, equivalence, minimalization, analysis and synthesis, regular expressions, computability, unsolvability, Godel's theorem, Turing machines. ",
    tags: ["theory-of-computation", "algorithms", "mathematics"],
    iceValue: 3
  },
  {
    name: "Analytical Models and Methods",
    slug: "ics442",
    number: "ICS 442",
    description: "Applications of mathematical methods in computer science with emphasis on discrete mathematics, numerical computation, algebraic models, operations research. ",
    tags: ["mathematics", "dynamic-programming", "analytical-modeling"],
    iceValue: 3
  },
  {
    name: "Parallel Algorithms",
    slug: "ics443",
    number: "ICS 443",
    description: "Introduction to parallel models of computation and design and analysis of parallel algorithms. ",
    tags: ["parallel-programming", "algorithms", "computer-architecture"],
    iceValue: 3
  },
  {
    name: "Data Networks",
    slug: "ics451",
    number: "ICS 451",
    description: " Network analysis, architecture, digital signal analysis and design; circuit switching, packet switching, packet broadcasting; protocols and standards; local area networks; satellite networks; ALOHA channels; examples. ",
    tags: ["network-design", "wireless-networks", "c"],
    iceValue: 3
  },
  {
    name: "Software Design for Robotics",
    slug: "ics452",
    number: "ICS 452",
    description: "Sensors, actuators, signal processing, paradigms of robotic software design, introduction to machine learning, introduction to computer vision, and robot-to-human interaction. A-F only. Pre: two ICS 300-level courses or consent. ",
    tags: ["robotics", "machine-learning", "computer-vision" ],
    iceValue: 3
  },

  {
    name: "Microelectronic Circuits I",
    slug: "ee323",
    number: "EE 323",
    description: "Semiconductor structures, operating principles and characteristics of diodes and amplifying devices. Their application as circuit elements in building basic digital, analog, and integrated circuit subsystems.",
    tags: ["electrical-engineering", "circuit-design"],
    iceValue: 3
  },
  {
    name: "Physical Electronics",
    slug: "ee324",
    number: "EE 324",
    description: "Review of quantum mechanics fundamentals, H-atom, and chemical bonding. Introduction to band structure models and materials. Semiconductor doping, charge carrier statistics and charge transport, including ambipolar transport. Metal-semiconductor and PN junctions.",
    tags: ["electrical-engineering", "circuit-design"],
    iceValue: 3
  },
  {
    name: "Probability and Statistics",
    slug: "ee342",
    number: "EE 342",
    description: "Probability, statistics, random variables, distributions, densities, expectations, limit theorems, and applications to electrical engineering.",
    tags: ["electrical-engineering", "mathematics"],
    iceValue: 3
  },
  {
    name: "Networking I",
    slug: "ee344",
    number: "EE 344",
    description: "Covers 4 semesters from the Cisco Networking Academy plus supplementary material; hands-on experience with routers and switches; prepares students for the CCNA. Topics include TCP/IP, LANs, WANs, routing protocols, network security; PPP; ISDN, frame relay.",
    tags: ["electrical-engineering", "wireless-networks"],
    iceValue: 3
  },
  {
    name: "Introduction to Computer and Network Security",
    slug: "ee406",
    number: "EE 406",
    description: "Review basic network mechanisms, introduce basic cryptography concepts, and study algorithms and protocols used in computer and network security. Discuss practical security mechanisms.",
    tags: ["electrical-engineering", "network-security", "cryptography"],
    iceValue: 3
  },
  {
    name: "Other Course",
    slug: "othxxx",
    number: "Other XXX",
    description: "This is another course.",
    tags: ["general-education"],
    iceValue: 0
  }

];

if (Courses.find().count() === 0){
  _.each(coursesSeeds, function(courses){
    Courses.insert(courses);
  });

}