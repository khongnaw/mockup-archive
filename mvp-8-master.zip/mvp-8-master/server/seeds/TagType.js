/**
 * TagType Seeds
 * Created by Josephine on 4/13/2016
 */

var tagTypeSeeds = [
  {name: "CS Disciplines", slug: "cs-disciplines", description: "Computer science and engineering areas of interest."},
  {name: "Non-CS Disciplines", slug: "non-cs-disciplines", description: "Areas of interest apart from computer science and engineering."},
  {name: "Locations", slug: "locations", description: "Geographic areas of interest."},
  {name: "Technologies", slug: "technologies", description: "Computer science and engineering languages, tools, and technologies"}
];

if (TagType.find().count() === 0){
  _.each(tagTypeSeeds, function(tagTypes){
    TagType.insert(tagTypes);
  });

}
