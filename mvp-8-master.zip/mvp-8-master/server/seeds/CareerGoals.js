/**
 * Career Goals Seed
 * Created by Josephine on 4/13/16
 */

var careerGoalSeeds = [
  {
    name: "Web developer",
    slug: "web-developer",
    description: "Web developers typically handle both server-side and front-end logic. This usually involves implementing all the visual elements that users see and use in the web application, as well as all the web services and APIs that are necessary to power the front-end."
  },
  {
    name: "Business intelligence analyst",
    slug: "business-intelligence-analyst",
    description: "Provides historical, current and predictive views of business operations.  Intelligence is gleamed through  reporting, online analytical processing, analytics, data mining, process mining, complex event processing, business performance management, benchmarking, text mining, predictive analytics and prescriptive analytics. "
  },
  {
    name: "Computer system engineer",
    slug: "computer-system-engineer",
    description: "A combination of computer science, engineering, and mathematical analysis employed to develop, test and evaluate software, circuits, personal computers and more. A systems engineer doesn't simply engineer computer technology, but understand how that technology fits into the larger scheme of professional and personal needs."
  },
  {
    name: "Database Administrator",
    slug: "database-administrator",
    description: "An IT professional who ensures that the software used to manage a database is properly maintained to allow rapid access when needed. Because constant access, searches, traffic are likely to have a damaging effect on any company database, the DBA works to maintain the efficiency of the servers. "
  },
  {
    name: "Network Engineer",
    slug: "network-engineer",
    description: "Network engineers are responsible for implementing, maintaining, supporting, developing and, in some cases designing communication networks within an organization. Their goal is to ensure the integrity of high availability network infrastructure in order to provide maximum performance for their users."
  },
  {
    name: "Information Security Analyst",
    slug: "information-security-analyst",
    description: "Information security analysts are responsible for planning and implementing security measures to protect computer systems, networks and data. Information security analysts are expected to stay up-to-date on the latest intelligence, including hackers' methodologies, in order to anticipate security breaches. They also are responsible for preventing data loss and service interruptions by researching new technologies that will effectively protect a" +
    " network."
  },
  {
    name: "Data Mining",
    slug: "data-mining",
    description: "The Data Mining Specialist's role is to design data modeling/analysis services that are used to mine enterprise systems and applications for knowledge and information that enhances business processes. This individual is also responsible for building, deploying and maintaining data support tools, metadata inventories and definitions for database file/table creation."
  },
  {
    name: "Operations Research Analyst",
    slug: "operations-research-analyst",
    description: "An operations research analyst is someone who formulates and applies mathematical modeling and other optimizing methods to develop and interpret information that assists management with decision making, policy formulation, or other managerial functions. May collect and analyze data and develop decision support software, service, or products. May develop and supply optimal time, cost, or logistics networks for program evaluation, review, or implementation."
  },
  {
    name: "User Experience Designer",
    slug: "user-experience-designer",
    description: "A user experience designer defines interaction models, user task flows, and UI specifications. Communicates scenarios, end-to-end experiences, interaction models, and screen designs to stakeholders."
  },
  {
    name: "Data Scientist",
    slug: "data-scientist",
    description: " Data Scientist role is responsible for modeling complex problems, discovering insights and identifying opportunities through the use of statistical, algorithmic, mining and visualization techniques. In addition to advanced analytic skills, this role is also proficient at integrating and preparing large, varied datasets, architecting specialized database and computing environments, and communicating results."
  },

  {
    name: "B.A. in Information and Computer Sciences",
    slug: "ba-ics",
    description: "The Bachelor of Arts degree in Information and Computer Sciences (BA ICS) allows students to combine computer science with another discipline."
  },
  {
    name: "B.S. in Computer Science",
    slug: "bs-cs",
    description: "The Bachelor of Science degree in Computer Science (BS CS) focuses on software technology and gives the student a firm foundation in science and math."
  },
  {
    name: "B.S. in Computer Engineering",
    slug: "bs-ce",
    description: "The Bachelor of Science degree in Computer Engineering (BS CE) focuses on hardware and software technologies and how they are used together to create systems."
  },

  {
    name: "Robotics Engineer",
    slug: "robotics-engineer",
    description: "Robotics engineers use computer-aided design and drafting (CADD) and computer-aided manufacturing (CAM) systems to perform their tasks."
  },
  {
    name: "Bioinformatics Developer",
    slug: "bioinformatics-developer",
    description: "A bioinformatics developer will implement data analysis, communication, and visualization solutions critical to improving crop yield, primarily by improving photosynthetic metabolism. They implement robust data analysis pipelines and services that provide complex computational science analytic results to plant biologists and biochemists in a highly collaborative and integrative setting."
  },
  {
    name: "Animation Designer",
    slug: "animation-designer",
    description: "An animation designer utilizes the latest computer technology to create images and effects for television, movies, websites and video games. They also coordinate projects and animators to produce 3D animation."
  },
  {
    name: "Game Designer",
    slug: "game-designer",
    description: "Game designers work with a team developing and designing video games.  Game designers have duties like designing characters, levels, puzzles, art and animation, and writing code, using various computer programming languages."
  }

];


if (CareerGoals.find().count() === 0){
  _.each(careerGoalSeeds, function(careers){
    CareerGoals.insert(careers);
  });

}
