/**
 *
 * Created by mike on 4/15/2016.
 */


var userSeeds = [
  {
    firstName: "Anthony",
    lastName: "Kriste",
    slug: "anthonykriste",
    password: "foo",
    uhEmail: "kriste@hawaii.edu",
//    role: RadGrad.role.student
  }
];

if (Users.find().count() === 0){
  _.each(userSeeds, function(users){
    Users.insert(users);
  });

}