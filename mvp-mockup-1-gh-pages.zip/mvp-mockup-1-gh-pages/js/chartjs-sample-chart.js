//Sampel Line Chart
var LineChartSampleData = {
  labels: ["2011", "2012", "2013", "2014", "2015", "2016"],
  datasets: [{
    label: "B.S. ICS",
    fillColor: "rgba(127,192,83,0.2)",
    strokeColor: "rgba(127,192,83,1)",
    pointColor: "rgba(127,192,83,1)",
    pointStrokeColor: "#fff",
    pointHighlightFill: "#fff",
    pointHighlightStroke: "rgba(127,192,83,1)",
    data: [59, 80, 81, 56, 55, 40]
  }, {
    label: "B.A. ICS",
    fillColor: "rgba(126,146,252,0.2)",
    strokeColor: "rgba(126,146,252,1)",
    pointColor: "rgba(126,146,252,1)",
    pointStrokeColor: "#fff",
    pointHighlightFill: "#fff",
    pointHighlightStroke: "rgba(126,146,252,1)",
    data: [48, 40, 19, 86, 27, 90]
  }, {
    label: "C.E. EE",
    fillColor: "rgba(91,91,91,0.2)",
    strokeColor: "rgba(91,91,91,1)",
    pointColor: "rgba(91,91,91,1)",
    pointStrokeColor: "#fff",
    pointHighlightFill: "#fff",
    pointHighlightStroke: "rgba(91,91,91,1)",
    data: [40, 60, 50, 40, 70, 80]
  }]
};

window.onload = function() {

  window.LineChartSample = new Chart(document.getElementById("line-chart-sample").getContext("2d")).Line(LineChartSampleData,{
    responsive:true
  });
};
 