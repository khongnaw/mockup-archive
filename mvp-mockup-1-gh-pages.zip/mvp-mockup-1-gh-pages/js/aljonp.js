$(document).ready(function(){
  // the "href" attribute of .modal-trigger must specify the modal ID that wants to be triggered
  $('.modal-trigger').leanModal();

  $('.slider').slider({
    interval: 7000,
    transition: 700,
    height: 460
  });

  $(".up").hide();

  $(".collapsible-header").click(function() {
    $(this).find(".up, .down").toggle();
  });
});

google.charts.load('current', {'packages':['corechart']});
google.charts.setOnLoadCallback(drawChart);

function drawChart() {
  var data = google.visualization.arrayToDataTable([
    ['Year', 'B.A. ICS', 'B.S. ICS', 'B.S. ce'],
    ['2012',  198,      60, 109],
    ['2013',  207,      78, 100],
    ['2014',  190,       73, 104],
    ['2015',  212,      90, 80],
    ['2016',  234,      98, 98]
  ]);

  var options = {
    curveType: 'function',
    legend: { position: 'bottom' }
  };

  var chart = new google.visualization.LineChart(document.getElementById('curve_chart'));

  chart.draw(data, options);
}