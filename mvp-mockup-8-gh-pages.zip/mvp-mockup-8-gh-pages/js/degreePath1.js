/**
 * Created by mike on 2/27/2016.
 */


// create an array with nodes
var nodes1 = new vis.DataSet([
  {id: 'ee160', label: 'EE 160'},
  {id: 'ics141', label: 'ICS 141'},
  {id: 'ics111', label: 'ICS 111'},
  {id: 'ics241', label: 'ICS 241'},
  {id: 'ics212', label: 'ICS 212'},
  {id: 'ics211', label: 'ICS 211'},
  {id: 'ee367', label: 'EE 367'},
  {id: 'ee205', label: 'EE 205'},
  {id: 'ee361', label: 'EE 361'},
  {id: 'ee260', label: 'EE 260'},
  {id: 'ee468', label: 'EE 468',    color:'#7dc24c', labelHighlightBold: true},
  {id: 'ee296', label: 'EE 296'},
  {id: 'ee461', label: 'EE 461',color:'#e0e0e0'},
  {id: 'ee406', label: 'EE 406',color:'#e0e0e0'},
  {id: 'ee366', label: 'EE 366',color:'#e0e0e0'},
  {id: 'ee467', label: 'EE 467',color:'#e0e0e0'},
  {id: 'ee344', label: 'EE 344'},
  {id: 'ics314', label: 'ICS 314'},
  {id: 'ics414', label: 'ICS 414',color:'#e0e0e0'},
  {id: 'ics321', label: 'ICS 321',color:'#7dc24c'},
  {id: 'ics415', label: 'ICS 415',color:'#e0e0e0'},
  {id: 'ee211', label: 'EE 211'},
  {id: 'ee213', label: 'EE 213'},
  {id: 'ee342', label: 'EE 342',color:'#e0e0e0'},
  {id: 'ee315', label: 'EE 315',color:'#7dc24c'},
  {id: 'ee323', label: 'EE 323'},
  {id: 'ee371', label: 'EE 371',color:'#e0e0e0'},
  {id: 'ics421', label: 'ICS 421',color:'#e0e0e0'},
  {id: 'ee449', label: 'EE 449',color:'#e0e0e0'},
  {id: 'ics311', label: 'ICS 311',    color:'#7dc24c'},
  {id: 'ee396', label: 'EE 396',color:'#7dc24c'},
  {id: 'ee496', label: 'EE 496',color:'#e0e0e0'}
]);

var nodes2 = new vis.DataSet([
  {id: 'ee160', label: 'EE 160'},
  {id: 'ics141', label: 'ICS 141'},
  {id: 'ics111', label: 'ICS 111'},
  {id: 'ics241', label: 'ICS 241'},
  {id: 'ics212', label: 'ICS 212'},
  {id: 'ics211', label: 'ICS 211'},
  {id: 'ee367', label: 'EE 367'},
  {id: 'ee205', label: 'EE 205'},
  {id: 'ee361', label: 'EE 361'},
  {id: 'ee260', label: 'EE 260'},
  {id: 'ee468', label: 'EE 468',    color:'#7dc24c', labelHighlightBold: true},
  {id: 'ee296', label: 'EE 296'},
  {id: 'ee461', label: 'EE 461',color:'#e0e0e0'},
  {id: 'ee406', label: 'EE 406',color:'#e0e0e0'},
  {id: 'ee366', label: 'EE 366',color:'#e0e0e0'},
  {id: 'ee467', label: 'EE 467',color:'#e0e0e0'},
  {id: 'ee344', label: 'EE 344'},
  {id: 'ics314', label: 'ICS 314'},
  {id: 'ics414', label: 'ICS 414',color:'#e0e0e0'},
  {id: 'ics321', label: 'ICS 321',color:'#7dc24c'},
  {id: 'ics415', label: 'ICS 415',color:'#e0e0e0'},
  {id: 'ee211', label: 'EE 211'},
  {id: 'ee213', label: 'EE 213'},
  {id: 'ee342', label: 'EE 342',color:'#e0e0e0'},
  {id: 'ee315', label: 'EE 315',color:'#7dc24c'},
  {id: 'ee323', label: 'EE 323'},
  {id: 'ee371', label: 'EE 371',color:'#e0e0e0'},
  {id: 'ics421', label: 'ICS 421',color:'#e0e0e0'},
  {id: 'ee449', label: 'EE 449',color:'#e0e0e0'},
  {id: 'ics311', label: 'ICS 311',    color:'#7dc24c'},
  {id: 'ee396', label: 'EE 396',color:'#7dc24c'},
  {id: 'ee496', label: 'EE 496',color:'#e0e0e0'}
]);


// create an array with edges
var edges1 = new vis.DataSet([
  {from: 'ee160', to: 'ee344'},
  {from: 'ee160', to: 'ee205'},
  {from: 'ee160', to: 'ee260'},
  {from: 'ee260', to: 'ee361'},
  {from: 'ee260', to: 'ee366'},
  {from: 'ee361', to: 'ee461'},
  {from: 'ee205', to: 'ee367'},
  {from: 'ee367', to: 'ee468'},
  {from: 'ee367', to: 'ee467'},
  {from: 'ee467', to: 'ics414'},
  {from: 'ee211', to: 'ee213'},
  {from: 'ee213', to: 'ee342'},
  {from: 'ee213', to: 'ee315'},
  {from: 'ee213', to: 'ee323'},
  {from: 'ee213', to: 'ee371'},
  {from: 'ee342', to: 'ee449'},
  {from: 'ee315', to: 'ee342'},
  {from: 'ee296', to: 'ee396'},
  {from: 'ee396', to: 'ee496'},
  {from: 'ics141', to: 'ics241'},
  {from: 'ics241', to: 'ics314'},
  {from: 'ics314', to: 'ics414'},
  {from: 'ics141', to: 'ee367'},
  {from: 'ics241', to: 'ics311'},
  {from: 'ics211', to: 'ics311'},
  {from: 'ee367', to: 'ics311'},
  {from: 'ee367', to: 'ics321'},
  {from: 'ee367', to: 'ee406'},
  {from: 'ics311', to: 'ics415'},
  {from: 'ee367', to: 'ics212'},
  {from: 'ics211', to: 'ics212'},
  {from: 'ics321', to: 'ics421'},
  {from: 'ics111', to: 'ics241'}
]);

// create a network
var container1 = document.getElementById('mynetwork');

// provide the data in the vis format
var data1 = {
  nodes: nodes1,
  edges: edges1
};
var options1 = {

  autoResize: true,
  height: '100%',
  width: '100%',
  edges: {
    arrows: {
      to: {enabled: true, scaleFactor: 1},
      middle: {enabled: false, scaleFactor: 1},
      from: {enabled: false, scaleFactor: 1}
    }
  },
  layout: {
    randomSeed: undefined,
    improvedLayout:true,
    hierarchical: {
      enabled: true,
      levelSeparation: 150,
      nodeSpacing: 10,
      treeSpacing: 0,
      blockShifting: true,
      edgeMinimization: true,
      parentCentralization: true,
      direction: 'DU',        // UD, DU, LR, RL
      sortMethod: 'directed'   // hubsize, directed
    }
  }
};

// initialize your network!
var network1 = new vis.Network(container1, data1, options1);
network1.setOptions(options1);
//
//
//
