$(document).ready(function(){
  // the "href" attribute of .modal-trigger must specify the modal ID that wants to be triggered
  $('.modal-trigger').leanModal();

  $('.slider').slider({
    interval: 6000,
    transition: 300,
    height: 500
  });

  $(".up").hide();

  $(".collapsible-header").click(function() {
    $(this).find(".up, .down").toggle();
  });
});

google.charts.load('current', {'packages':['corechart']});
google.charts.setOnLoadCallback(drawChart);

function drawChart() {
  var data = google.visualization.arrayToDataTable([
    ['Year', 'B.A. ICS', 'B.S. ICS', 'B.S. ce'],
    ['2012',  198,      60, 109],
    ['2013',  207,      78, 100],
    ['2014',  190,       73, 104],
    ['2015',  212,      90, 80],
    ['2016',  234,      98, 98]
  ]);

  var options = {
    curveType: 'function',
    legend: { position: 'bottom' }
  };

  var chart = new google.visualization.LineChart(document.getElementById('curve_chart'));

  chart.draw(data, options);
}



  var interestWords = [
    {text: "Aerospace", weight: 10},
    {text: "Algorithms", weight: 10},
    {text: "Android", weight: 15},
    {text: "Data Science", weight: 8},
    {text: "Game Design", weight: 18},
    {text: "Javascript", weight: 22},
    {text: "Machine Learning", weight: 19},
    {text: "Software Engineering", weight: 20},
    {text: "Python", weight: 27},
    {text: "Security", weight: 21},
    {text: "Networks", weight: 16},
    {text: "C++", weight: 22},
    {text: "Java", weight: 10}
  ];

  $('#interests-cloud').jQCloud(interestWords, {
    autoResize: true
  });

  var degreegoalWords = [
    {text: "Network designer", weight: 14},
    {text: "Systems analyst", weight: 17},
    {text: "Biomedical Engineer", weight: 15},
    {text: "Data Scientist", weight: 8},
    {text: "DB Administrator", weight: 6},
    {text: "Ph.D. student", weight: 12},
    {text: "Robotics Engineer", weight: 9},
    {text: "Security Analyst", weight: 10},
    {text: "UX Designer", weight: 10}
  ];

  $('#degreegoals-cloud').jQCloud(degreegoalWords, {
    autoResize: true,
    removeOverflowing: false
  });

  $('#interests-tab').on('click', function () {
    setTimeout(function () {
      $('#interests-cloud').jQCloud('update', interestWords);
    }, 500);
  });

  $('#degreegoals-tab').on('click', function () {
    setTimeout(function () {
      $('#degreegoals-cloud').jQCloud('update', degreegoalWords);
    }, 500);
  });

