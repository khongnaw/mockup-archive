function scrollTab(){

  $('ul.tabs').each(function(){
    // For each set of tabs, we want to keep track of
    // which tab is active and its associated content
    var $active, $content, $links = $(this).find('a');

    // If the location.hash matches one of the links, use that as the active tab.
    // If no match is found, use the first link as the initial active tab.
    $active = $($links.filter('[href="'+location.hash+'"]')[0] || $links[0]);
    $active.addClass('active');

    $content = $($active[0].hash);

    // Hide the remaining content
    $links.not($active).each(function () {
      $(this.hash).hide();
    });

    // Bind the click event handler
    $(this).on('click', 'a', function(e){

      // Make the old tab inactive.
      $active.removeClass('active');
      $content.hide();

      // Update the variables with the new link and content
      $active = $(this);
      $content = $(this.hash);

      // Make the tab active.
      $active.addClass('active');
      $content.show();

      // Prevent the anchor's default click action
      e.preventDefault();
    });
  });
}
function renderCharts(){
  var iceRating= document.getElementById("iceRating").getContext("2d");
  var iceData =[
    {
      value: 11,
      color:"#F7464A",
      highlight: "#FF5A5E",
      label: "Innovation"
    },
    {
      value: 6,
      color: "#46BFBD",
      highlight: "#5AD3D1",
      label: "Competency"
    },
    {
      value: 4,
      color: "#FDB45C",
      highlight: "#FFC870",
      label: "Experience"
    }

  ];

  var iceOptions = {
    //Boolean - Show a backdrop to the scale label
    scaleShowLabelBackdrop : true,

    //String - The colour of the label backdrop
    scaleBackdropColor : "rgba(255,255,255,0.75)",

    // Boolean - Whether the scale should begin at zero
    scaleBeginAtZero : true,

    //Number - The backdrop padding above & below the label in pixels
    scaleBackdropPaddingY : 2,

    //Number - The backdrop padding to the side of the label in pixels
    scaleBackdropPaddingX : 2,

    //Boolean - Show line for each value in the scale
    scaleShowLine : true,

    //Boolean - Stroke a line around each segment in the chart
    segmentShowStroke : true,

    //String - The colour of the stroke on each segement.
    segmentStrokeColor : "#fff",

    //Number - The width of the stroke value in pixels
    segmentStrokeWidth : 2,

    //Number - Amount of animation steps
    animationSteps : 100,

    //String - Animation easing effect.
    animationEasing : "easeOutBounce",

    //Boolean - Whether to animate the rotation of the chart
    animateRotate : true,

    //Boolean - Whether to animate scaling the chart from the centre
    animateScale : false,

  };
  new Chart(iceRating).PolarArea(iceData, iceOptions);

  /////////////////////////////////////////////////////////////////////////////
  //Credit Graph
  var creditCompletionChart= document.getElementById("creditCompletionChart").getContext("2d");
  var creditCompletion = [

    {
      value : 70,
      color : "#7dc24c"
    },

    {
      value : 30,
      color : "white"
    }

  ];

  var creditCompletionOptions = {
    segmentShowStroke : true,
    animateScale : true,
    //Number - The percentage of the chart that we cut out of the middle
    percentageInnerCutout : 70, // This is 0 for Pie charts
    //String - The colour of each segment stroke
    segmentStrokeColor : "#7dc24c"

  };

  new Chart(creditCompletionChart).Doughnut(creditCompletion, creditCompletionOptions);



}

renderCharts();
scrollTab();