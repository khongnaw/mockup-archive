$(document).ready(function () {
  dragula([
        document.querySelector('#sp16'),
        document.querySelector('#s16'),
        document.querySelector('#rec-courses'),
        document.querySelector('#rec-courses1'),
        document.querySelector('#rec-courses2'),
        document.querySelector('#rec-courses3'),
        document.querySelector('#rec-courses4'),
        document.querySelector('#rec-courses5'),
        document.querySelector('#rec-courses6')
      ],
      {
        revertOnSpill: true,
        ignoreInputTextSelection: false
      });

  dragula([
        document.querySelector('#fall12op'),
        document.querySelector('#sp13op'),
        document.querySelector('#s13op'),
        document.querySelector('#fall13op'),
        document.querySelector('#sp14op'),
        document.querySelector('#s14op'),
        document.querySelector('#fall14op'),
        document.querySelector('#sp15op'),
        document.querySelector('#s15op'),
        document.querySelector('#fall15op'),
        document.querySelector('#sp16op'),
        document.querySelector('#s16op'),
        document.querySelector('#rec-opp'),
        document.querySelector('#rec-opp1'),
        document.querySelector('#rec-opp2'),
        document.querySelector('#rec-opp3'),
        document.querySelector('#rec-opp4')
      ],
      {
        revertOnSpill: true,
        ignoreInputTextSelection: false
      });

  dragula([
        document.querySelector('#sp16o'),
        document.querySelector('#s16o'),
        document.querySelector('#other'),
        document.querySelector('#other1'),
        document.querySelector('#other2'),
        document.querySelector('#other3'),
        document.querySelector('#other4'),
        document.querySelector('#other5')
      ],
      {
        revertOnSpill: true,
        ignoreInputTextSelection: false
      });
});




/*
 var count = 0;
 var currentOption = "Courses";
 var option_select = $("#option-selected");
 var option_selected2 = $("#option-selected2");
 var courseContent = null;
 var opportunitiesContent = null;
 option_select[0].onclick = function(){
 if(currentOption !== "Courses" ) {
 opportunitiesContent = $("#search-results").html();
 $("#search-results").empty();
 $("#search-results").append(courseContent);
 currentOption = "Courses";
 $("#searchInput").attr("placeholder", "Search Courses")
 }
 }
 option_selected2[0].onclick = function(){
 if(currentOption !== "Opportunities") {
 if(count === 0){
 opportunitiesContent = "<div class='card-action center'> <a class='waves-effect cyan waves-light modal-trigger btn hoverable tooltipped' style='height: 35px; width: 300px;' href='#modal4' data-position='right' data-delay='50'>ATT Hackathon 2016</a> </div> <div class='center card-action'> <a class='waves-effect cyan waves-light modal-trigger btn tooltipped' style='height: 35px; width: 300px;' href='#modal5' data-position='right' data-delay='50'>ACM Manoa</a> </div> <div class='center card-action'> <a class='waves-effect cyan waves-light modal-trigger btn hoverable tooltipped' style='height: 35px; width: 300px;' href='#modal6' href='#modal2' data-position='right' data-delay='50'>IEEE Student Chapter</a> </div> "
 count++;
 }
 courseContent = $("#search-results").html();
 $("#search-results").empty();
 $("#search-results").append(opportunitiesContent);
 currentOption = "Opportunities"
 $("#searchInput").attr("placeholder", "Search Opportunities")
 }
 }
 */

/*dragula([
 document.querySelector('#fall12'),
 document.querySelector('#fall12o'),
 document.querySelector('#fall12op'),
 document.querySelector('#sp13'),
 document.querySelector('#sp13o'),
 document.querySelector('#sp13op'),
 document.querySelector('#s13'),
 document.querySelector('#s13o'),
 document.querySelector('#s13op'),

 document.querySelector('#fall13'),
 document.querySelector('#fall13o'),
 document.querySelector('#fall13op'),
 document.querySelector('#sp14'),
 document.querySelector('#sp14o'),
 document.querySelector('#sp14op'),
 document.querySelector('#s14'),
 document.querySelector('#s14o'),
 document.querySelector('#s14op'),

 document.querySelector('#fall14'),
 document.querySelector('#fall14o'),
 document.querySelector('#fall14op'),
 document.querySelector('#sp15'),
 document.querySelector('#sp15o'),
 document.querySelector('#sp15op'),
 document.querySelector('#s15'),
 document.querySelector('#s15o'),
 document.querySelector('#s15op'),

 document.querySelector('#fall15'),
 document.querySelector('#fall15o'),
 document.querySelector('#fall15op'),
 document.querySelector('#sp16'),
 document.querySelector('#sp16o'),
 document.querySelector('#sp16op'),
 document.querySelector('#s16'),
 document.querySelector('#s16o'),
 document.querySelector('#s16op'),

 document.querySelector('#rec-courses'),
 document.querySelector('#rec-opp')
 ]
 )
 }
 );*/