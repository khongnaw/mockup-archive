$(document).ready(function() {

  $('#search-degree').hideseek({
    nodata: 'No results found',
    hightlight: true,
    navigation: true
  });

  $('#search-interest').hideseek({
    nodata: 'No results found',
    hightlight: true,
    navigation: true
  });

  $('#search-icscourse').hideseek({
    nodata: 'No results found',
    hightlight: true,
    navigation: true
  });

  $('#search-opp').hideseek({
    nodata: 'No results found',
    hightlight: true,
    navigation: true
  });

  $('#search-other').hideseek({
    nodata: 'No results found',
    hightlight: true,
    navigation: true
  });
});



