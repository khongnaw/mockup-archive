Chart.types.Line.extend({
  name: "LineAlt",
  draw: function () {
    Chart.types.Line.prototype.draw.apply(this, arguments);

    var ctx = this.chart.ctx;
    ctx.save();
    // text alignment and color
    ctx.textAlign = "center";
    ctx.textBaseline = "bottom";
    ctx.fillStyle = this.options.scaleFontColor;
    // position
    var x = this.scale.xScalePaddingLeft * 0.4;
    var y = this.chart.height / 2;
    // change origin
    ctx.translate(x, y);
    // rotate text
    ctx.rotate(-90 * Math.PI / 180);
    ctx.fillText(this.datasets[0].label, 0, 0);
    ctx.restore();
  }
});

var DegreeStudentData = {
  labels: ["2011", "2012", "2013", "2014", "2015", "2016"],
  datasets: [{
    label: "Number of Students",
    fillColor: "rgba(139,195,74,0.2)",
    strokeColor: "rgba(139,195,74,1)",
    pointColor: "rgba(139,195,74,1)",
    pointStrokeColor: "#fff",
    pointHighlightFill: "#fff",
    pointHighlightStroke: "rgba(139,195,74,1)",
    data: [59, 80, 81, 56, 55, 40]
  }, {
    label: "Number of Students",
    fillColor: "rgba(1,188,212,0.2)",
    strokeColor: "rgba(1,188,212,1)",
    pointColor: "rgba(1,188,212,1)",
    pointStrokeColor: "#fff",
    pointHighlightFill: "#fff",
    pointHighlightStroke: "rgba(1,188,212,1)",
    data: [48, 40, 19, 86, 27, 90]
  }, {
    label: "Number of Students",
    fillColor: "rgba(84,110,112,0.2)",
    strokeColor: "rgba(84,110,112,1)",
    pointColor: "rgba(84,110,112,1)",
    pointStrokeColor: "#fff",
    pointHighlightFill: "#fff",
    pointHighlightStroke: "rgba(84,110,112,1)",
    data: [40, 60, 50, 40, 70, 80]
  }]
};

window.onload = function() {
  window.myLineChart = new Chart(
      document.getElementById("myChart").getContext("2d")).LineAlt(DegreeStudentData,{
        responsive:true,
        scaleFontColor: "#444",
        scaleLabel: "          <%=value%>"
      });
};

var data = {
  labels: ["FALL 2014", "SPR 2014", "FALL 2015", "SPR 2015", "FALL 2016", "SPR 2016"],
  datasets: [
    {
      label: "Number of Credits",
      fillColor: "rgba(220,220,220,0.2)",
      strokeColor: "rgba(220,220,220,1)",
      pointColor: "rgba(220,220,220,1)",
      pointStrokeColor: "#fff",
      pointHighlightFill: "#fff",
      pointHighlightStroke: "rgba(220,220,220,1)",
      data: [15, 32, 48, 63, 81, 96]
    }
  ]
};

var creditData = [
  {
    value: 22,
    color: "#00acc1"
  },
  {
    value: 98,
    color:"#fff",
    highlight: "#fff"
  }
];

var iceData =  [
  {
    value: 40,
    color: "#455a64",
    highlight: "#607d8b",
    label: "Experience"
  },
  {
    value: 60,
    color: "#7cb342",
    highlight: "#9ccc65",
    label: "Competency"
  },
  {
    value: 50,
    color:"#00acc1",
    highlight: "#26c6da",
    label: "Innovation"
  }
];

$(document).ready(function () {
  var ctx3 = document.getElementById("ice-chart").getContext("2d");
  var myNewChart3 = new Chart(ctx3).PolarArea(iceData, {
    segmentStrokeColor : "#FFF"
  });

  var ctx = document.getElementById("credit-doughnut-chart").getContext("2d");
  var myNewChart = new Chart(ctx).Doughnut(creditData, {
    segmentStrokeColor : "#00bcd4",
    segmentStrokeWidth : 4
  });

  var ctx2 = document.getElementById("degree-chart").getContext("2d");
  var myNewChart2 = new Chart(ctx2).LineAlt(data,{
    responsive:true,
    label:true,
    scaleLineColor: "rgba(250,250,250,.3)",
    scaleGridLineColor : "rgba(250,250,250,.3)",
    scaleFontColor: "#FFF",
    scaleOverride : true,
    scaleSteps : 7,
    scaleStepWidth : 15,
    scaleLabel: "          <%=value%>"
  });

});