$(document).ready(function() {
  var icsIntClickOn;
  var icsDegClickOn;
  var oppIntClickOn;
  var oppDegClickOn;


  // the "href" attribute of .modal-trigger must specify the modal ID that wants to be triggered
  $('.modal-trigger').leanModal();

  $('.slider').slider({
    interval: 1000000,
    transition: 800,
    height: 460
  });

  $(".up").hide();

  $(".collapsible-header").click(function() {
    $(this).find(".up, .down").toggle();
  });

  // Initialize collapse button
  $('.button-collapse').sideNav({
        menuWidth: 300, // Default is 240
        edge: 'left', // Choose the horizontal origin
        closeOnClick: false // Closes side-nav on <a> clicks, useful for Angular/Meteor
      }
  );

  $('.collapsible').collapsible({
    accordion : false // A setting that changes the collapsible behavior to expandable instead of the default accordion style
  });

  // On edge hit
  $('.your-class').on('beforeChange', function(event, slick, currentSlide, nextSlide){

    if (currentSlide == 3) {
      $('.right-arrow').addClass('disabled');
    }

    if (nextSlide == 0) {
      $('.left-arrow').addClass('disabled');
    }
    else if (nextSlide == 3) {
      $('.right-arrow').addClass('disabled');
    }
    else {
      $('.left-arrow').removeClass('disabled');
      $('.right-arrow').removeClass('disabled');
    }
  });

  $('.your-class').slick({
    prevArrow: "\<a class=\"left-arrow btn-floating btn-small waves-effect waves-light light-green left\"><i class=\"material-icons\">keyboard_arrow_left</i></a>",
    nextArrow: "\<a class=\"right-arrow btn-floating btn-small waves-effect waves-light light-green right\"><i class=\"material-icons\">keyboard_arrow_right</i></a>",
    appendArrows: ".arrow-holder",
    initialSlide: 3,
    infinite: false
  });

  $('.right-arrow').addClass('disabled');

  $('select').material_select();

  $(".icsStar").click(function() {
    if (icsIntClickOn) {
      if (icsDegClickOn) {
        $('li[class="intICSCourse"]').hide();
        $('.ICSCourse').hide();
      }
      else {
        $('.degICSCourse').show();
        $('.ICSCourse').show();
      }
      icsIntClickOn = false;
    }
    else if (icsDegClickOn) {
      $('.intICSCourse').show();
      $('.ICSCourse').hide();
      icsIntClickOn = true;
    }
    else {
      if ($('.degICSCourse').hasClass("intICSCourse") ) {
        $('.degICSCourse').hide();
        $('li[class="intICSCourse degICSCourse"]').show();
      }
      else {
        $('.degICSCourse').hide();
      }
      $('.ICSCourse').hide();
      icsIntClickOn = true;
    }
  });

  $(".icsDeg").click(function() {
    if (icsDegClickOn) {
      if (icsIntClickOn) {
        $('li[class="degICSCourse"]').hide();
        $('.ICSCourse').hide();
      }
      else {
        $('.intICSCourse').show();
        $('.ICSCourse').show();
      }
      icsDegClickOn = false;
    }
    else if (icsIntClickOn) {
      $('.degICSCourse').show();
      $('.ICSCourse').hide();
      icsDegClickOn = true;
    }
    else {
      if ($('.intICSCourse').hasClass("degICSCourse") ) {
        $('.intICSCourse').hide();
        $('li[class="intICSCourse degICSCourse"]').show();
      }
      else {
        $('.intICSCourse').hide();
      }
      $('.ICSCourse').hide();
      icsDegClickOn = true;
    }
  });

  $(".oppStar").click(function() {
    if (oppIntClickOn) {
      if (oppDegClickOn) {
        $('li[class="intOPPCourse"]').hide();
        $('.OPPCourse').hide();
      }
      else {
        $('.degOPPCourse').show();
        $('.OPPCourse').show();
      }
      oppIntClickOn = false;
    }
    else if (oppDegClickOn) {
      $('.intOPPCourse').show();
      $('.OPPCourse').hide();
      oppIntClickOn = true;
    }
    else {
      if ($('.degOPPCourse').hasClass("intOPPCourse") ) {
        $('.degOPPCourse').hide();
        $('li[class="intOPPCourse degOPPCourse"]').show();
      }
      else {
        $('.degOPPCourse').hide();
      }
      $('.OPPCourse').hide();
      oppIntClickOn = true;
    }
  });

  $(".oppDeg").click(function() {
    if (oppDegClickOn) {
      if (oppIntClickOn) {
        $('li[class="degOPPCourse"]').hide();
        $('.OPPCourse').hide();
      }
      else {
        $('.intOPPCourse').show();
        $('.OPPCourse').show();
      }
      oppDegClickOn = false;
    }
    else if (oppIntClickOn) {
      $('.degOPPCourse').show();
      $('.OPPCourse').hide();
      oppDegClickOn = true;
    }
    else {
      if ($('.intOPPCourse').hasClass("degOPPCourse") ) {
        $('.intOPPCourse').hide();
        $('li[class="intOPPCourse degOPPCourse"]').show();
      }
      else {
        $('.intOPPCourse').hide();
      }
      $('.OPPCourse').hide();
      oppDegClickOn = true;
    }
  });
});