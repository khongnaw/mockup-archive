$(document).ready(function() {
  /* Appending Interests */

  $(".collection-item").on("click", ".addinterest", function() {
    this.innerHTML = "close";

    $(this)
        .removeClass("light-green-text")
        .addClass("cyan-text")
        .closest("li")
        .removeClass("cyan lighten-4");

    $(".interest-table").append( this.closest("li") );

    $(this).removeClass("addinterest");
    $(this).closest("a").attr("onClick", "removeInterest(this);");
  });


  $(".collection-item").on("click", ".adddegreegoals", function() {
    this.innerHTML = "close";

    $(this)
        .removeClass("light-green-text")
        .addClass("cyan-text")
        .closest("li")
        .removeClass("cyan lighten-4");

    $(".degreeg-table").append( this.closest("li") );

    $(this).removeClass("adddegreegoals");
    $(this).closest("a").attr("onClick", "removeDegrees(this);");
  });

});