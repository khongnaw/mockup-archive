/**
 * This function calls Aljon's student profiles.
 */

defineStudentProfilesAljonp = function() {
  defineLaraBryan();
  defineAljon();
  defineLisaChen();
  defineLaloThatom();
  defineSophieWedekind();
  defineKelsie();
  defineSorapong();
  defineJohnson();
};